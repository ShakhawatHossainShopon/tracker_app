<?php
// --- DATABASE CONFIGURATION (Optional shared connection if needed) ---
$host = 'sql102.infinityfree.com'; 
$dbname = 'if0_40135421_trade_tracker'; 
$username = 'if0_40135421';         
$password = 'WasasCNrbr';                 

try {
    $db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    $db = null;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ATR Calculator // Risk Terminal</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @keyframes terminalPulse {
            0%, 100% { opacity: 1; transform: translateY(0); }
            50% { opacity: 0.5; transform: translateY(-1px); }
        }
        .animate-terminal-pulse {
            animation: terminalPulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }
    </style>
</head>
<body class="bg-[#0b0e14] text-[#8b949e] font-mono min-h-screen p-4 md:p-8 flex items-center justify-center">

<!-- Toast Notification Container -->
<div id="toast-container" class="fixed bottom-4 right-4 z-50 flex flex-col gap-2"></div>

<div class="w-full max-w-4xl bg-[#161b22] border border-[#30363d] rounded-md shadow-2xl overflow-hidden">
    
    <!-- Top Terminal Bar -->
    <div class="bg-[#21262d] px-4 py-3 border-b border-[#30363d] flex justify-between items-center">
        <div class="flex items-center gap-2">
            <span class="w-3 h-3 rounded-full bg-[#f85149] inline-block"></span>
            <span class="w-3 h-3 rounded-full bg-[#e3b341] inline-block"></span>
            <span class="w-3 h-3 rounded-full bg-[#2ea043] inline-block"></span>
            <span class="text-xs text-[#c9d1d9] font-bold ml-2 tracking-wider">ATR_CALCULATOR_v1.1 // STOP_LOSS_ENGINE</span>
        </div>
        <div class="text-xs text-[#8b949e]" id="terminal-clock">00:00:00</div>
    </div>

    <div class="p-6 space-y-6">
        
        <!-- Header Nav & Info -->
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-[#30363d] pb-4 gap-4">
            <div>
                <h1 class="text-sm font-bold text-[#c9d1d9] uppercase tracking-wider">ATR Stop-Loss & Take-Profit Matrix</h1>
                <p class="text-xs text-[#8b949e] mt-1">Status: <span class="text-[#2ea043]">CALCULATOR_READY</span></p>
            </div>
            <div>
                <a href="backtest.php" class="bg-[#21262d] hover:bg-[#30363d] border border-[#30363d] text-[#c9d1d9] px-3 py-1.5 rounded text-xs transition">
                    [ BACK_TO_BACKTEST ]
                </a>
            </div>
        </div>

        <!-- Input Panel -->
        <div class="bg-[#0d1117] border border-[#30363d] rounded p-5 space-y-4">
            <h2 class="text-xs font-bold text-[#c9d1d9] uppercase tracking-wider border-b border-[#30363d] pb-2">Parameters</h2>
            
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                    <label class="block text-[11px] font-bold text-[#8b949e] mb-1 uppercase">ATR Value</label>
                    <input type="number" id="input-atr" step="0.00001" value="25" oninput="calculateATR()" class="w-full bg-[#161b22] border border-[#30363d] rounded p-2 text-xs text-[#c9d1d9] focus:border-[#58a6ff] outline-none font-mono">
                </div>
                <div>
                    <label class="block text-[11px] font-bold text-[#8b949e] mb-1 uppercase">ATR Multiplier (SL)</label>
                    <input type="number" id="input-multiplier" step="0.1" value="1.5" oninput="calculateATR()" class="w-full bg-[#161b22] border border-[#30363d] rounded p-2 text-xs text-[#c9d1d9] focus:border-[#58a6ff] outline-none font-mono">
                </div>
                <div>
                    <label class="block text-[11px] font-bold text-[#8b949e] mb-1 uppercase">Current Price</label>
                    <input type="number" id="input-price" step="0.00001" value="66860" oninput="calculateATR()" class="w-full bg-[#161b22] border border-[#30363d] rounded p-2 text-xs text-[#c9d1d9] focus:border-[#58a6ff] outline-none font-mono">
                </div>
                <div>
                    <label class="block text-[11px] font-bold text-[#8b949e] mb-1 uppercase">Risk-to-Reward (1:X)</label>
                    <input type="number" id="input-rr" step="0.1" value="2.0" oninput="calculateATR()" class="w-full bg-[#161b22] border border-[#30363d] rounded p-2 text-xs text-[#c9d1d9] focus:border-[#58a6ff] outline-none font-mono">
                </div>
            </div>
        </div>

        <!-- Output Grid (Buy & Sell Results) -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            <!-- BUY SETUP -->
            <div class="bg-[#0d1117] border border-[#2ea043]/40 rounded p-5 space-y-4">
                <div class="flex justify-between items-center border-b border-[#30363d] pb-2">
                    <h2 class="text-xs font-bold text-[#2ea043] uppercase tracking-wider">// BUY_SETUP_MATRIX</h2>
                    <span class="text-[10px] bg-[#2ea043]/10 text-[#2ea043] border border-[#2ea043]/30 px-2 py-0.5 rounded font-mono">LONG</span>
                </div>
                
                <div class="space-y-3 text-xs font-mono">
                    <div class="flex justify-between items-center bg-[#161b22] border border-[#30363d] p-2.5 rounded">
                        <div>
                            <span class="text-[#8b949e] block text-[10px] uppercase">Stop Loss (SL)</span>
                            <span id="buy-sl" class="text-sm font-bold text-[#f85149]">0.00</span>
                        </div>
                        <button onclick="copyToClipboard('buy-sl', 'Buy Stop Loss copied!')" class="bg-[#21262d] hover:bg-[#30363d] border border-[#30363d] text-[#c9d1d9] px-2.5 py-1 rounded text-[10px] transition">COPY</button>
                    </div>

                    <div class="flex justify-between items-center bg-[#161b22] border border-[#30363d] p-2.5 rounded">
                        <div>
                            <span id="lbl-buy-tp-title" class="text-[#8b949e] block text-[10px] uppercase">Take Profit (TP) [1:2.0]</span>
                            <span id="buy-tp" class="text-sm font-bold text-[#2ea043]">0.00</span>
                        </div>
                        <button onclick="copyToClipboard('buy-tp', 'Buy Take Profit copied!')" class="bg-[#21262d] hover:bg-[#30363d] border border-[#30363d] text-[#c9d1d9] px-2.5 py-1 rounded text-[10px] transition">COPY</button>
                    </div>
                </div>
            </div>

            <!-- SELL SETUP -->
            <div class="bg-[#0d1117] border border-[#f85149]/40 rounded p-5 space-y-4">
                <div class="flex justify-between items-center border-b border-[#30363d] pb-2">
                    <h2 class="text-xs font-bold text-[#f85149] uppercase tracking-wider">// SELL_SETUP_MATRIX</h2>
                    <span class="text-[10px] bg-[#da3633]/20 text-[#f85149] border border-[#f85149]/30 px-2 py-0.5 rounded font-mono">SHORT</span>
                </div>
                
                <div class="space-y-3 text-xs font-mono">
                    <div class="flex justify-between items-center bg-[#161b22] border border-[#30363d] p-2.5 rounded">
                        <div>
                            <span class="text-[#8b949e] block text-[10px] uppercase">Stop Loss (SL)</span>
                            <span id="sell-sl" class="text-sm font-bold text-[#f85149]">0.00</span>
                        </div>
                        <button onclick="copyToClipboard('sell-sl', 'Sell Stop Loss copied!')" class="bg-[#21262d] hover:bg-[#30363d] border border-[#30363d] text-[#c9d1d9] px-2.5 py-1 rounded text-[10px] transition">COPY</button>
                    </div>

                    <div class="flex justify-between items-center bg-[#161b22] border border-[#30363d] p-2.5 rounded">
                        <div>
                            <span id="lbl-sell-tp-title" class="text-[#8b949e] block text-[10px] uppercase">Take Profit (TP) [1:2.0]</span>
                            <span id="sell-tp" class="text-sm font-bold text-[#2ea043]">0.00</span>
                        </div>
                        <button onclick="copyToClipboard('sell-tp', 'Sell Take Profit copied!')" class="bg-[#21262d] hover:bg-[#30363d] border border-[#30363d] text-[#c9d1d9] px-2.5 py-1 rounded text-[10px] transition">COPY</button>
                    </div>
                </div>
            </div>

        </div>

    </div>
</div>

<script>
    // Terminal Clock
    setInterval(() => {
        const now = new Date();
        document.getElementById('terminal-clock').innerText = now.toLocaleTimeString();
    }, 1000);

    function showToast(message, type = 'success') {
        const container = document.getElementById('toast-container');
        const toast = document.createElement('div');
        const borderColor = type === 'success' ? '#2ea043' : '#f85149';
        toast.className = 'bg-[#161b22] border text-[#c9d1d9] px-4 py-3 rounded shadow-lg text-xs font-mono transition-all';
        toast.style.borderColor = borderColor;
        toast.innerHTML = `<span>${message}</span>`;
        container.appendChild(toast);
        setTimeout(() => toast.remove(), 2500);
    }

    function copyToClipboard(elementId, successMsg) {
        const text = document.getElementById(elementId).innerText;
        navigator.clipboard.writeText(text).then(() => {
            showToast(successMsg);
        }).catch(err => {
            showToast("Failed to copy value.", "error");
        });
    }

    function calculateATR() {
        let atr = parseFloat(document.getElementById('input-atr').value) || 0;
        let multiplier = parseFloat(document.getElementById('input-multiplier').value) || 0;
        let price = parseFloat(document.getElementById('input-price').value) || 0;
        let rrRatio = parseFloat(document.getElementById('input-rr').value) || 1.0;

        let riskDistance = atr * multiplier;
        let rewardDistance = riskDistance * rrRatio;

        // Buy calculations
        let buySL = price - riskDistance;
        let buyTP = price + rewardDistance;

        // Sell calculations
        let sellSL = price + riskDistance;
        let sellTP = price - rewardDistance;

        // Update UI labels for R:R
        document.getElementById('lbl-buy-tp-title').innerText = `Take Profit (TP) [1:${rrRatio}]`;
        document.getElementById('lbl-sell-tp-title').innerText = `Take Profit (TP) [1:${rrRatio}]`;

        // Update UI values
        document.getElementById('buy-sl').innerText = buySL.toFixed(2);
        document.getElementById('buy-tp').innerText = buyTP.toFixed(2);

        document.getElementById('sell-sl').innerText = sellSL.toFixed(2);
        document.getElementById('sell-tp').innerText = sellTP.toFixed(2);
    }

    // Run initial calculation on load
    calculateATR();
</script>
</body>
</html>
<?php
// --- DATABASE CONFIGURATION (Using your existing live DB) ---
$host = 'sql102.infinityfree.com'; 
$dbname = 'if0_40135421_trade_tracker'; 
$username = 'if0_40135421';         
$password = 'WasasCNrbr';                 

try {
    $db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database Connection Failed: " . $e->getMessage());
}

// Default configuration & state for Backtest
$defaultConfig = [
    'startBalance' => 2000,
    'profitTarget' => 2200,
    'terminalFloor' => 1800,
    'winRate' => 50,
    'rrRatio' => 1.5,
    'profitTiers' => [
        ['min' => 2000, 'max' => 2080, 'cushion' => '+$80', 'risk' => 20],
        ['min' => 2080, 'max' => 2140, 'cushion' => '+$60', 'risk' => 15],
        ['min' => 2140, 'max' => 2180, 'cushion' => '+$40', 'risk' => 10],
        ['min' => 2180, 'max' => 2200, 'cushion' => '+$20', 'risk' => 5]
    ],
    'ddTiers' => [
        ['max' => 2000, 'min' => 1920, 'cushion' => '-$80', 'risk' => 20],
        ['max' => 1920, 'min' => 1860, 'cushion' => '-$60', 'risk' => 15],
        ['max' => 1860, 'min' => 1820, 'cushion' => '-$40', 'risk' => 10],
        ['max' => 1820, 'min' => 1800, 'cushion' => '-$20', 'risk' => 5]
    ]
];

// Helper to get state from DB
function getState($db, $key, $default) {
    $stmt = $db->prepare("SELECT value FROM state WHERE `key` = ?");
    $stmt->execute([$key]);
    $res = $stmt->fetch(PDO::FETCH_ASSOC);
    return $res ? json_decode($res['value'], true) : $default;
}

// Helper to save state to DB
function saveState($db, $key, $value) {
    $stmt = $db->prepare("INSERT INTO state (`key`, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value = ?");
    $stmt->execute([$key, json_encode($value), json_encode($value)]);
}

// Initialize DB state for backtest if empty
$config = getState($db, 'backtest_config', $defaultConfig);
$balance = getState($db, 'backtest_balance', $config['startBalance']);

// --- API / AJAX HANDLER ---
if (isset($_GET['action'])) {
    header('Content-Type: application/json');
    $action = $_GET['action'];

    if ($action === 'get_data') {
        $stmt = $db->query("SELECT * FROM backtest_history ORDER BY id DESC");
        $history = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode([
            'config' => $config,
            'balance' => $balance,
            'history' => $history
        ]);
        exit;
    }

    if ($action === 'execute_trade') {
        $input = json_decode(file_get_contents('php://input'), true);
        $isWin = $input['isWin'];
        $rrRatio = isset($input['rrRatio']) ? (float)$input['rrRatio'] : $config['rrRatio'];

        $currentRisk = getTierRisk($balance, $config);
        $rewardAmount = $currentRisk * $rrRatio;
        $pnl = $isWin ? $rewardAmount : -$currentRisk;
        
        $balance += $pnl;
        
        if ($balance <= $config['terminalFloor']) $balance = $config['terminalFloor'];
        if ($balance >= $config['profitTarget']) $balance = $config['profitTarget'];

        saveState($db, 'backtest_balance', $balance);

        $tierDetails = getTierDetails($balance, $config);

        $stmt = $db->prepare("INSERT INTO backtest_history (mode, is_win, risk, pnl, new_balance) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$tierDetails['stepName'], $isWin ? 1 : 0, $currentRisk, $pnl, $balance]);

        echo json_encode(['success' => true, 'balance' => $balance]);
        exit;
    }

    if ($action === 'reset') {
        $balance = $config['startBalance'];
        saveState($db, 'backtest_balance', $balance);
        $db->exec("TRUNCATE TABLE backtest_history");
        echo json_encode(['success' => true, 'balance' => $balance]);
        exit;
    }

    if ($action === 'update_config') {
        $input = json_decode(file_get_contents('php://input'), true);
        $config = $input['config'];
        saveState($db, 'backtest_config', $config);
        
        $balance = $config['startBalance'];
        saveState($db, 'backtest_balance', $balance);
        $db->exec("TRUNCATE TABLE backtest_history");

        echo json_encode(['success' => true]);
        exit;
    }

    if ($action === 'delete_trade') {
        $input = json_decode(file_get_contents('php://input'), true);
        $tradeId = isset($input['id']) ? (int)$input['id'] : 0;

        if ($tradeId > 0) {
            $stmt = $db->prepare("DELETE FROM backtest_history WHERE id = ?");
            $stmt->execute([$tradeId]);

            $stmt = $db->query("SELECT * FROM backtest_history ORDER BY id ASC");
            $remainingTrades = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $currentBal = $config['startBalance'];
            foreach ($remainingTrades as $t) {
                $currentBal += (float)$t['pnl'];
                if ($currentBal <= $config['terminalFloor']) $currentBal = $config['terminalFloor'];
                if ($currentBal >= $config['profitTarget']) $currentBal = $config['profitTarget'];
                
                $upd = $db->prepare("UPDATE backtest_history SET new_balance = ? WHERE id = ?");
                $upd->execute([$currentBal, $t['id']]);
            }

            $balance = $currentBal;
            saveState($db, 'backtest_balance', $balance);

            echo json_encode(['success' => true, 'balance' => $balance]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid ID']);
        }
        exit;
    }
}

function getTierRisk($bal, $cfg) {
    foreach ($cfg['profitTiers'] as $t) {
        if ($bal > $t['min'] && $bal <= $t['max']) return $t['risk'];
    }
    foreach ($cfg['ddTiers'] as $t) {
        if ($bal < $t['max'] && $bal >= $t['min']) return $t['risk'];
    }
    return $cfg['profitTiers'][0]['risk'] ?? 20;
}

function getTierDetails($bal, $cfg) {
    foreach ($cfg['profitTiers'] as $i => $t) {
        if ($bal > $t['min'] && $bal <= $t['max']) {
            return ['mode' => 'Profit Scaling', 'stepName' => 'Profit Step ' . ($i+1), 'type' => 'profit'];
        }
    }
    foreach ($cfg['ddTiers'] as $i => $t) {
        if ($bal < $t['max'] && $bal >= $t['min']) {
            return ['mode' => 'Drawdown Defense', 'stepName' => 'DD Step ' . ($i+1), 'type' => 'dd'];
        }
    }
    return ['mode' => 'Base Balance', 'stepName' => 'Base ($' . $cfg['startBalance'] . ')', 'type' => 'base'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Backtest Terminal // Risk Simulator</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @keyframes terminalPulse {
            0%, 100% { opacity: 1; transform: translateY(0); }
            50% { opacity: 0.5; transform: translateY(-1px); }
        }
        .animate-terminal-pulse {
            animation: terminalPulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }
    </style>
</head>
<body class="bg-[#0b0e14] text-[#8b949e] font-mono min-h-screen p-4 md:p-8 flex items-center justify-center">

<!-- Global Loader Overlay -->
<div id="loading-overlay" class="fixed inset-0 bg-[#0b0e14]/80 backdrop-blur-sm hidden items-center justify-center z-50">
    <div class="w-8 h-8 border-2 border-[#30363d] border-t-[#58a6ff] rounded-full animate-spin"></div>
</div>

<!-- Toast Notification Container -->
<div id="toast-container" class="fixed bottom-4 right-4 z-50 flex flex-col gap-2"></div>

<div class="w-full max-w-6xl bg-[#161b22] border border-[#30363d] rounded-md shadow-2xl overflow-hidden">
    
    <!-- Top Terminal Bar -->
    <div class="bg-[#21262d] px-4 py-3 border-b border-[#30363d] flex justify-between items-center">
        <div class="flex items-center gap-2">
            <span class="w-3 h-3 rounded-full bg-[#f85149] inline-block"></span>
            <span class="w-3 h-3 rounded-full bg-[#e3b341] inline-block"></span>
            <span class="w-3 h-3 rounded-full bg-[#2ea043] inline-block"></span>
            <span class="text-xs text-[#c9d1d9] font-bold ml-2 tracking-wider">BACKTEST_TERMINAL_v2.4 // RISK_SIMULATOR</span>
        </div>
        <div class="text-xs text-[#8b949e]" id="terminal-clock">00:00:00</div>
    </div>

    <div class="p-6 space-y-6">
        
        <!-- Header Nav & Info -->
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-[#30363d] pb-4 gap-4">
            <div>
                <h1 class="text-sm font-bold text-[#c9d1d9] uppercase tracking-wider">Backtest Calculation & Risk Simulator</h1>
                <p class="text-xs text-[#8b949e] mt-1">Status: <span class="text-[#2ea043]">BACKTEST_READY</span></p>
            </div>
            <div class="flex items-center gap-2">
                <a href="index.php" class="bg-[#21262d] hover:bg-[#30363d] border border-[#30363d] text-[#c9d1d9] px-3 py-1.5 rounded text-xs transition">
                    [ RETURN_TO_DASHBOARD ]
                </a>
                    <a href="daily_drawdown_backtest.php" class="bg-[#238636] hover:bg-[#2ea043] text-white px-3 py-1.5 rounded text-xs font-bold transition border border-[#2ea043]">
                    [ Daily Drawdown Backtest ]
                </a>
                    <a href="backtest_chart.php" class="bg-[#238636] hover:bg-[#2ea043] text-white px-3 py-1.5 rounded text-xs font-bold transition border border-[#2ea043]">
                    [ CHARTS ]
                </a>
                <a href="atr_value.php" class="bg-[#238636] hover:bg-[#2ea043] text-white px-3 py-1.5 rounded text-xs font-bold transition border border-[#2ea043]">
                   [ ATR VALUE ]
                </a>
            </div>
        </div>

        <!-- Master Configuration Panel Dropdown -->
        <details class="bg-[#0d1117] border border-[#30363d] rounded p-4 group">
            <summary class="cursor-pointer text-xs font-bold text-[#c9d1d9] uppercase tracking-wider flex justify-between items-center select-none">
                <span>// MASTER_CONFIGURATION_PANEL</span>
                <span class="text-[#58a6ff] text-sm group-open:rotate-180 transition-transform">▼</span>
            </summary>
            
            <div class="mt-4 pt-4 border-t border-[#30363d] space-y-4">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <label class="block text-[11px] font-bold text-[#8b949e] mb-1 uppercase">Starting Balance ($)</label>
                        <input type="number" id="cfg-start-balance" step="10" class="w-full bg-[#161b22] border border-[#30363d] rounded p-2 text-xs text-[#c9d1d9] focus:border-[#58a6ff] outline-none font-mono">
                    </div>
                    <div>
                        <label class="block text-[11px] font-bold text-[#8b949e] mb-1 uppercase">Profit Target ($)</label>
                        <input type="number" id="cfg-profit-target" step="10" class="w-full bg-[#161b22] border border-[#30363d] rounded p-2 text-xs text-[#c9d1d9] focus:border-[#58a6ff] outline-none font-mono">
                    </div>
                    <div>
                        <label class="block text-[11px] font-bold text-[#8b949e] mb-1 uppercase">Terminal Floor ($)</label>
                        <input type="number" id="cfg-terminal-floor" step="10" class="w-full bg-[#161b22] border border-[#30363d] rounded p-2 text-xs text-[#c9d1d9] focus:border-[#58a6ff] outline-none font-mono">
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                    <div>
                        <h3 class="text-xs font-bold text-[#c9d1d9] uppercase tracking-wider mb-2">Profit Scaling Tiers</h3>
                        <div class="border border-[#30363d] rounded overflow-hidden">
                            <table class="w-full text-left text-xs">
                                <thead class="bg-[#161b22] text-[#8b949e] border-b border-[#30363d]">
                                    <tr>
                                        <th class="p-2">Step</th>
                                        <th class="p-2">Min ($)</th>
                                        <th class="p-2">Max ($)</th>
                                        <th class="p-2">Cushion</th>
                                        <th class="p-2">Risk ($)</th>
                                    </tr>
                                </thead>
                                <tbody id="cfg-profit-tbody"></tbody>
                            </table>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-bold text-[#c9d1d9] uppercase tracking-wider mb-2">Drawdown Defense Tiers</h3>
                        <div class="border border-[#30363d] rounded overflow-hidden">
                            <table class="w-full text-left text-xs">
                                <thead class="bg-[#161b22] text-[#8b949e] border-b border-[#30363d]">
                                    <tr>
                                        <th class="p-2">Step</th>
                                        <th class="p-2">Max ($)</th>
                                        <th class="p-2">Min ($)</th>
                                        <th class="p-2">Cushion</th>
                                        <th class="p-2">Risk ($)</th>
                                    </tr>
                                </thead>
                                <tbody id="cfg-dd-tbody"></tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="flex justify-end pt-2">
                    <button onclick="saveConfiguration()" class="bg-[#238636] hover:bg-[#2ea043] text-white font-bold text-xs px-4 py-2 rounded uppercase tracking-wider transition border border-[#2ea043]">
                        Save Config & Reset Backtest DB
                    </button>
                </div>
            </div>
        </details>

        <!-- Status Banners -->
        <div id="alert-banner" class="hidden bg-[#da3633]/20 border border-[#f85149]/40 text-[#f85149] p-3 rounded text-xs font-bold text-center tracking-wider animate-pulse">
            CRITICAL FLOOR REACHED: Drawdown Cap Hit. Backtest Trading Suspended Immediately.
        </div>
        <div id="success-banner" class="hidden bg-[#2ea043]/20 border border-[#2ea043]/40 text-[#2ea043] p-3 rounded text-xs font-bold text-center tracking-wider">
            MAX PROFIT TARGET REACHED: Profit Target Achieved! Backtest Trading Suspended Immediately.
        </div>

        <!-- Main Dashboard Layout Grid -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            <!-- Account Dashboard Card -->
            <div class="bg-[#0d1117] border border-[#30363d] rounded p-5 space-y-4">
                <h2 class="text-xs font-bold text-[#c9d1d9] uppercase tracking-wider border-b border-[#30363d] pb-2">Backtest Account Dashboard</h2>
                
                <div class="space-y-2 text-xs">
                    <div class="flex justify-between items-center py-1 border-b border-[#30363d]/40">
                        <span class="text-[#8b949e]">Current Balance:</span>
                        <span id="lbl-balance" class="text-base font-bold text-[#58a6ff] font-mono">$0.00</span>
                    </div>
                    <div class="flex justify-between items-center py-1 border-b border-[#30363d]/40">
                        <span class="text-[#8b949e]">Framework Mode:</span>
                        <span id="lbl-mode" class="font-bold text-[#c9d1d9]">Base / Neutral</span>
                    </div>
                    <div class="flex justify-between items-center py-1 border-b border-[#30363d]/40">
                        <span class="text-[#8b949e]">Current Tier:</span>
                        <span id="lbl-tier" class="font-bold text-[#c9d1d9]">-</span>
                    </div>
                    <div class="flex justify-between items-center py-1 border-b border-[#30363d]/40">
                        <span class="text-[#8b949e]">Total Trades Executed:</span>
                        <span id="lbl-trade-count" class="font-bold text-[#c9d1d9]">0</span>
                    </div>
                    <div class="flex justify-between items-center py-1">
                        <span class="text-[#8b949e]">Risk / Target Reward:</span>
                        <span id="lbl-risk-reward" class="font-bold text-[#c9d1d9] font-mono">$0.00 / $0.00</span>
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-3 pt-2">
                    <div>
                        <label class="block text-[10px] font-bold text-[#8b949e] mb-1 uppercase">Win Rate (%) [Random]</label>
                        <input type="number" id="input-winrate" value="50" min="1" max="99" class="w-full bg-[#161b22] border border-[#30363d] rounded p-2 text-xs text-[#c9d1d9] focus:border-[#58a6ff] outline-none font-mono">
                    </div>
                    <div>
                        <label class="block text-[10px] font-bold text-[#8b949e] mb-1 uppercase">Risk-to-Reward (1:X)</label>
                        <input type="number" id="input-rr" value="1.5" step="0.1" min="0.1" oninput="updateUI()" class="w-full bg-[#161b22] border border-[#30363d] rounded p-2 text-xs text-[#c9d1d9] focus:border-[#58a6ff] outline-none font-mono">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-3 pt-2">
                    <button id="btn-win" onclick="makeTrade(true)" class="bg-[#238636] hover:bg-[#2ea043] text-white font-bold text-xs py-2.5 rounded uppercase tracking-wider transition border border-[#2ea043]">
                        Submit Win
                    </button>
                    <button id="btn-loss" onclick="makeTrade(false)" class="bg-[#da3633]/20 hover:bg-[#da3633]/30 border border-[#f85149]/40 text-[#f85149] font-bold text-xs py-2.5 rounded uppercase tracking-wider transition">
                        Submit Loss
                    </button>
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <button id="trade-btn" onclick="makeRandomTrade()" class="bg-[#21262d] hover:bg-[#30363d] border border-[#30363d] text-[#c9d1d9] font-bold text-xs py-2 rounded uppercase tracking-wider transition">
                        Generate Random
                    </button>
                    <button id="reset-btn" onclick="resetDatabase()" class="bg-[#da3633]/10 hover:bg-[#da3633]/20 border border-[#f85149]/30 text-[#f85149] font-bold text-xs py-2 rounded uppercase tracking-wider transition">
                        Reset DB
                    </button>
                </div>
            </div>

            <!-- Profit Scaling Ladder View -->
            <div class="bg-[#0d1117] border border-[#30363d] rounded p-5 space-y-4">
                <h2 class="text-xs font-bold text-[#c9d1d9] uppercase tracking-wider border-b border-[#30363d] pb-2">Profit Scaling Ladder</h2>
                <div class="border border-[#30363d] rounded overflow-hidden">
                    <table class="w-full text-left text-xs">
                        <thead class="bg-[#161b22] text-[#8b949e] border-b border-[#30363d]">
                            <tr>
                                <th class="p-2.5">Tier</th>
                                <th class="p-2.5">Balance Range</th>
                                <th class="p-2.5">Cushion</th>
                                <th class="p-2.5">Risk / Trade</th>
                            </tr>
                        </thead>
                        <tbody id="profit-ladder-body"></tbody>
                    </table>
                </div>
            </div>

        </div>

        <!-- Second Row (Drawdown & History) -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            <!-- Drawdown Framework Ladder -->
            <div class="bg-[#0d1117] border border-[#30363d] rounded p-5 space-y-4">
                <h2 class="text-xs font-bold text-[#c9d1d9] uppercase tracking-wider border-b border-[#30363d] pb-2">Drawdown Framework Ladder</h2>
                <div class="border border-[#30363d] rounded overflow-hidden">
                    <table class="w-full text-left text-xs">
                        <thead class="bg-[#161b22] text-[#8b949e] border-b border-[#30363d]">
                            <tr>
                                <th class="p-2.5">Tier</th>
                                <th class="p-2.5">Balance Range</th>
                                <th class="p-2.5">Cushion</th>
                                <th class="p-2.5">Risk / Trade</th>
                            </tr>
                        </thead>
                        <tbody id="dd-ladder-body"></tbody>
                    </table>
                </div>
            </div>

            <!-- Trade History (Database) -->
            <div class="bg-[#0d1117] border border-[#30363d] rounded p-5 space-y-4">
                <h2 class="text-xs font-bold text-[#c9d1d9] uppercase tracking-wider border-b border-[#30363d] pb-2">Backtest History (Database)</h2>
                <div class="border border-[#30363d] rounded overflow-hidden max-h-[280px] overflow-y-auto">
                    <table class="w-full text-left text-xs">
                        <thead class="bg-[#161b22] text-[#8b949e] border-b border-[#30363d] sticky top-0">
                            <tr>
                                <th class="p-2.5">#</th>
                                <th class="p-2.5">Mode</th>
                                <th class="p-2.5">Outcome</th>
                                <th class="p-2.5">Risk</th>
                                <th class="p-2.5">PnL</th>
                                <th class="p-2.5">Balance</th>
                                <th class="p-2.5">Action</th>
                            </tr>
                        </thead>
                        <tbody id="history-body">
                            <tr><td colspan="7" class="p-4 text-center text-[#8b949e]">Loading history...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

    </div>
</div>

<script>
    let appData = null;

    // Terminal Clock
    setInterval(() => {
        const now = new Date();
        document.getElementById('terminal-clock').innerText = now.toLocaleTimeString();
    }, 1000);

    function showLoader() {
        document.getElementById('loading-overlay').classList.remove('hidden');
        document.getElementById('loading-overlay').classList.add('flex');
    }

    function hideLoader() {
        document.getElementById('loading-overlay').classList.remove('flex');
        document.getElementById('loading-overlay').classList.add('hidden');
    }

    function showToast(message, type = 'success') {
        const container = document.getElementById('toast-container');
        const toast = document.createElement('div');
        const borderColor = type === 'success' ? '#2ea043' : '#f85149';
        toast.className = 'bg-[#161b22] border text-[#c9d1d9] px-4 py-3 rounded shadow-lg text-xs font-mono transition-all';
        toast.style.borderColor = borderColor;
        toast.innerHTML = `<span>${message}</span>`;
        container.appendChild(toast);
        setTimeout(() => toast.remove(), 3000);
    }

    async function loadData(showSpin = false) {
        if(showSpin) showLoader();
        try {
            let response = await fetch('?action=get_data');
            appData = await response.json();
            populateConfigUI();
            updateUI();
        } catch(e) {
            showToast("Failed to fetch data from database.", "error");
        } finally {
            if(showSpin) hideLoader();
        }
    }

    function populateConfigUI() {
        let cfg = appData.config;
        document.getElementById('cfg-start-balance').value = cfg.startBalance;
        document.getElementById('cfg-profit-target').value = cfg.profitTarget;
        document.getElementById('cfg-terminal-floor').value = cfg.terminalFloor;

        let pTbody = document.getElementById('cfg-profit-tbody');
        pTbody.innerHTML = '';
        cfg.profitTiers.forEach((t, i) => {
            pTbody.innerHTML += `
                <tr class="border-b border-[#30363d]/40">
                    <td class="p-2">Step ${i+1}</td>
                    <td class="p-2"><input type="number" class="w-full bg-[#161b22] border border-[#30363d] rounded p-1 text-xs text-[#c9d1d9] p-min font-mono" value="${t.min}"></td>
                    <td class="p-2"><input type="number" class="w-full bg-[#161b22] border border-[#30363d] rounded p-1 text-xs text-[#c9d1d9] p-max font-mono" value="${t.max}"></td>
                    <td class="p-2"><input type="text" class="w-full bg-[#161b22] border border-[#30363d] rounded p-1 text-xs text-[#c9d1d9] p-cushion font-mono" value="${t.cushion}"></td>
                    <td class="p-2"><input type="number" class="w-full bg-[#161b22] border border-[#30363d] rounded p-1 text-xs text-[#c9d1d9] p-risk font-mono" value="${t.risk}" step="0.5"></td>
                </tr>`;
        });

        let dTbody = document.getElementById('cfg-dd-tbody');
        dTbody.innerHTML = '';
        cfg.ddTiers.forEach((t, i) => {
            dTbody.innerHTML += `
                <tr class="border-b border-[#30363d]/40">
                    <td class="p-2">Step ${i+1}</td>
                    <td class="p-2"><input type="number" class="w-full bg-[#161b22] border border-[#30363d] rounded p-1 text-xs text-[#c9d1d9] d-max font-mono" value="${t.max}"></td>
                    <td class="p-2"><input type="number" class="w-full bg-[#161b22] border border-[#30363d] rounded p-1 text-xs text-[#c9d1d9] d-min font-mono" value="${t.min}"></td>
                    <td class="p-2"><input type="text" class="w-full bg-[#161b22] border border-[#30363d] rounded p-1 text-xs text-[#c9d1d9] d-cushion font-mono" value="${t.cushion}"></td>
                    <td class="p-2"><input type="number" class="w-full bg-[#161b22] border border-[#30363d] rounded p-1 text-xs text-[#c9d1d9] d-risk font-mono" value="${t.risk}" step="0.5"></td>
                </tr>`;
        });
    }

    function getTierDetails(currentBalance, cfg) {
        for (let i = 0; i < cfg.profitTiers.length; i++) {
            let t = cfg.profitTiers[i];
            if (currentBalance > t.min && currentBalance <= t.max) {
                return { mode: "Profit Scaling", stepName: `Profit Step ${i+1}`, activeId: `profit-step-${i}`, type: "profit", risk: t.risk };
            }
        }
        for (let i = 0; i < cfg.ddTiers.length; i++) {
            let t = cfg.ddTiers[i];
            if (currentBalance < t.max && currentBalance >= t.min) {
                return { mode: "Drawdown Defense", stepName: `DD Step ${i+1}`, activeId: `dd-step-${i}`, type: "dd", risk: t.risk };
            }
        }
        return { mode: "Base Balance", stepName: `Base ($${cfg.startBalance})`, activeId: null, type: "base", risk: cfg.profitTiers[0].risk };
    }

    function updateUI() {
        let cfg = appData.config;
        let bal = appData.balance;
        let history = appData.history;

        let tier = getTierDetails(bal, cfg);
        let rrRatio = parseFloat(document.getElementById('input-rr').value) || cfg.rrRatio;
        let rewardAmount = tier.risk * rrRatio;

        document.getElementById('lbl-balance').innerText = `$${Number(bal).toFixed(2)}`;
        let modeEl = document.getElementById('lbl-mode');
        modeEl.innerText = tier.mode;
        modeEl.className = tier.type === 'profit' ? "font-bold text-[#2ea043]" : (tier.type === 'dd' ? "font-bold text-[#f85149]" : "font-bold text-[#c9d1d9]");

        document.getElementById('lbl-tier').innerText = tier.stepName;
        document.getElementById('lbl-trade-count').innerText = history.length;
        document.getElementById('lbl-risk-reward').innerText = `$${tier.risk.toFixed(2)} / $${rewardAmount.toFixed(2)}`;

        let pBody = document.getElementById('profit-ladder-body');
        pBody.innerHTML = '';
        cfg.profitTiers.forEach((t, i) => {
            let activeClass = (tier.activeId === `profit-step-${i}`) ? 'bg-[#2ea043]/10 border-l-2 border-[#2ea043]' : 'border-b border-[#30363d]/40';
            pBody.innerHTML += `<tr id="profit-step-${i}" class="${activeClass}"><td class="p-2.5">Step ${i+1}</td><td class="p-2.5">$${t.min} - $${t.max}</td><td class="p-2.5">${t.cushion}</td><td class="p-2.5 font-mono">$${t.risk.toFixed(2)}</td></tr>`;
        });

        let dBody = document.getElementById('dd-ladder-body');
        dBody.innerHTML = '';
        cfg.ddTiers.forEach((t, i) => {
            let activeClass = (tier.activeId === `dd-step-${i}`) ? 'bg-[#f85149]/10 border-l-2 border-[#f85149]' : 'border-b border-[#30363d]/40';
            dBody.innerHTML += `<tr id="dd-step-${i}" class="${activeClass}"><td class="p-2.5">Step ${i+1}</td><td class="p-2.5">$${t.max} - $${t.min}</td><td class="p-2.5">${t.cushion}</td><td class="p-2.5 font-mono">$${t.risk.toFixed(2)}</td></tr>`;
        });

        let hBody = document.getElementById('history-body');
        if (history.length === 0) {
            hBody.innerHTML = `<tr><td colspan="7" class="p-4 text-center text-[#8b949e]">No trades logged yet.</td></tr>`;
        } else {
            let html = '';
            history.forEach((h, index) => {
                let isWin = h.is_win == 1;
                let outcomeLabel = isWin ? '<span class="text-[#2ea043] font-bold">WIN</span>' : '<span class="text-[#f85149] font-bold">LOSS</span>';
                let pnlFormatted = isWin ? `+$${Number(h.pnl).toFixed(2)}` : `-$${Math.abs(h.pnl).toFixed(2)}`;
                let pnlClass = isWin ? 'text-[#2ea043] font-mono' : 'text-[#f85149] font-mono';
                let tradeNum = history.length - index;

                html += `<tr class="border-b border-[#30363d]/40">
                    <td class="p-2.5 font-mono">#${tradeNum}</td>
                    <td class="p-2.5">${h.mode}</td>
                    <td class="p-2.5">${outcomeLabel}</td>
                    <td class="p-2.5 font-mono">$${Number(h.risk).toFixed(2)}</td>
                    <td class="p-2.5 ${pnlClass}">${pnlFormatted}</td>
                    <td class="p-2.5 font-mono">$${Number(h.new_balance).toFixed(2)}</td>
                    <td class="p-2.5">
                        <button class="bg-[#da3633]/20 hover:bg-[#da3633]/30 text-[#f85149] border border-[#f85149]/40 px-2 py-1 rounded text-[10px] font-bold transition" onclick="deleteTrade(${h.id})" title="Delete Trade">
                            DEL
                        </button>
                    </td>
                </tr>`;
            });
            hBody.innerHTML = html;
        }

        if (bal <= cfg.terminalFloor || bal >= cfg.profitTarget) {
            document.getElementById('trade-btn').disabled = true;
            document.getElementById('btn-win').disabled = true;
            document.getElementById('btn-loss').disabled = true;
            if (bal <= cfg.terminalFloor) document.getElementById('alert-banner').classList.remove('hidden');
            if (bal >= cfg.profitTarget) document.getElementById('success-banner').classList.remove('hidden');
        } else {
            document.getElementById('trade-btn').disabled = false;
            document.getElementById('btn-win').disabled = false;
            document.getElementById('btn-loss').disabled = false;
            document.getElementById('alert-banner').classList.add('hidden');
            document.getElementById('success-banner').classList.add('hidden');
        }
    }

    async function makeTrade(isWin) {
        showLoader();
        try {
            let response = await fetch('?action=execute_trade', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    isWin: isWin,
                    rrRatio: parseFloat(document.getElementById('input-rr').value)
                })
            });
            let result = await response.json();
            if (result.success) {
                showToast(isWin ? "Trade Win Logged." : "Trade Loss Logged.");
                await loadData();
            } else {
                showToast("Failed to execute trade.", "error");
            }
        } catch(e) {
            showToast("Network error during trade execution.", "error");
        } finally {
            hideLoader();
        }
    }

    function makeRandomTrade() {
        let winRate = parseFloat(document.getElementById('input-winrate').value) || 50;
        let randomRoll = Math.random() * 100;
        let isWin = randomRoll < winRate;
        makeTrade(isWin);
    }

    async function resetDatabase() {
        if(!confirm("Are you sure you want to wipe backtest trade history and reset balance?")) return;
        showLoader();
        try {
            let response = await fetch('?action=reset');
            let result = await response.json();
            if(result.success) {
                showToast("Backtest database reset successfully.");
                await loadData();
            }
        } catch(e) {
            showToast("Failed to reset backtest database.", "error");
        } finally {
            hideLoader();
        }
    }

    async function saveConfiguration() {
        showLoader();
        try {
            let cfg = JSON.parse(JSON.stringify(appData.config));
            cfg.startBalance = parseFloat(document.getElementById('cfg-start-balance').value);
            cfg.profitTarget = parseFloat(document.getElementById('cfg-profit-target').value);
            cfg.terminalFloor = parseFloat(document.getElementById('cfg-terminal-floor').value);

            let pRows = document.querySelectorAll('#cfg-profit-tbody tr');
            pRows.forEach((row, i) => {
                cfg.profitTiers[i].min = parseFloat(row.querySelector('.p-min').value);
                cfg.profitTiers[i].max = parseFloat(row.querySelector('.p-max').value);
                cfg.profitTiers[i].cushion = row.querySelector('.p-cushion').value;
                cfg.profitTiers[i].risk = parseFloat(row.querySelector('.p-risk').value);
            });

            let dRows = document.querySelectorAll('#cfg-dd-tbody tr');
            dRows.forEach((row, i) => {
                cfg.ddTiers[i].max = parseFloat(row.querySelector('.d-max').value);
                cfg.ddTiers[i].min = parseFloat(row.querySelector('.d-min').value);
                cfg.ddTiers[i].cushion = row.querySelector('.d-cushion').value;
                cfg.ddTiers[i].risk = parseFloat(row.querySelector('.d-risk').value);
            });

            let response = await fetch('?action=update_config', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ config: cfg })
            });
            let result = await response.json();
            if(result.success) {
                showToast("Configuration updated successfully.");
                await loadData();
            }
        } catch(e) {
            showToast("Failed to update configuration.", "error");
        } finally {
            hideLoader();
        }
    }

    async function deleteTrade(id) {
        if(!confirm("Are you sure you want to delete this backtest trade?")) return;
        showLoader();
        try {
            let response = await fetch('?action=delete_trade', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: id })
            });
            let result = await response.json();
            if(result.success) {
                showToast("Trade deleted and balances recalculated.");
                await loadData();
            }
        } catch(e) {
            showToast("Failed to delete trade.", "error");
        } finally {
            hideLoader();
        }
    }

    // Initial load on page startup
    loadData(true);
</script>
</body>
</html>
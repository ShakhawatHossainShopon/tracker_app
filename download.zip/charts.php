<?php
// --- DATABASE CONFIGURATION ---
$host = 'sql102.infinityfree.com';
$dbname = 'if0_40135421_trade_tracker';
$username = 'if0_40135421';
$password = 'WasasCNrbr';

try {
    $db = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $username,
        $password
    );

    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e) {
    die("Database Connection Failed: " . $e->getMessage());
}


// ============================================================
// FETCH CONFIG & HISTORY
// ============================================================

$stmt = $db->prepare("SELECT value FROM state WHERE `key` = 'config'");
$stmt->execute();

$res = $stmt->fetch(PDO::FETCH_ASSOC);

$config = $res
    ? json_decode($res['value'], true)
    : ['startBalance' => 2000];


// Make sure startBalance exists
$startBalance = isset($config['startBalance'])
    ? (float)$config['startBalance']
    : 2000;


// Fetch trade history
$stmt = $db->query("SELECT * FROM trade_history ORDER BY id ASC");

$history = $stmt->fetchAll(PDO::FETCH_ASSOC);


// ============================================================
// ADVANCED ANALYTICS
// ============================================================

$totalTrades = count($history);

$wins = 0;
$losses = 0;

$totalProfit = 0;
$totalLoss = 0;

$maxWin = 0;
$maxLoss = 0;

$consecutiveWins = 0;
$consecutiveLosses = 0;

$maxConsecutiveWins = 0;
$maxConsecutiveLosses = 0;

$riskRewardSum = 0;
$rrCount = 0;


// ============================================================
// EQUITY DATA
// ============================================================

$labels = ['Start'];

$balanceData = [$startBalance];

$currentBal = $startBalance;

$peakBal = $currentBal;

$maxDrawdownUSD = 0;
$maxDrawdownPercent = 0;


// Balance history
$balancePoints = [$currentBal];


// ============================================================
// PROCESS TRADES
// ============================================================

foreach ($history as $index => $trade) {

    $isWin = isset($trade['is_win']) && $trade['is_win'] == 1;

    $pnl = isset($trade['pnl'])
        ? (float)$trade['pnl']
        : 0;


    // --------------------------------------------------------
    // R:R
    // --------------------------------------------------------

    if (
        isset($trade['risk_reward']) &&
        (float)$trade['risk_reward'] > 0
    ) {

        $riskRewardSum += (float)$trade['risk_reward'];

        $rrCount++;
    }


    // --------------------------------------------------------
    // WIN / LOSS
    // --------------------------------------------------------

    if ($isWin) {

        $wins++;

        $totalProfit += $pnl;

        if ($pnl > $maxWin) {
            $maxWin = $pnl;
        }


        $consecutiveWins++;

        $consecutiveLosses = 0;


        if ($consecutiveWins > $maxConsecutiveWins) {
            $maxConsecutiveWins = $consecutiveWins;
        }

    } else {

        $losses++;

        $totalLoss += abs($pnl);

        if (abs($pnl) > $maxLoss) {
            $maxLoss = abs($pnl);
        }


        $consecutiveLosses++;

        $consecutiveWins = 0;


        if ($consecutiveLosses > $maxConsecutiveLosses) {
            $maxConsecutiveLosses = $consecutiveLosses;
        }
    }


    // --------------------------------------------------------
    // BALANCE
    // --------------------------------------------------------

    if (isset($trade['new_balance'])) {

        $currentBal = (float)$trade['new_balance'];

    } else {

        $currentBal += $pnl;
    }


    $balancePoints[] = $currentBal;


    // --------------------------------------------------------
    // DRAW DOWN
    // --------------------------------------------------------

    if ($currentBal > $peakBal) {

        $peakBal = $currentBal;
    }


    $drawdownUSD = $peakBal - $currentBal;


    $drawdownPercent = $peakBal > 0
        ? ($drawdownUSD / $peakBal) * 100
        : 0;


    if ($drawdownUSD > $maxDrawdownUSD) {

        $maxDrawdownUSD = $drawdownUSD;
    }


    if ($drawdownPercent > $maxDrawdownPercent) {

        $maxDrawdownPercent = $drawdownPercent;
    }


    // --------------------------------------------------------
    // CHART LABELS
    // --------------------------------------------------------

    $labels[] = 'T#' . ($index + 1);

    $balanceData[] = $currentBal;
}


// ============================================================
// FINAL CALCULATIONS
// ============================================================

$winRate = $totalTrades > 0
    ? ($wins / $totalTrades) * 100
    : 0;


$netPnL = $currentBal - $startBalance;


$avgWin = $wins > 0
    ? $totalProfit / $wins
    : 0;


$avgLoss = $losses > 0
    ? $totalLoss / $losses
    : 0;


$profitFactor = $totalLoss > 0
    ? $totalProfit / $totalLoss
    : ($totalProfit > 0 ? 99.9 : 0);


$avgRR = $rrCount > 0
    ? $riskRewardSum / $rrCount
    : 0;


// ============================================================
// CONSISTENCY SCORE
// ============================================================

// ============================================================
// PROP-FIRM CONSISTENCY
// Biggest Winning Trade / Total Net Profit
// ============================================================

$consistencyScore = 0;

if ($netPnL > 0 && $maxWin > 0) {

    $consistencyScore = (
        $maxWin / $netPnL
    ) * 100;

    $consistencyScore = round(
        $consistencyScore,
        1
    );
}
// ============================================================
// JSON DATA FOR CHART
// ============================================================

$chartLabels = json_encode(
    $labels,
    JSON_UNESCAPED_SLASHES
);

$chartBalanceData = json_encode(
    $balanceData,
    JSON_NUMERIC_CHECK
);

$chartStartBalance = json_encode(
    $startBalance
);

?>
<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Terminal Dashboard | Performance Analytics
    </title>


    <!-- =====================================================
         GOOGLE FONTS
    ====================================================== -->

    <link
        href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@500;700&display=swap"
        rel="stylesheet"
    >


    <!-- =====================================================
         CHART.JS
    ====================================================== -->

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>


    <!-- =====================================================
         STYLE
    ====================================================== -->

    <style>

        :root {

            --bg-base: #060913;

            --bg-surface: #0f172a;

            --bg-surface-hover: #1e293b;

            --border-subtle:
                rgba(255, 255, 255, 0.06);

            --border-highlight:
                rgba(56, 189, 248, 0.2);


            --text-main: #f8fafc;

            --text-muted: #64748b;

            --text-dimmed: #94a3b8;


            --accent-blue: #38bdf8;

            --accent-glow:
                rgba(56, 189, 248, 0.15);


            --success: #10b981;

            --success-glow:
                rgba(16, 185, 129, 0.1);


            --danger: #f43f5e;

            --danger-glow:
                rgba(244, 63, 94, 0.1);


            --warning: #fbbf24;


            --radius-lg: 16px;

            --radius-md: 12px;


            --transition:
                all 0.25s cubic-bezier(
                    0.4,
                    0,
                    0.2,
                    1
                );
        }


        * {

            box-sizing: border-box;
        }


        body {

            font-family:
                'Plus Jakarta Sans',
                sans-serif;

            background-color:
                var(--bg-base);

            color:
                var(--text-main);

            margin: 0;

            padding: 40px 20px;

            display: flex;

            justify-content: center;

            min-height: 100vh;


            background-image:

                radial-gradient(
                    circle at 10% 20%,
                    rgba(56, 189, 248, 0.03) 0%,
                    transparent 40%
                ),

                radial-gradient(
                    circle at 90% 80%,
                    rgba(16, 185, 129, 0.03) 0%,
                    transparent 40%
                );
        }


        .container {

            width: 100%;

            max-width: 1280px;
        }


        /* =====================================================
           HEADER
        ====================================================== */

        header {

            display: flex;

            justify-content:
                space-between;

            align-items: center;

            margin-bottom: 35px;

            position: relative;

            background:
                var(--bg-surface);

            padding: 24px 30px;

            border-radius:
                var(--radius-lg);

            border:
                1px solid var(--border-subtle);

            box-shadow:
                0 4px 20px -2px
                rgba(0, 0, 0, 0.5);
        }


        .header-content h1 {

            margin:
                0 0 6px 0;

            font-size: 22px;

            font-weight: 700;

            color:
                var(--text-main);

            letter-spacing:
                -0.3px;
        }


        .header-content p.subtitle {

            margin: 0;

            color:
                var(--text-muted);

            font-size: 13px;
        }


        .back-btn {

            background-color:
                var(--bg-surface-hover);

            color:
                var(--text-dimmed);

            padding:
                10px 18px;

            border-radius: 10px;

            text-decoration: none;

            font-weight: 600;

            font-size: 13px;

            border:
                1px solid var(--border-subtle);

            transition:
                var(--transition);

            display: flex;

            align-items: center;

            gap: 8px;
        }


        .back-btn:hover {

            background-color:
                #334155;

            color:
                var(--text-main);

            border-color:
                var(--border-highlight);
        }


        /* =====================================================
           STATS
        ====================================================== */

        .stats-grid {

            display: grid;

            grid-template-columns:
                repeat(
                    auto-fit,
                    minmax(260px, 1fr)
                );

            gap: 20px;

            margin-bottom: 30px;
        }


        .stat-card {

            background-color:
                var(--bg-surface);

            border:
                1px solid var(--border-subtle);

            border-radius:
                var(--radius-lg);

            padding: 24px;

            position: relative;

            overflow: hidden;

            transition:
                var(--transition);
        }


        .stat-card:hover {

            border-color:
                var(--border-highlight);

            transform:
                translateY(-2px);
        }


        .stat-card::before {

            content: '';

            position: absolute;

            top: 0;

            left: 0;

            width: 4px;

            height: 100%;

            background:
                var(--accent-blue);
        }


        .stat-card.win-accent::before {

            background:
                var(--success);
        }


        .stat-card.loss-accent::before {

            background:
                var(--danger);
        }


        .stat-card.warning-accent::before {

            background:
                var(--warning);
        }


        .stat-card h3 {

            margin:
                0 0 10px 0;

            font-size: 11px;

            text-transform:
                uppercase;

            letter-spacing:
                1px;

            color:
                var(--text-muted);

            font-weight: 600;
        }


        .stat-card .value {

            font-family:
                'JetBrains Mono',
                monospace;

            font-size: 26px;

            font-weight: 700;

            letter-spacing:
                -0.5px;
        }


        .text-win {

            color:
                var(--success);
        }


        .text-loss {

            color:
                var(--danger);
        }


        .text-warning {

            color:
                var(--warning);
        }


        .text-accent {

            color:
                var(--accent-blue);
        }


        /* =====================================================
           METRIC TABLES
        ====================================================== */

        .metrics-table-grid {

            display: grid;

            grid-template-columns:
                repeat(
                    auto-fit,
                    minmax(400px, 1fr)
                );

            gap: 24px;

            margin-bottom: 30px;
        }


        .card {

            background-color:
                var(--bg-surface);

            border:
                1px solid var(--border-subtle);

            border-radius:
                var(--radius-lg);

            padding: 28px;

            box-shadow:
                0 10px 25px -5px
                rgba(0, 0, 0, 0.4);
        }


        .card h2 {

            margin:
                0 0 20px 0;

            font-size: 13px;

            text-transform:
                uppercase;

            letter-spacing:
                0.8px;

            color:
                var(--text-dimmed);

            border-bottom:
                1px solid
                var(--border-subtle);

            padding-bottom: 14px;

            font-weight: 600;

            display: flex;

            align-items: center;

            gap: 8px;
        }


        .metric-row {

            display: flex;

            justify-content:
                space-between;

            align-items: center;

            padding: 12px 0;

            border-bottom:
                1px solid
                var(--border-subtle);

            font-size: 14px;
        }


        .metric-row:last-child {

            border-bottom: none;

            padding-bottom: 0;
        }


        .metric-label {

            color:
                var(--text-muted);

            font-weight: 500;
        }


        .metric-value {

            font-family:
                'JetBrains Mono',
                monospace;

            font-weight: 600;

            color:
                var(--text-main);
        }


        /* =====================================================
           ADVANCED CHART CARD
        ====================================================== */

        .chart-card {

            background-color:
                var(--bg-surface);

            border:
                1px solid var(--border-subtle);

            border-radius:
                var(--radius-lg);

            padding: 28px;

            box-shadow:
                0 10px 25px -5px
                rgba(0, 0, 0, 0.4);

            overflow: hidden;
        }


        .chart-header {

            display: flex;

            justify-content:
                space-between;

            align-items:
                flex-start;

            gap: 20px;

            margin-bottom: 10px;
        }


        .chart-title-wrapper h2 {

            margin: 0;

            font-size: 15px;

            text-transform:
                uppercase;

            letter-spacing:
                0.8px;

            color:
                var(--text-dimmed);

            font-weight: 700;
        }


        .chart-title-wrapper p {

            margin:
                7px 0 0;

            color:
                var(--text-muted);

            font-size: 11px;
        }


        .chart-legend-info {

            display: flex;

            align-items: center;

            gap: 14px;

            flex-wrap: wrap;

            justify-content:
                flex-end;
        }


        .chart-status {

            display: flex;

            align-items: center;

            gap: 6px;

            color:
                var(--text-muted);

            font-size: 10px;

            font-weight: 600;
        }


        .chart-dot {

            width: 7px;

            height: 7px;

            border-radius: 50%;
        }


        .chart-dot.green {

            background:
                var(--success);

            box-shadow:
                0 0 8px
                rgba(16, 185, 129, 0.55);
        }


        .chart-dot.red {

            background:
                var(--danger);

            box-shadow:
                0 0 8px
                rgba(244, 63, 94, 0.55);
        }


        .chart-dot.yellow {

            background:
                var(--warning);

            box-shadow:
                0 0 8px
                rgba(251, 191, 36, 0.55);
        }


        .chart-container {

            position: relative;

            height: 460px;

            width: 100%;

            margin-top: 15px;
        }


        /* =====================================================
           CHART FOOTER
        ====================================================== */

        .chart-footer {

            display: grid;

            grid-template-columns:
                repeat(
                    4,
                    minmax(0, 1fr)
                );

            gap: 12px;

            margin-top: 15px;

            padding-top: 18px;

            border-top:
                1px solid
                var(--border-subtle);
        }


        .chart-footer-item {

            padding:
                10px 12px;

            background:
                rgba(255,255,255,0.015);

            border:
                1px solid
                rgba(255,255,255,0.035);

            border-radius: 9px;
        }


        .chart-footer-label {

            display: block;

            color:
                var(--text-muted);

            font-size: 9px;

            text-transform:
                uppercase;

            letter-spacing:
                0.8px;

            margin-bottom: 5px;
        }


        .chart-footer-value {

            font-family:
                'JetBrains Mono',
                monospace;

            font-size: 12px;

            font-weight: 700;

            color:
                var(--text-main);
        }


        /* =====================================================
           RESPONSIVE
        ====================================================== */

        @media (max-width: 768px) {

            body {

                padding: 15px;
            }


            header {

                flex-direction:
                    column;

                align-items:
                    flex-start;

                gap: 15px;

                padding: 20px;
            }


            .metrics-table-grid {

                grid-template-columns:
                    100%;
            }


            .chart-header {

                flex-direction:
                    column;
            }


            .chart-legend-info {

                justify-content:
                    flex-start;
            }


            .chart-container {

                height: 380px;
            }


            .chart-footer {

                grid-template-columns:
                    repeat(2, 1fr);
            }
        }


        @media (max-width: 480px) {

            .chart-container {

                height: 330px;
            }


            .chart-footer {

                grid-template-columns:
                    1fr 1fr;
            }


            .stat-card .value {

                font-size: 22px;
            }
        }

    </style>

</head>


<body>


<div class="container">


    <!-- =====================================================
         HEADER
    ====================================================== -->

    <header>

        <div class="header-content">

            <h1>
                Advanced Performance Analytics
            </h1>

            <p class="subtitle">
                Real-time trading execution profile, expectancy, & capital curves
            </p>

        </div>


        <a
            href="calculation.php"
            class="back-btn"
        >
            &larr; Return to Terminal
        </a>

    </header>


    <!-- =====================================================
         OVERVIEW STATS
    ====================================================== -->

    <div class="stats-grid">


        <!-- NET PNL -->

        <div class="stat-card
            <?php echo $netPnL >= 0
                ? 'win-accent'
                : 'loss-accent';
            ?>"
        >

            <h3>
                Total Net P&L
            </h3>


            <div class="value
                <?php echo $netPnL >= 0
                    ? 'text-win'
                    : 'text-loss';
                ?>"
            >

                <?php

                echo (
                    $netPnL >= 0
                        ? '+$'
                        : '-$'
                )
                .
                number_format(
                    abs($netPnL),
                    2
                );
				
                ?>
                
				&nbsp;<?php echo ($netPnL >= 0 ? '+' : '') . number_format(($netPnL / $startBalance) * 100, 2); ?>%
            </div>

        </div>


        <!-- WIN RATE -->

        <div class="stat-card win-accent">

            <h3>
                Win Rate Performance
            </h3>


            <div class="value text-accent">

                <?php

                echo number_format(
                    $winRate,
                    1
                );

                ?>%

            </div>

        </div>


        <!-- MAX DRAWDOWN -->

        <div class="stat-card loss-accent">

            <h3>
                Maximum Drawdown
            </h3>


            <div class="value text-loss">

                -$

                <?php

                echo number_format(
                    $maxDrawdownUSD,
                    2
                );

                ?>


                <span style="font-size:16px;">

                    (

                    <?php

                    echo number_format(
                        $maxDrawdownPercent,
                        1
                    );

                    ?>%

                    )

                </span>

            </div>

        </div>


        <!-- CONSISTENCY -->

        <div class="stat-card warning-accent">

            <h3>
                Consistency Score
            </h3>


            <div class="value text-warning">

                   <?php echo number_format($consistencyScore, 1); ?>%

            </div>

        </div>

    </div>


    <!-- =====================================================
         METRICS
    ====================================================== -->

    <div class="metrics-table-grid">


        <!-- PERFORMANCE -->

        <div class="card">

            <h2>
                Performance & Expectancy Matrix
            </h2>


            <div class="metric-row">

                <span class="metric-label">
                    Total Volume Distribution
                </span>


                <span class="metric-value">

                    <?php echo $totalTrades; ?>

                    Trades

                    (

                    <span class="text-win">

                        <?php echo $wins; ?>W

                    </span>

                    /

                    <span class="text-loss">

                        <?php echo $losses; ?>L

                    </span>

                    )

                </span>

            </div>


            <div class="metric-row">

                <span class="metric-label">
                    Profit Factor Ratio
                </span>


                <span class="metric-value">

                    <?php

                    echo number_format(
                        $profitFactor,
                        2
                    );

                    ?>

                </span>

            </div>


            <div class="metric-row">

                <span class="metric-label">
                    Average Risk to Reward (R:R)
                </span>


                <span class="metric-value">

                    <?php

                    echo number_format(
                        $avgRR,
                        2
                    );

                    ?>

                    : 1

                </span>

            </div>


            <div class="metric-row">

                <span class="metric-label">
                    Expectancy per Trade Execution
                </span>


                <span class="metric-value">

                    <?php

                    echo $totalTrades > 0
                        ? '$' .
                          number_format(
                              $netPnL / $totalTrades,
                              2
                          )
                        : '$0.00';

                    ?>

                </span>

            </div>

        </div>


        <!-- STREAKS -->

        <div class="card">

            <h2>
                Streaks & Extreme Volatilities
            </h2>


            <div class="metric-row">

                <span class="metric-label">
                    Maximum Winning Trade
                </span>


                <span class="metric-value text-win">

                    +$

                    <?php

                    echo number_format(
                        $maxWin,
                        2
                    );

                    ?>

                </span>

            </div>


            <div class="metric-row">

                <span class="metric-label">
                    Maximum Losing Trade
                </span>


                <span class="metric-value text-loss">

                    -$

                    <?php

                    echo number_format(
                        $maxLoss,
                        2
                    );

                    ?>

                </span>

            </div>


            <div class="metric-row">

                <span class="metric-label">
                    Max Consecutive Wins
                </span>


                <span class="metric-value text-win">

                    <?php echo $maxConsecutiveWins; ?>

                    Streaks

                </span>

            </div>


            <div class="metric-row">

                <span class="metric-label">
                    Max Consecutive Losses
                </span>


                <span class="metric-value text-loss">

                    <?php echo $maxConsecutiveLosses; ?>

                    Streaks

                </span>

            </div>

        </div>

    </div>


    <!-- =====================================================
         ADVANCED EQUITY CHART
    ====================================================== -->

    <div class="chart-card">


        <div class="chart-header">


            <div class="chart-title-wrapper">

                <h2>
                    Equity Progression
                </h2>

                <p>
                    Capital curve, drawdown zones & high-water mark
                </p>

            </div>


            <div class="chart-legend-info">


                <div class="chart-status">

                    <span class="chart-dot green"></span>

                    PROFIT

                </div>


                <div class="chart-status">

                    <span class="chart-dot red"></span>

                    DRAWDOWN

                </div>


                <div class="chart-status">

                    <span class="chart-dot yellow"></span>

                    HIGH WATER

                </div>

            </div>

        </div>


        <div class="chart-container">

            <canvas id="equityChart"></canvas>

        </div>


        <!-- =================================================
             CHART FOOTER
        ================================================== -->

        <div class="chart-footer">


            <div class="chart-footer-item">

                <span class="chart-footer-label">
                    Starting Balance
                </span>

                <span class="chart-footer-value">

                    $

                    <?php

                    echo number_format(
                        $startBalance,
                        2
                    );

                    ?>

                </span>

            </div>


            <div class="chart-footer-item">

                <span class="chart-footer-label">
                    Current Equity
                </span>

                <span class="chart-footer-value
                    <?php echo $netPnL >= 0
                        ? 'text-win'
                        : 'text-loss';
                    ?>"
                >

                    $

                    <?php

                    echo number_format(
                        $currentBal,
                        2
                    );

                    ?>

                </span>

            </div>


            <div class="chart-footer-item">

                <span class="chart-footer-label">
                    Net Return
                </span>

                <span class="chart-footer-value
                    <?php echo $netPnL >= 0
                        ? 'text-win'
                        : 'text-loss';
                    ?>"
                >

                    <?php

                    $returnPercent =
                        $startBalance > 0
                            ? (
                                $netPnL /
                                $startBalance
                              ) * 100
                            : 0;


                    echo (
                        $returnPercent >= 0
                            ? '+'
                            : ''
                    );


                    echo number_format(
                        $returnPercent,
                        2
                    );

                    ?>%

                </span>

            </div>


            <div class="chart-footer-item">

                <span class="chart-footer-label">
                    Max Drawdown
                </span>

                <span class="chart-footer-value text-loss">

                    -$

                    <?php

                    echo number_format(
                        $maxDrawdownUSD,
                        2
                    );

                    ?>

                </span>

            </div>

        </div>

    </div>


</div>


<!-- =========================================================
     ADVANCED CHART JAVASCRIPT
========================================================= -->

<script>


// ============================================================
// PHP DATA
// ============================================================

const labels =
    <?php echo $chartLabels; ?>;


const balanceData =
    <?php echo $chartBalanceData; ?>;


const startingBalance =
    <?php echo $chartStartBalance; ?>;


// ============================================================
// CANVAS
// ============================================================

const ctx =
    document
        .getElementById('equityChart')
        .getContext('2d');


// ============================================================
// HIGH WATER MARK
// ============================================================

let runningPeak =
    startingBalance;


const peakData =
    balanceData.map(balance => {

        if (balance > runningPeak) {

            runningPeak = balance;
        }

        return runningPeak;
    });


// ============================================================
// PNL DATA
// ============================================================

const pnlData =
    balanceData.map(balance => {

        return balance -
            startingBalance;
    });


// ============================================================
// DRAWDOWN DATA
// ============================================================

const drawdownData =
    balanceData.map(
        (balance, index) => {

            return (
                peakData[index] -
                balance
            );
        }
    );


// ============================================================
// GREEN GRADIENT
// ============================================================

const greenGradient =
    ctx.createLinearGradient(
        0,
        0,
        0,
        460
    );


greenGradient.addColorStop(
    0,
    'rgba(16, 185, 129, 0.30)'
);


greenGradient.addColorStop(
    0.55,
    'rgba(16, 185, 129, 0.10)'
);


greenGradient.addColorStop(
    1,
    'rgba(16, 185, 129, 0)'
);


// ============================================================
// RED GRADIENT
// ============================================================

const redGradient =
    ctx.createLinearGradient(
        0,
        0,
        0,
        460
    );


redGradient.addColorStop(
    0,
    'rgba(244, 63, 94, 0)'
);


redGradient.addColorStop(
    0.45,
    'rgba(244, 63, 94, 0.10)'
);


redGradient.addColorStop(
    1,
    'rgba(244, 63, 94, 0.30)'
);


// ============================================================
// BASELINE PLUGIN
// ============================================================

const baselinePlugin = {

    id: 'baselinePlugin',


    afterDraw(chart) {

        const {
            ctx,
            chartArea,
            scales
        } = chart;


        if (!chartArea) {

            return;
        }


        const yScale =
            scales.y;


        const baselineY =
            yScale.getPixelForValue(
                startingBalance
            );


        ctx.save();


        // ----------------------------------------------------
        // STARTING BALANCE LINE
        // ----------------------------------------------------

        ctx.beginPath();

        ctx.moveTo(
            chartArea.left,
            baselineY
        );

        ctx.lineTo(
            chartArea.right,
            baselineY
        );


        ctx.lineWidth = 1.5;

        ctx.strokeStyle =
            'rgba(148, 163, 184, 0.45)';

        ctx.setLineDash([
            7,
            6
        ]);

        ctx.stroke();


        // ----------------------------------------------------
        // BASELINE LABEL
        // ----------------------------------------------------

        ctx.setLineDash([]);


        ctx.fillStyle =
            'rgba(148, 163, 184, 0.85)';


        ctx.font =
            '600 10px Plus Jakarta Sans';


        ctx.textAlign =
            'right';


        ctx.fillText(

            'START $' +
            startingBalance.toLocaleString(
                undefined,
                {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                }
            ),

            chartArea.right - 5,

            baselineY - 8
        );


        ctx.restore();
    }
};


// ============================================================
// CROSSHAIR PLUGIN
// ============================================================

const crosshairPlugin = {

    id: 'crosshairPlugin',


    afterDraw(chart) {

        if (
            !chart.tooltip ||
            !chart.tooltip._active ||
            !chart.tooltip._active.length
        ) {

            return;
        }


        const activePoint =
            chart.tooltip._active[0];


        const {
            ctx,
            chartArea
        } = chart;


        const x =
            activePoint.element.x;


        ctx.save();


        ctx.beginPath();


        ctx.moveTo(
            x,
            chartArea.top
        );


        ctx.lineTo(
            x,
            chartArea.bottom
        );


        ctx.lineWidth = 1;

        ctx.strokeStyle =
            'rgba(148, 163, 184, 0.25)';

        ctx.setLineDash([
            4,
            4
        ]);


        ctx.stroke();


        ctx.restore();
    }
};


// ============================================================
// CREATE EQUITY CHART
// ============================================================

const equityChart =
    new Chart(
        ctx,
        {

            type: 'line',


            data: {

                labels: labels,


                datasets: [

                    // ==================================================
                    // MAIN EQUITY CURVE
                    // ==================================================

                    {

                        label:
                            'Account Equity',


                        data:
                            balanceData,


                        borderColor:
                            function(context) {

                                const value =
                                    context.parsed?.y ??
                                    startingBalance;


                                return value >=
                                    startingBalance

                                    ? '#10b981'

                                    : '#f43f5e';
                            },


                        backgroundColor:
                            function(context) {

                                const value =
                                    context.parsed?.y ??
                                    startingBalance;


                                return value >=
                                    startingBalance

                                    ? greenGradient

                                    : redGradient;
                            },


                        segment: {

                            borderColor:
                                function(context) {

                                    const y =
                                        context.p1.parsed.y;


                                    return y >=
                                        startingBalance

                                        ? '#10b981'

                                        : '#f43f5e';
                                },


                            backgroundColor:
                                function(context) {

                                    const y =
                                        context.p1.parsed.y;


                                    return y >=
                                        startingBalance

                                        ? greenGradient

                                        : redGradient;
                                }
                        },


                        borderWidth: 2.5,


                        fill: {

                            target:
                                'origin'
                        },


                        tension:
                            0.32,


                        cubicInterpolationMode:
                            'monotone',


                        pointRadius:
                            function(context) {

                                return (
                                    context.dataIndex === 0 ||
                                    context.dataIndex ===
                                        balanceData.length - 1
                                )

                                    ? 4

                                    : 2;
                            },


                        pointHoverRadius:
                            7,


                        pointBackgroundColor:
                            '#060913',


                        pointBorderWidth:
                            2,


                        pointBorderColor:
                            function(context) {

                                const value =
                                    context.parsed?.y ??
                                    startingBalance;


                                return value >=
                                    startingBalance

                                    ? '#10b981'

                                    : '#f43f5e';
                            },


                        order: 1
                    },


                    // ==================================================
                    // HIGH WATER MARK
                    // ==================================================

                    {

                        label:
                            'High Water Mark',


                        data:
                            peakData,


                        borderColor:
                            'rgba(251, 191, 36, 0.75)',


                        borderWidth:
                            1.3,


                        borderDash:
                            [
                                5,
                                5
                            ],


                        pointRadius:
                            0,


                        pointHoverRadius:
                            0,


                        fill:
                            false,


                        tension:
                            0.25,


                        order: 2
                    },


                    // ==================================================
                    // START BALANCE
                    // ==================================================

                    {

                        label:
                            'Starting Balance',


                        data:
                            labels.map(
                                () =>
                                    startingBalance
                            ),


                        borderColor:
                            'rgba(148, 163, 184, 0.50)',


                        borderWidth:
                            1.2,


                        borderDash:
                            [
                                7,
                                6
                            ],


                        pointRadius:
                            0,


                        pointHoverRadius:
                            0,


                        fill:
                            false,


                        order: 3
                    }

                ]
            },


            // ========================================================
            // OPTIONS
            // ========================================================

            options: {

                responsive:
                    true,


                maintainAspectRatio:
                    false,


                interaction: {

                    mode:
                        'index',

                    intersect:
                        false
                },


                animation: {

                    duration:
                        900,

                    easing:
                        'easeOutQuart'
                },


                plugins: {

                    legend: {

                        display:
                            true,


                        position:
                            'top',


                        align:
                            'end',


                        labels: {

                            usePointStyle:
                                true,


                            pointStyle:
                                'line',


                            padding:
                                18,


                            color:
                                '#94a3b8',


                            font: {

                                family:
                                    'Plus Jakarta Sans',

                                size:
                                    10,

                                weight:
                                    '600'
                            }
                        }
                    },


                    tooltip: {

                        enabled:
                            true,


                        backgroundColor:
                            '#0b1220',


                        titleColor:
                            '#f8fafc',


                        bodyColor:
                            '#cbd5e1',


                        borderColor:
                            'rgba(56, 189, 248, 0.25)',


                        borderWidth:
                            1,


                        padding:
                            14,


                        cornerRadius:
                            10,


                        displayColors:
                            false,


                        titleFont: {

                            family:
                                'Plus Jakarta Sans',

                            size:
                                12,

                            weight:
                                '700'
                        },


                        bodyFont: {

                            family:
                                'JetBrains Mono',

                            size:
                                11,

                            weight:
                                '500'
                        },


                        callbacks: {

                            title:
                                function(context) {

                                    return context[0]
                                        .label;
                                },


                            label:
                                function(context) {

                                    if (
                                        context.datasetIndex !==
                                        0
                                    ) {

                                        return null;
                                    }


                                    const index =
                                        context.dataIndex;


                                    const balance =
                                        balanceData[index];


                                    const pnl =
                                        balance -
                                        startingBalance;


                                    const peak =
                                        peakData[index];


                                    const drawdown =
                                        peak -
                                        balance;


                                    const drawdownPercent =
                                        peak > 0

                                            ? (
                                                drawdown /
                                                peak
                                              ) * 100

                                            : 0;


                                    const pnlPrefix =
                                        pnl >= 0
                                            ? '+'
                                            : '-';


                                    return [

                                        'Balance     $' +
                                        Math.abs(
                                            balance
                                        ).toLocaleString(
                                            undefined,
                                            {
                                                minimumFractionDigits: 2,
                                                maximumFractionDigits: 2
                                            }
                                        ),


                                        'P&L         ' +
                                        pnlPrefix +
                                        '$' +
                                        Math.abs(
                                            pnl
                                        ).toLocaleString(
                                            undefined,
                                            {
                                                minimumFractionDigits: 2,
                                                maximumFractionDigits: 2
                                            }
                                        ),


                                        'High Water  $' +
                                        peak.toLocaleString(
                                            undefined,
                                            {
                                                minimumFractionDigits: 2,
                                                maximumFractionDigits: 2
                                            }
                                        ),


                                        'Drawdown    -$' +
                                        drawdown.toLocaleString(
                                            undefined,
                                            {
                                                minimumFractionDigits: 2,
                                                maximumFractionDigits: 2
                                            }
                                        ) +
                                        ' (' +
                                        drawdownPercent.toFixed(
                                            2
                                        ) +
                                        '%)'
                                    ];
                                }
                        }
                    }
                },


                // ====================================================
                // AXES
                // ====================================================

                scales: {

                    x: {

                        grid: {

                            display:
                                true,

                            color:
                                'rgba(255,255,255,0.025)',

                            drawTicks:
                                false
                        },


                        border: {

                            display:
                                false
                        },


                        ticks: {

                            color:
                                '#64748b',

                            font: {

                                family:
                                    'Plus Jakarta Sans',

                                size:
                                    10,

                                weight:
                                    '500'
                            },


                            maxRotation:
                                0,


                            autoSkip:
                                true,


                            padding:
                                10
                        }
                    },


                    y: {

                        beginAtZero:
                            false,


                        grace:
                            '5%',


                        grid: {

                            color:
                                'rgba(255,255,255,0.035)',

                            drawTicks:
                                false
                        },


                        border: {

                            display:
                                false
                        },


                        ticks: {

                            color:
                                '#64748b',

                            padding:
                                12,


                            font: {

                                family:
                                    'JetBrains Mono',

                                size:
                                    10,

                                weight:
                                    '500'
                            },


                            callback:
                                function(value) {

                                    return '$' +
                                        Number(
                                            value
                                        ).toLocaleString(
                                            undefined,
                                            {
                                                maximumFractionDigits: 0
                                            }
                                        );
                                }
                        }
                    }
                }
            },


            plugins: [

                baselinePlugin,

                crosshairPlugin

            ]
        }
    );


// ============================================================
// RESIZE
// ============================================================

window.addEventListener(
    'resize',
    function() {

        equityChart.resize();

    }
);

</script>


</body>

</html>
<?php
date_default_timezone_set('Asia/Dhaka');

// Database credentials
$host = 'sql102.infinityfree.com'; 
$db   = 'if0_40135421_trade_tracker'; 
$user = 'if0_40135421'; 
$pass = 'WasasCNrbr'; 
$dsn = "mysql:host=$host;dbname=$db;charset=utf8";

try {
    $pdo = new PDO($dsn, $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
} catch (PDOException $e) {
    if (isset($_GET['get_live_data'])) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'DB Connection failed']);
        exit;
    }
    die("DB Connection failed: " . $e->getMessage());
}

// AJAX ENDPOINT FOR REAL-TIME UPDATES
if (isset($_GET['get_live_data'])) {
    header('Content-Type: application/json');
    header('Cache-Control: no-cache, no-store, must-revalidate');
    header('Pragma: no-cache');
    header('Expires: 0');

    $activeCheck = $pdo->query("SELECT * FROM time_checkers ORDER BY id DESC LIMIT 1")->fetch(PDO::FETCH_ASSOC);

    if (!$activeCheck) {
        echo json_encode(['success' => false]);
        exit;
    }

    $startTimestamp = strtotime($activeCheck['custom_time']);
    $currentTimestamp = time();
    $diffSeconds = max(0, $currentTimestamp - $startTimestamp);

    $days = floor($diffSeconds / 86400);
    $hours = floor(($diffSeconds % 86400) / 3600);
    $minutes = floor(($diffSeconds % 3600) / 60);
    $seconds = $diffSeconds % 60;

    $elapsedText = "";
    if ($days > 0) $elapsedText .= "$days days ";
    if ($hours > 0 || $days > 0) $elapsedText .= "$hours hours ";
    if ($minutes > 0 || $hours > 0 || $days > 0) $elapsedText .= "$minutes mins ";
    $elapsedText .= "$seconds secs";

    $totalMinutes = $diffSeconds / 60;

    echo json_encode([
        'success' => true,
        'custom_time' => date('h:i:s A', $startTimestamp),
        'elapsed_text' => $elapsedText,
        'diff_seconds' => $diffSeconds,
        'h1' => floor($totalMinutes / 60),
        'm15' => floor($totalMinutes / 15),
        'm5' => floor($totalMinutes / 5),
        'm3' => floor($totalMinutes / 3),
        'm2' => floor($totalMinutes / 2),
        'm1' => floor($totalMinutes / 1)
    ]);
    exit;
}

$error = '';

// HANDLE FORM SUBMISSIONS EXPLICITLY
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $inputTimeStr = '';

    if (isset($_POST['check_time'])) {
        $inputTimeStr = $_POST['custom_time'] ?? '';
        if (empty($inputTimeStr)) {
            $error = "Please provide a time.";
        }
    } elseif (isset($_POST['check_in_now'])) {
        $inputTimeStr = date('H:i'); 
    }

    if (!empty($inputTimeStr)) {
        $todayDate = date('Y-m-d');
        $fullInputTime = "$todayDate $inputTimeStr:00";
        
        $startTimestamp = strtotime($fullInputTime);
        $currentTimestamp = time();
        
        if ($startTimestamp) {
            if ($startTimestamp > $currentTimestamp) {
                $startTimestamp = strtotime("$fullInputTime -1 day");
                $fullInputTime = date('Y-m-d H:i:s', $startTimestamp);
            }

            $diffSeconds = $currentTimestamp - $startTimestamp;
            $totalMinutes = $diffSeconds / 60;
            
            $h1  = floor($totalMinutes / 60);
            $m15 = floor($totalMinutes / 15);
            $m5  = floor($totalMinutes / 5);
            $m3  = floor($totalMinutes / 3);
            $m2  = floor($totalMinutes / 2);
            $m1  = floor($totalMinutes / 1);

            // CLEAR old records completely
            $pdo->exec("DELETE FROM time_checkers");

            // Insert new record
            $stmt = $pdo->prepare("
                INSERT INTO time_checkers (custom_time, elapsed_text, h1_candles, m15_candles, m5_candles, m1_candles)
                VALUES (?, '', ?, ?, ?, ?)
            ");
            $stmt->execute([$fullInputTime, $h1, $m15, $m5, $m1]);

            header("Location: checker.php?reset=1");
            exit;
        }
    }
}

$selectedView = isset($_GET['view']) ? $_GET['view'] : 'm5';
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Real-Time Time & Candle Checker</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
@keyframes terminalPulse {
    0%, 100% { opacity: 1; transform: translateY(0); }
    50% { opacity: 0.5; transform: translateY(-1px); }
}
.animate-terminal-pulse {
    animation: terminalPulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite;
}
</style>
</head>
<body class="bg-[#0b0e14] text-[#8b949e] font-mono min-h-screen flex items-center justify-center p-4">

<div class="bg-[#161b22] border border-[#30363d] rounded-md shadow-2xl w-full max-w-7xl overflow-hidden">

    <!-- Top Terminal Bar -->
    <div class="bg-[#21262d] px-4 py-3 border-b border-[#30363d] flex justify-between items-center">
        <div class="flex items-center gap-2">
            <span class="w-3 h-3 rounded-full bg-[#f85149] inline-block"></span>
            <span class="w-3 h-3 rounded-full bg-[#e3b341] inline-block"></span>
            <span class="w-3 h-3 rounded-full bg-[#2ea043] inline-block"></span>
            <span class="text-xs text-[#c9d1d9] font-bold ml-2 tracking-wider">TERMINAL_CHECKER_v2.4 // TIME_&_CANDLE_MATRIX</span>
        </div>
        <div class="text-xs text-[#8b949e]" id="terminal-clock">00:00:00</div>
    </div>

    <div class="p-6">

        <!-- Navigation Bar -->
        <div class="flex justify-between items-center mb-6 border-b border-[#30363d] pb-4 flex-wrap gap-2">
            <div>
                <h1 class="text-sm font-bold text-[#c9d1d9] uppercase tracking-wider">Real-Time Time & Candle Checker</h1>
                <p class="text-xs text-[#8b949e] mt-1">Status: <span class="text-[#2ea043]">ACTIVE_FEED_ONLINE</span></p>
            </div>
            <div class="flex gap-2 flex-wrap">
                <a href="index.php" class="bg-[#21262d] hover:bg-[#30363d] border border-[#30363d] text-[#c9d1d9] px-3 py-1.5 rounded text-xs transition">
                    [ RETURN_TO_MAIN ]
                </a>
                <a href="stratergy_checklist.php" target="_blank" class="bg-[#21262d] hover:bg-[#30363d] border border-[#30363d] text-[#c9d1d9] px-3 py-1.5 rounded text-xs transition">
                [ STRATEGY ]
            </a>
                <a href="calculation.php" class="bg-[#238636] hover:bg-[#2ea043] text-white px-3 py-1.5 rounded text-xs font-bold transition border border-[#2ea043]">
                    [ TRACKER ]
                </a>
                
            </div>
        </div>

        <!-- SIGNAL BOX FEATURE -->
        <div class="mb-6 bg-[#0d1117] border border-[#30363d] rounded p-4 flex flex-wrap items-center justify-between gap-4 shadow-sm animate-terminal-pulse">
            <div class="flex items-center gap-3">
                <span class="text-xs font-bold uppercase tracking-wider text-[#8b949e]">Signal Directive:</span>
                <span id="signal-badge" class="px-3 py-1 rounded text-xs font-bold bg-[#2ea043]/20 text-[#2ea043] border border-[#2ea043]/40">UP TREND (CALL)</span>
            </div>
            <div class="flex items-center gap-2">
                <label for="signal-selector" class="text-xs font-semibold text-[#8b949e]">Select Signal:</label>
                <select id="signal-selector" onchange="updateSignalBadge(this.value)" class="bg-[#0d1117] border border-[#30363d] rounded p-1.5 text-xs text-[#c9d1d9] font-medium focus:outline-none focus:border-[#58a6ff]">
                    <option value="up">Uptrend (Up)</option>
                    <option value="down">Downtrend (Down)</option>
                    <option value="neutral">Neutral / Wait</option>
                </select>
            </div>
        </div>

        <!-- INPUT FORMS -->
        <div class="flex flex-wrap gap-4 items-center justify-center mb-8 bg-[#0d1117] p-6 rounded border border-[#30363d]">
            <form action="checker.php" method="POST" class="flex flex-wrap gap-3 items-end">
                <div class="flex flex-col gap-1">
                    <input type="time" id="custom_time" name="custom_time" class="bg-[#161b22] border border-[#30363d] rounded p-2 text-xs text-[#c9d1d9] focus:border-[#58a6ff] outline-none" required>
                </div>
                <button type="submit" name="check_time" class="bg-[#238636] hover:bg-[#2ea043] text-white font-bold rounded px-5 py-2 h-[38px] text-xs uppercase tracking-wider transition border border-[#2ea043]">
                    Checking
                </button>
            </form>

            <div class="text-[#8b949e] font-bold text-xs hidden md:block">OR</div>

            <form action="checker.php" method="POST" class="flex items-end">
                <button type="submit" name="check_in_now" class="bg-[#21262d] hover:bg-[#30363d] border border-[#30363d] text-[#c9d1d9] font-bold rounded px-6 py-2 h-[38px] text-xs uppercase tracking-wider transition shadow-sm">
                    Check-In Now
                </button>
            </form>
        </div>

        <?php if($error): ?>
            <div class="bg-[#da3633]/20 border border-[#f85149]/40 text-[#f85149] p-3 rounded text-xs text-center mb-4">
                <?= $error ?>
            </div>
        <?php endif; ?>

        <!-- TIMEFRAME SELECTOR TABS -->
        <div id="checker-section" style="display: none;">
            <div class="flex flex-wrap justify-between items-center mb-4 gap-2 border-b border-[#30363d] pb-3">
                <div class="flex gap-2 flex-wrap">
                    <button onclick="switchView('m5')" id="btn-m5" class="px-3 py-1.5 rounded font-bold text-xs transition">5 Min</button>
                    <button onclick="switchView('m3')" id="btn-m3" class="px-3 py-1.5 rounded font-bold text-xs transition">3 Min</button>
                    <button onclick="switchView('m2')" id="btn-m2" class="px-3 py-1.5 rounded font-bold text-xs transition">2 Min</button>
                    <button onclick="switchView('h1')" id="btn-h1" class="px-3 py-1.5 rounded font-bold text-xs transition">1 Hour</button>
                    <button onclick="switchView('m15')" id="btn-m15" class="px-3 py-1.5 rounded font-bold text-xs transition">15 Min</button>
                    <button onclick="switchView('m1')" id="btn-m1" class="px-3 py-1.5 rounded font-bold text-xs transition">1 Min</button>
                </div>
                <span class="text-xs text-[#8b949e]">Viewing: <strong id="view-label" class="text-[#58a6ff] uppercase">M5</strong> Candles (🔔 15-Times Bell Active)</span>
            </div>

            <!-- LIVE TABLE -->
            <div class="overflow-x-auto border border-[#30363d] rounded bg-[#0d1117]">
                <table class="min-w-full text-center">
                    <thead class="bg-[#21262d] text-[#c9d1d9] text-xs border-b border-[#30363d]">
                        <tr>
                            <th class="p-3">Check-In Time</th>
                            <th class="p-3">Elapsed Time (Live)</th>
                            <th class="p-3" id="table-header-candle">M5 Candles</th>
                            <th class="p-3">Current Candle Progress</th>
                        </tr>
                    </thead>
                    <tbody class="text-center bg-[#0d1117] text-xs">
                        <tr class="hover:bg-[#161b22] border-b border-[#30363d]">
                            <td class="p-3 text-[#c9d1d9]" id="live-check-time">-</td>
                            <td class="p-3 font-bold text-[#58a6ff]" id="live-elapsed">-</td>
                            <td class="p-3 font-extrabold text-base text-[#2ea043]" id="live-candles">-</td>
                            <td class="p-3 align-middle w-64">
                                <div class="flex justify-between font-bold text-[11px] text-[#8b949e] mb-1">
                                    <span id="progress-percent">0%</span>
                                    <span id="progress-time">0s / 300s</span>
                                </div>
                                <div class="w-full bg-[#161b22] border border-[#30363d] rounded h-2.5 overflow-hidden p-0.5">
                                    <div id="progress-bar" class="bg-[#2ea043] h-full transition-all duration-300" style="width: 0%"></div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <p id="no-check-msg" class="text-center text-[#8b949e] text-xs py-4" style="display: none;">NO_ACTIVE_CHECKIN // Use custom input or click "Check-In Now"!</p>

    </div>
</div>

<script>
let currentView = '<?= $selectedView ?>';
let prevCounts = null; 

const timeframeDurations = {
    'm1': 60,
    'm2': 120,
    'm3': 180,
    'm5': 300,
    'm15': 900,
    'h1': 3600
};

function updateSignalBadge(val) {
    const badge = document.getElementById('signal-badge');
    if (val === 'up') {
        badge.className = 'px-3 py-1 rounded text-xs font-bold bg-[#2ea043]/20 text-[#2ea043] border border-[#2ea043]/40';
        badge.innerText = 'UP TREND (CALL)';
    } else if (val === 'down') {
        badge.className = 'px-3 py-1 rounded text-xs font-bold bg-[#da3633]/20 text-[#f85149] border border-[#f85149]/40';
        badge.innerText = 'DOWN TREND (PUT)';
    } else {
        badge.className = 'px-3 py-1 rounded text-xs font-bold bg-[#e3b341]/20 text-[#e3b341] border border-[#e3b341]/40';
        badge.innerText = 'NEUTRAL / WAIT';
    }
    localStorage.setItem('trade_signal_preference', val);
}

window.addEventListener('DOMContentLoaded', () => {
    const savedSignal = localStorage.getItem('trade_signal_preference');
    if (savedSignal) {
        document.getElementById('signal-selector').value = savedSignal;
        updateSignalBadge(savedSignal);
    }
});

setInterval(() => {
    const now = new Date();
    document.getElementById('terminal-clock').innerText = now.toLocaleTimeString();
}, 1000);

function playBellSound() {
    let rings = 0;
    function ringChime() {
        if (rings >= 15) return;
        try {
            const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
            const osc1 = audioCtx.createOscillator();
            const osc2 = audioCtx.createOscillator();
            const gainNode = audioCtx.createGain();

            osc1.type = 'sine';
            osc2.type = 'triangle';

            osc1.frequency.setValueAtTime(1046.50, audioCtx.currentTime); 
            osc2.frequency.setValueAtTime(523.25, audioCtx.currentTime);  

            gainNode.gain.setValueAtTime(0.3, audioCtx.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.3);

            osc1.connect(gainNode);
            osc2.connect(gainNode);
            gainNode.connect(audioCtx.destination);

            osc1.start();
            osc2.start();
            osc1.stop(audioCtx.currentTime + 0.3);
            osc2.stop(audioCtx.currentTime + 0.3);
        } catch (e) {
            console.log("Audio waiting for user interaction.", e);
        }
        rings++;
        if (rings < 15) {
            setTimeout(ringChime, 250);
        }
    }
    ringChime();
}

function switchView(view) {
    currentView = view;
    ['m5', 'm3', 'm2', 'h1', 'm15', 'm1'].forEach(v => {
        let btn = document.getElementById('btn-' + v);
        if (v === view) {
            btn.className = 'px-3 py-1.5 rounded font-bold text-xs bg-[#238636] text-white border border-[#2ea043]';
        } else {
            btn.className = 'px-3 py-1.5 rounded font-bold text-xs bg-[#21262d] text-[#c9d1d9] border border-[#30363d] hover:bg-[#30363d] transition';
        }
    });
    document.getElementById('view-label').innerText = view.toUpperCase();
    document.getElementById('table-header-candle').innerText = view.toUpperCase() + ' Candles';
    fetchLiveData();
}

switchView(currentView);

function fetchLiveData() {
    fetch('checker.php?get_live_data=1&_t=' + Date.now())
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('checker-section').style.display = 'block';
                document.getElementById('no-check-msg').style.display = 'none';

                document.getElementById('live-check-time').innerText = data.custom_time;
                document.getElementById('live-elapsed').innerText = data.elapsed_text;

                if (prevCounts === null) {
                    prevCounts = { h1: data.h1, m15: data.m15, m5: data.m5, m3: data.m3, m2: data.m2, m1: data.m1 };
                } else {
                    let shouldRing = false;
                    if (currentView === 'm1' && data.m1 > prevCounts.m1) shouldRing = true;
                    if (currentView === 'm2' && data.m2 > prevCounts.m2) shouldRing = true;
                    if (currentView === 'm3' && data.m3 > prevCounts.m3) shouldRing = true;
                    if (currentView === 'm5' && data.m5 > prevCounts.m5) shouldRing = true;
                    if (currentView === 'm15' && data.m15 > prevCounts.m15) shouldRing = true;
                    if (currentView === 'h1' && data.h1 > prevCounts.h1) shouldRing = true;

                    if (shouldRing) {
                        playBellSound();
                    }

                    prevCounts = { h1: data.h1, m15: data.m15, m5: data.m5, m3: data.m3, m2: data.m2, m1: data.m1 };
                }

                let candleCount = data.m5;
                if (currentView === 'h1') candleCount = data.h1;
                else if (currentView === 'm15') candleCount = data.m15;
                else if (currentView === 'm5') candleCount = data.m5;
                else if (currentView === 'm3') candleCount = data.m3;
                else if (currentView === 'm2') candleCount = data.m2;
                else if (currentView === 'm1') candleCount = data.m1;

                document.getElementById('live-candles').innerText = Number(candleCount).toLocaleString();

                let totalDuration = timeframeDurations[currentView];
                let currentCandleSeconds = data.diff_seconds % totalDuration;
                let percent = Math.min(100, Math.max(0, (currentCandleSeconds / totalDuration) * 100)).toFixed(1);

                document.getElementById('progress-bar').style.width = percent + '%';
                document.getElementById('progress-percent').innerText = percent + '%';
                document.getElementById('progress-time').innerText = `${Math.floor(currentCandleSeconds)}s / ${totalDuration}s`;

            } else {
                document.getElementById('checker-section').style.display = 'none';
                document.getElementById('no-check-msg').style.display = 'block';
                prevCounts = null;
            }
        })
        .catch(err => console.error('Error fetching live data:', err));
}

setInterval(fetchLiveData, 1000);
fetchLiveData();
</script>

</body>
</html>
<?php
date_default_timezone_set('Asia/Dhaka');
?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>Daily Drawdown & Trade Safeguards (Synchronized)</title>

<script src="https://cdn.tailwindcss.com"></script>

</head>


<body
    class="bg-[#0b0e14] text-[#8b949e] font-mono min-h-screen flex items-center justify-center p-4"
>


<div
    class="bg-[#161b22] border border-[#30363d] rounded-md shadow-2xl w-full max-w-4xl overflow-hidden my-8"
>


    <!-- TOP TERMINAL BAR -->

    <div
        class="bg-[#21262d] px-4 py-3 border-b border-[#30363d] flex justify-between items-center"
    >

        <div class="flex items-center gap-2">

            <span class="w-3 h-3 rounded-full bg-[#f85149] inline-block"></span>

            <span class="w-3 h-3 rounded-full bg-[#e3b341] inline-block"></span>

            <span class="w-3 h-3 rounded-full bg-[#2ea043] inline-block"></span>

            <span
                class="text-xs text-[#c9d1d9] font-bold ml-2 tracking-wider"
            >
               DAILY_SAFEGUARDS // v2.0
            </span>

        </div>
                <a href="index.php" class="bg-[#21262d] hover:bg-[#30363d] border border-[#30363d] text-[#c9d1d9] px-3 py-1.5 rounded text-xs transition">
                    [ RETURN_TO_DASHBOARD ]
                </a>

        <div
            class="text-xs text-[#8b949e]"
            id="terminal-clock"
        >
            00:00:00
        </div>

    </div>



    <div class="p-6 space-y-6">


        <!-- HEADER & GFT TIMER -->

        <div
            class="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-[#30363d] pb-4 gap-4"
        >

            <div>

                <h1
                    class="text-sm font-bold text-[#c9d1d9] uppercase tracking-wider"
                >
                     Daily Drawdown & Reset Sync
                </h1>


                <p class="text-xs text-[#8b949e] mt-1">

                    Status:

                    <span
                        id="system-lockout-badge"
                        class="text-[#2ea043]"
                    >
                        SYSTEM_ACTIVE
                    </span>

                </p>

            </div>


            <!-- GFT RESET COUNTDOWN BOX -->

            <div class="bg-[#0d1117] border border-[#30363d] px-3 py-2 rounded text-right">

                <p class="text-[9px] text-[#8b949e] uppercase tracking-wider">
                    Reset in (03:00 AM BDT):
                </p>

                <p
                    id="gft_countdown_timer"
                    class="text-xs font-bold text-[#58a6ff] mt-0.5"
                >
                    --h --m --s
                </p>

            </div>

        </div>



        <!-- DAILY DRAWDOWN & TRADE ANALYSIS MODULE -->

        <div class="space-y-6">


            <!-- CONFIGURATION & INPUT PANEL -->

            <div class="bg-[#0d1117] border border-[#30363d] p-4 rounded space-y-4">

                <div class="grid grid-cols-1 md:grid-cols-5 gap-4">

                    <!-- ACCOUNT BALANCE -->

                    <div>

                        <label class="block text-[10px] font-bold text-[#8b949e] mb-1 uppercase">
                            Account Balance ($)
                        </label>

                        <input
                            type="number"
                            id="dd_account_balance"
                            step="100"
                            class="w-full bg-[#161b22] border border-[#30363d] rounded p-2 text-xs text-[#c9d1d9] focus:border-[#58a6ff] outline-none"
                        >

                    </div>


                    <!-- ACTIVE SESSION -->

                    <div>

                        <label class="block text-[10px] font-bold text-[#8b949e] mb-1 uppercase">
                            Active Trading Session
                        </label>

                        <select
                            id="dd_active_session"
                            class="w-full bg-[#161b22] border border-[#30363d] rounded p-2 text-xs text-[#c9d1d9] focus:border-[#58a6ff] outline-none"
                        >

                            <option value="1">Session 1</option>

                            <option value="2">Session 2</option>

                        </select>

                    </div>


                    <!-- RISK AMOUNT -->

                    <div>

                        <label class="block text-[10px] font-bold text-[#8b949e] mb-1 uppercase">
                            Risk Amount ($)
                        </label>

                        <input
                            type="number"
                            id="dd_risk_amount"
                            step="0.01"
                            min="0"
                            class="w-full bg-[#161b22] border border-[#30363d] rounded p-2 text-xs text-[#c9d1d9] focus:border-[#58a6ff] outline-none"
                        >

                    </div>


                    <!-- PROFIT AMOUNT -->

                    <div>

                        <label class="block text-[10px] font-bold text-[#8b949e] mb-1 uppercase">
                            Profit Amount ($)
                        </label>

                        <input
                            type="number"
                            id="dd_profit_amount"
                            step="0.01"
                            min="0"
                            class="w-full bg-[#161b22] border border-[#30363d] rounded p-2 text-xs text-[#c9d1d9] focus:border-[#58a6ff] outline-none"
                        >

                    </div>


                    <!-- DAILY RISK LIMIT -->

                    <div>

                        <label class="block text-[10px] font-bold text-[#8b949e] mb-1 uppercase">
                            Daily Risk Limit (%)
                        </label>

                        <input
                            type="number"
                            id="dd_risk_limit_percent"
                            step="0.01"
                            min="0.01"
                            class="w-full bg-[#161b22] border border-[#30363d] rounded p-2 text-xs text-[#c9d1d9] focus:border-[#58a6ff] outline-none"
                        >

                    </div>

                </div>


                <div class="grid grid-cols-1 gap-4 pt-2 border-t border-[#30363d]">

                    <div class="flex items-end gap-2">

                        <button
                            onclick="submitTradeOutcome('profit')"
                            id="btn_submit_profit"
                            class="flex-1 bg-[#238636] hover:bg-[#2ea043] text-white font-bold text-xs py-2.5 rounded uppercase tracking-wider transition border border-[#2ea043]"
                        >
                            Submit Exact Profit
                        </button>


                        <button
                            onclick="submitTradeOutcome('loss')"
                            id="btn_submit_loss"
                            class="flex-1 bg-[#da3633]/20 hover:bg-[#da3633]/30 text-[#f85149] font-bold text-xs py-2.5 rounded uppercase tracking-wider transition border border-[#f85149]/40"
                        >
                            Submit Exact Loss
                        </button>

                    </div>

                </div>

            </div>



            <!-- RULES STATUS GRID -->

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">

                <div class="bg-[#0d1117] border border-[#30363d] p-3 rounded text-center">

                    <p class="text-[9px] text-[#8b949e] uppercase">
                        Sess. Safeguard
                    </p>

                    <p
                        id="rule_session_status"
                        class="text-xs font-bold text-[#2ea043] mt-1"
                    >
                        SAFE
                    </p>

                </div>


                <div class="bg-[#0d1117] border border-[#30363d] p-3 rounded text-center">

                    <p class="text-[9px] text-[#8b949e] uppercase">
                        Daily Lockout
                    </p>

                    <p
                        id="rule_lockout_status"
                        class="text-xs font-bold text-[#2ea043] mt-1"
                    >
                        SAFE
                    </p>

                </div>


                <div class="bg-[#0d1117] border border-[#30363d] p-3 rounded text-center">

                    <p class="text-[9px] text-[#8b949e] uppercase">
                        Profit Rate (>40%)
                    </p>

                    <p
                        id="rule_profitrate_status"
                        class="text-xs font-bold text-[#8b949e] mt-1"
                    >
                        PENDING (0/5)
                    </p>

                </div>


                <!-- RISK LIMIT -->

                <div class="bg-[#0d1117] border border-[#30363d] p-3 rounded text-center">

                    <p
                        class="text-[9px] text-[#8b949e] uppercase"
                    >
                        Risk Limit
                    </p>

                    <p
                        id="rule_capital_status"
                        class="text-xs font-bold text-[#2ea043] mt-1"
                    >
                        CAN TRADE
                    </p>

                </div>


                <div class="bg-[#0d1117] border border-[#30363d] p-3 rounded text-center">

                    <p class="text-[9px] text-[#8b949e] uppercase">
                        Frequency Cap
                    </p>

                    <p
                        id="rule_frequency_status"
                        class="text-xs font-bold text-[#2ea043] mt-1"
                    >
                        SESSION 1
                    </p>

                </div>

            </div>



            <!-- METRICS SUMMARY BAR -->

            <div class="grid grid-cols-2 md:grid-cols-5 gap-3">


                <!-- TOTAL TRADES -->

                <div class="bg-[#0d1117] border border-[#30363d] p-3 rounded text-center">

                    <p class="text-[10px] text-[#8b949e] uppercase">
                        Total Trades
                    </p>

                    <p
                        id="stat_total_trades"
                        class="text-sm font-bold text-[#c9d1d9] mt-1"
                    >
                        0
                    </p>

                </div>


                <!-- PROFIT RATE -->

                <div class="bg-[#0d1117] border border-[#30363d] p-3 rounded text-center">

                    <p class="text-[10px] text-[#8b949e] uppercase">
                        Profit Rate
                    </p>

                    <p
                        id="stat_profit_rate"
                        class="text-sm font-bold text-[#c9d1d9] mt-1"
                    >
                        0.0%
                    </p>

                </div>


                <!-- NET P&L -->

                <div class="bg-[#0d1117] border border-[#30363d] p-3 rounded text-center">

                    <p class="text-[10px] text-[#8b949e] uppercase">
                        Net P&L ($)
                    </p>

                    <p
                        id="stat_net_pnl"
                        class="text-sm font-bold text-[#c9d1d9] mt-1"
                    >
                        $0.00
                    </p>

                </div>


                <!-- DAILY DRAWDOWN -->

                <div class="bg-[#0d1117] border border-[#30363d] p-3 rounded text-center">

                    <p class="text-[10px] text-[#8b949e] uppercase">
                        Daily Drawdown %
                    </p>

                    <p
                        id="stat_daily_dd"
                        class="text-sm font-bold text-[#c9d1d9] mt-1"
                    >
                        0.00%
                    </p>

                </div>


                <!-- TOTAL RISK EXPOSURE -->

                <div class="bg-[#0d1117] border border-[#30363d] p-3 rounded text-center">

                    <p class="text-[10px] text-[#8b949e] uppercase">
                        Total Risk Exposure
                    </p>

                    <p
                        id="stat_total_risk"
                        class="text-sm font-bold text-[#c9d1d9] mt-1"
                    >
                        $0.00
                    </p>

                </div>

            </div>



            <!-- TRADE LOGS TABLE -->

            <div class="bg-[#0d1117] border border-[#30363d] rounded overflow-hidden">

                <div class="px-4 py-3 border-b border-[#30363d] flex justify-between items-center">

                    <span class="text-xs font-bold text-[#c9d1d9] uppercase">
                        Session Execution Log
                    </span>

                    <div class="flex gap-3">

                        <button
                            onclick="resetDailyData()"
                            class="text-[10px] text-[#f85149] hover:underline uppercase"
                        >
                            [ RESET DAY ]
                        </button>

                    </div>

                </div>


                <div class="overflow-x-auto max-h-60 overflow-y-auto">

                    <table class="w-full text-left text-xs">

                        <thead class="bg-[#161b22] text-[#8b949e] border-b border-[#30363d] sticky top-0">

                            <tr>

                                <th class="p-2.5">#</th>

                                <th class="p-2.5">Session</th>

                                <th class="p-2.5">Outcome</th>

                                <th class="p-2.5">Risk ($)</th>

                                <th class="p-2.5">P&L ($)</th>

                                <th class="p-2.5">Time</th>

                                <th class="p-2.5 text-right">Action</th>

                            </tr>

                        </thead>


                        <tbody
                            id="trade_log_tbody"
                            class="divide-y divide-[#30363d] text-[#c9d1d9]"
                        >

                            <tr>

                                <td
                                    colspan="7"
                                    class="p-4 text-center text-[#8b949e] italic"
                                >
                                    No trades recorded for today yet.
                                </td>

                            </tr>

                        </tbody>

                    </table>

                </div>

            </div>

        </div>

    </div>

</div>



<script>

/* =========================
   TERMINAL CLOCK & GFT TIMER
========================= */

function updateClockAndTimer() {

    const now = new Date();

    document.getElementById('terminal-clock').innerText =
        now.toLocaleTimeString();


    // GFT resets at 5 PM EST,
    // which corresponds to 03:00 AM Bangladesh Time

    let resetTime = new Date(now);

    resetTime.setHours(3, 0, 0, 0);


    if (now >= resetTime) {

        resetTime.setDate(
            resetTime.getDate() + 1
        );

    }


    const diff = resetTime - now;

    const hours = Math.floor(
        (diff % (1000 * 60 * 60 * 24)) /
        (1000 * 60 * 60)
    );

    const minutes = Math.floor(
        (diff % (1000 * 60 * 60)) /
        (1000 * 60)
    );

    const seconds = Math.floor(
        (diff % (1000 * 60)) /
        1000
    );


    document.getElementById('gft_countdown_timer').innerText =

        String(hours).padStart(2, '0') + 'h ' +

        String(minutes).padStart(2, '0') + 'm ' +

        String(seconds).padStart(2, '0') + 's';

}


updateClockAndTimer();

setInterval(updateClockAndTimer, 1000);


/* ========================================================================= */
/* GFT-SYNCHRONIZED STORAGE & RESET ENGINE */
/* ========================================================================= */

const DD_STORAGE_KEY =
    'terminal_gft_backtest_daily_state_v1';

const DD_DATE_KEY =
    'terminal_gft_backtest_daily_date_v1';

const DD_SETTINGS_KEY =
    'terminal_gft_backtest_settings_v1';



/* =========================
   GFT TRADING DAY
========================= */

function getGftTradingDayString() {

    const now = new Date();


    if (now.getHours() < 3) {

        now.setDate(
            now.getDate() - 1
        );

    }


    return now.getFullYear() + '-' +

        String(
            now.getMonth() + 1
        ).padStart(2, '0') + '-' +

        String(
            now.getDate()
        ).padStart(2, '0');

}



/* =========================
   SETTINGS
========================= */

function loadSettings() {

    const saved =
        localStorage.getItem(
            DD_SETTINGS_KEY
        );


    let settings = {

        balance: 10000,

        session: '1',

        riskAmount: 200,

        profitAmount: 300,

        riskLimitPercent: 4

    };


    if (saved) {

        try {

            const parsed =
                JSON.parse(saved);

            settings = {
                ...settings,
                ...parsed
            };

        } catch (e) {}

    }


    document.getElementById(
        'dd_account_balance'
    ).value = settings.balance;


    document.getElementById(
        'dd_active_session'
    ).value = settings.session;


    document.getElementById(
        'dd_risk_amount'
    ).value = settings.riskAmount;


    document.getElementById(
        'dd_profit_amount'
    ).value = settings.profitAmount;


    document.getElementById(
        'dd_risk_limit_percent'
    ).value = settings.riskLimitPercent;

}



function saveSettings() {

    const settings = {

        balance:
            parseFloat(
                document.getElementById(
                    'dd_account_balance'
                ).value
            ) || 10000,


        session:
            document.getElementById(
                'dd_active_session'
            ).value,


        riskAmount:
            parseFloat(
                document.getElementById(
                    'dd_risk_amount'
                ).value
            ) || 0,


        profitAmount:
            parseFloat(
                document.getElementById(
                    'dd_profit_amount'
                ).value
            ) || 0,


        riskLimitPercent:
            parseFloat(
                document.getElementById(
                    'dd_risk_limit_percent'
                ).value
            ) || 0

    };


    localStorage.setItem(
        DD_SETTINGS_KEY,
        JSON.stringify(settings)
    );

}



/* =========================
   DAILY STATE
========================= */

function loadDailyState() {

    const storedDate =
        localStorage.getItem(
            DD_DATE_KEY
        );


    const currentGftDay =
        getGftTradingDayString();


    if (storedDate !== currentGftDay) {

        resetDailyData(true);

    }


    const saved =
        localStorage.getItem(
            DD_STORAGE_KEY
        );


    if (!saved) {

        return getDefaultDailyState();

    }


    try {

        return JSON.parse(saved);

    } catch (e) {

        return getDefaultDailyState();

    }

}



function getDefaultDailyState() {

    return {

        trades: [],

        session1Losses: 0,

        session1Expired: false,

        session2Losses: 0,

        session2Expired: false,

        dailyLockoutTriggered: false

    };

}



function saveDailyState(state) {

    localStorage.setItem(
        DD_DATE_KEY,
        getGftTradingDayString()
    );


    localStorage.setItem(
        DD_STORAGE_KEY,
        JSON.stringify(state)
    );

}



/* =========================
   RESET DAILY DATA
========================= */

function resetDailyData(silent = false) {

    if (
        !silent &&
        !confirm(
            'CONFIRM_RESET: Clear all GFT daily drawdown stats and trade logs?'
        )
    ) {

        return;

    }


    const freshState =
        getDefaultDailyState();


    saveDailyState(
        freshState
    );


    updateDrawdownInterface();


    if (!silent) {

        alert(
            'SUCCESS: GFT daily session data reset.'
        );

    }

}



/* =========================
   DELETE TRADE
========================= */

function deleteTrade(index) {

    let state =
        loadDailyState();


    if (
        index < 0 ||
        index >= state.trades.length
    ) {

        alert(
            'ERR: Invalid trade index.'
        );

        return;

    }


    if (
        !confirm(
            'CONFIRM_DELETE: Are you sure you want to remove this trade entry?'
        )
    ) {

        return;

    }


    state.trades.splice(
        index,
        1
    );


    state.session1Losses = 0;

    state.session1Expired = false;

    state.session2Losses = 0;

    state.session2Expired = false;

    state.dailyLockoutTriggered = false;



// ACCOUNT LOCKOUT: 2 CONSECUTIVE LOSSES
let consecutiveLossesCount = 0;

for (
    let i = state.trades.length - 1;
    i >= 0;
    i--
) {
    if (
        state.trades[i].outcome === 'loss'
    ) {
        consecutiveLossesCount++;
    } else {
        break;
    }
}

if (consecutiveLossesCount >= 2) {
    state.dailyLockoutTriggered = true;
}

saveDailyState(state);
updateDrawdownInterface();



/* =========================
   SUBMIT TRADE
========================= */

function submitTradeOutcome(outcome) {

    saveSettings();


    let state =
        loadDailyState();


    if (
        state.dailyLockoutTriggered
    ) {

        alert(
            'ERR_LOCKOUT: Daily lockout active (2 consecutive daily losses). Trading halted.'
        );

        return;

    }


    const activeSession =
        document.getElementById(
            'dd_active_session'
        ).value;


    if (
        activeSession === '1' &&
        state.session1Expired
    ) {

        alert(
            'ERR_SESSION: Session 1 has reached 3 consecutive losses and is expired. Switch to Session 2.'
        );

        return;

    }


    if (
        activeSession === '2' &&
        state.session2Expired
    ) {

        alert(
            'ERR_SESSION: Session 2 has reached 3 consecutive losses and is expired.'
        );

        return;

    }



    /* =========================
       GET RISK AMOUNT
    ========================= */

    const riskAmountInput =
        parseFloat(
            document.getElementById(
                'dd_risk_amount'
            ).value
        );


    if (
        isNaN(riskAmountInput) ||
        riskAmountInput <= 0
    ) {

        alert(
            'ERR: Please enter a valid risk amount.'
        );

        return;

    }



    /* =========================
       GET RISK LIMIT
    ========================= */

    const balance =
        parseFloat(
            document.getElementById(
                'dd_account_balance'
            ).value
        );


    const riskLimitPercent =
        parseFloat(
            document.getElementById(
                'dd_risk_limit_percent'
            ).value
        );


    if (
        isNaN(balance) ||
        balance <= 0
    ) {

        alert(
            'ERR: Please enter a valid account balance.'
        );

        return;

    }


    if (
        isNaN(riskLimitPercent) ||
        riskLimitPercent <= 0
    ) {

        alert(
            'ERR: Please enter a valid daily risk limit percentage.'
        );

        return;

    }


    const riskLimitAmount =
        balance *
        (riskLimitPercent / 100);


    let currentTotalRiskExposure = 0;


    state.trades.forEach(t => {

        currentTotalRiskExposure +=
            Number(t.risk) || 0;

    });



    /* =========================
       RISK LIMIT CHECK
    ========================= */

    if (
        currentTotalRiskExposure >= riskLimitAmount
    ) {

        alert(
            'ERR_RISK_LIMIT: Daily risk limit reached/exceeded. Trading halted.'
        );

        updateDrawdownInterface();

        return;

    }


    const projectedRiskExposure =
        currentTotalRiskExposure +
        Math.abs(riskAmountInput);


    if (
        projectedRiskExposure > riskLimitAmount
    ) {

        alert(

            'ERR_RISK_LIMIT: This trade would exceed the daily risk limit.\n\n' +

            'Current Risk: $' +
            currentTotalRiskExposure.toFixed(2) +

            '\nTrade Risk: $' +
            Math.abs(riskAmountInput).toFixed(2) +

            '\nRisk Limit: $' +
            riskLimitAmount.toFixed(2) +

            '\n\nTrading halted.'

        );

        updateDrawdownInterface();

        return;

    }



    /* =========================
       GET PROFIT AMOUNT
    ========================= */

    const profitAmountInput =
        parseFloat(
            document.getElementById(
                'dd_profit_amount'
            ).value
        );


    if (
        outcome === 'profit' &&
        (
            isNaN(profitAmountInput) ||
            profitAmountInput <= 0
        )
    ) {

        alert(
            'ERR: Please enter a valid profit amount.'
        );

        return;

    }



    /* =========================
       P&L CALCULATION
       
       LOSS  = -RISK
       PROFIT = PROFIT INPUT
    ========================= */

    let pnl;


    if (outcome === 'profit') {

        pnl =
            Math.abs(
                profitAmountInput
            );

    } else {

        pnl =
            -Math.abs(
                riskAmountInput
            );

    }



    const now =
        new Date();


    const timeStr =

        String(
            now.getHours()
        ).padStart(2, '0') +

        ':' +

        String(
            now.getMinutes()
        ).padStart(2, '0') +

        ':' +

        String(
            now.getSeconds()
        ).padStart(2, '0');



    /* =========================
       TRADE OBJECT
       
       RISK IS ALWAYS STORED
    ========================= */

    const trade = {

        session:
            activeSession,

        outcome:
            outcome,

        pnl:
            pnl,

        risk:
            Math.abs(
                riskAmountInput
            ),

        time:
            timeStr

    };


    state.trades.push(
        trade
    );



    /* =========================
       SESSION LOSS LOGIC
    ========================= */

    if (
        activeSession === '1'
    ) {

        if (
            outcome === 'loss'
        ) {

            state.session1Losses++;


            if (
                state.session1Losses >= 3
            ) {

                state.session1Expired =
                    true;

            }

        } else {

            state.session1Losses = 0;

        }

    }

    else if (
        activeSession === '2'
    ) {

        if (
            outcome === 'loss'
        ) {

            state.session2Losses++;


            if (
                state.session2Losses >= 3
            ) {

                state.session2Expired =
                    true;

            }

        } else {

            state.session2Losses = 0;

        }

    }



    /* =========================
       DAILY CONSECUTIVE LOSSES
    ========================= */

    let consecutiveLossesCount = 0;


    for (
        let i = state.trades.length - 1;
        i >= 0;
        i--
    ) {

        if (
            state.trades[i].outcome === 'loss'
        ) {

            consecutiveLossesCount++;

        } else {

            break;

        }

    }


    if (
        consecutiveLossesCount >= 2
    ) {

        state.dailyLockoutTriggered =
            true;

    }



    saveDailyState(state);

    updateDrawdownInterface();

}



/* =========================
   UPDATE INTERFACE
========================= */

function updateDrawdownInterface() {

    saveSettings();


    const state =
        loadDailyState();


    const balance =
        parseFloat(
            document.getElementById(
                'dd_account_balance'
            ).value
        ) || 10000;


    const riskLimitPercent =
        parseFloat(
            document.getElementById(
                'dd_risk_limit_percent'
            ).value
        ) || 0;


    const riskLimitAmount =
        balance > 0 && riskLimitPercent > 0
            ? balance * (riskLimitPercent / 100)
            : 0;



    let totalTrades =
        state.trades.length;


    let profitCount = 0;

    let netPnl = 0;

    let grossLoss = 0;

    let totalRiskExposure = 0;



    state.trades.forEach(t => {

        netPnl +=
            Number(t.pnl) || 0;


        /* =========================
           TOTAL RISK EXPOSURE
           
           Every trade contributes
           its risk amount, regardless
           of profit or loss.
        ========================= */

        totalRiskExposure +=
            Number(t.risk) || 0;



        if (
            t.outcome === 'profit'
        ) {

            profitCount++;

        }

        else {

            if (
                Number(t.pnl) < 0
            ) {

                grossLoss +=
                    Math.abs(
                        Number(t.pnl)
                    );

            }

        }

    });



    const profitRate =
        totalTrades > 0
            ? (profitCount / totalTrades) * 100
            : 0;


    const dailyDrawdownPct =
        balance > 0
            ? (grossLoss / balance) * 100
            : 0;


    const totalRiskExposurePct =
        balance > 0
            ? (totalRiskExposure / balance) * 100
            : 0;



    /* =========================
       METRICS
    ========================= */

    document.getElementById(
        'stat_total_trades'
    ).innerText =
        totalTrades;


    document.getElementById(
        'stat_profit_rate'
    ).innerText =
        profitRate.toFixed(1) + '%';


    document.getElementById(
        'stat_net_pnl'
    ).innerText =

        (
            netPnl >= 0
                ? '+$'
                : '-$'
        ) +

        Math.abs(
            netPnl
        ).toFixed(2);


    document.getElementById(
        'stat_daily_dd'
    ).innerText =
        dailyDrawdownPct.toFixed(2) + '%';



    /* =========================
       TOTAL RISK EXPOSURE
    ========================= */

    document.getElementById(
        'stat_total_risk'
    ).innerText =

        '$' +
        totalRiskExposure.toFixed(2);



    /* =========================
       SESSION STATUS
    ========================= */

    const activeSession =
        document.getElementById(
            'dd_active_session'
        ).value;


    let sessionStatusElem =
        document.getElementById(
            'rule_session_status'
        );


    let isCurrentSessionExpired =

        (
            activeSession === '1' &&
            state.session1Expired
        )

        ||

        (
            activeSession === '2' &&
            state.session2Expired
        );



    if (
        isCurrentSessionExpired
    ) {

        sessionStatusElem.innerText =
            'BREACHED (EXPIRED)';


        sessionStatusElem.className =
            'text-xs font-bold text-[#f85149] mt-1';

    }

    else {

        let currentLossStreak =

            activeSession === '1'
                ? state.session1Losses
                : state.session2Losses;


        sessionStatusElem.innerText =
            `SAFE (${currentLossStreak}/3 losses)`;


        sessionStatusElem.className =
            'text-xs font-bold text-[#2ea043] mt-1';

    }



    /* =========================
       DAILY LOCKOUT
    ========================= */

    let lockoutElem =
        document.getElementById(
            'rule_lockout_status'
        );


    let consecutiveLossesCount = 0;


    for (
        let i = state.trades.length - 1;
        i >= 0;
        i--
    ) {

        if (
            state.trades[i].outcome === 'loss'
        ) {

            consecutiveLossesCount++;

        } else {

            break;

        }

    }



    if (
        state.dailyLockoutTriggered
    ) {

        lockoutElem.innerText =
            'BREACHED (LOCKOUT)';


        lockoutElem.className =
            'text-xs font-bold text-[#f85149] mt-1';

    }

    else {

        lockoutElem.innerText =
            `SAFE (${consecutiveLossesCount}/4 losses)`;


        lockoutElem.className =
            'text-xs font-bold text-[#2ea043] mt-1';

    }



    /* =========================
       PROFIT RATE RULE
    ========================= */

    let profitRateElem =
        document.getElementById(
            'rule_profitrate_status'
        );


    if (
        totalTrades < 5
    ) {

        profitRateElem.innerText =
            `PENDING (${totalTrades}/5 trades)`;


        profitRateElem.className =
            'text-xs font-bold text-[#8b949e] mt-1';

    }

    else if (
        profitRate < 40
    ) {

        profitRateElem.innerText =
            `BREACHED (${profitRate.toFixed(1)}%)`;


        profitRateElem.className =
            'text-xs font-bold text-[#f85149] mt-1';

    }

    else {

        profitRateElem.innerText =
            `SAFE (${profitRate.toFixed(1)}%)`;


        profitRateElem.className =
            'text-xs font-bold text-[#2ea043] mt-1';

    }



    /* =========================
       RISK LIMIT
    ========================= */

    let capitalElem =
        document.getElementById(
            'rule_capital_status'
        );


    if (
        riskLimitAmount <= 0
    ) {

        capitalElem.innerText =
            'SET RISK LIMIT';


        capitalElem.className =
            'text-xs font-bold text-[#e3b341] mt-1';

    }

    else if (
        totalRiskExposure > riskLimitAmount
    ) {

        capitalElem.innerText =
            `RISK LIMIT EXCEEDED (${totalRiskExposurePct.toFixed(2)}% / ${riskLimitPercent.toFixed(2)}%)`;


        capitalElem.className =
            'text-xs font-bold text-[#f85149] mt-1';

    }

    else if (
        totalRiskExposure >= riskLimitAmount
    ) {

        capitalElem.innerText =
            `RISK LIMIT REACHED (${totalRiskExposurePct.toFixed(2)}%)`;


        capitalElem.className =
            'text-xs font-bold text-[#f85149] mt-1';

    }

    else {

        capitalElem.innerText =
            `CAN TRADE (${totalRiskExposurePct.toFixed(2)}% / ${riskLimitPercent.toFixed(2)}%)`;


        capitalElem.className =
            'text-xs font-bold text-[#2ea043] mt-1';

    }



    /* =========================
       FREQUENCY CAP
    ========================= */

    let freqElem =
        document.getElementById(
            'rule_frequency_status'
        );


    freqElem.innerText =
        `SESSION ${activeSession} ACTIVE`;


    freqElem.className =
        'text-xs font-bold text-[#2ea043] mt-1';



    /* =========================
       SYSTEM LOCKOUT
    ========================= */

    let systemBadge =
        document.getElementById(
            'system-lockout-badge'
        );


    let isRiskLimitBreached =

        riskLimitAmount > 0 &&

        totalRiskExposure >= riskLimitAmount;


    if (

        state.dailyLockoutTriggered

        ||

        isRiskLimitBreached

        ||

        (
            totalTrades >= 5 &&
            profitRate < 40
        )

    ) {

        systemBadge.innerText =
            'LOCKOUT_ACTIVE';


        systemBadge.className =
            'text-xs font-bold text-[#f85149] px-2 py-1 bg-[#f85149]/10 border border-[#f85149]/30 rounded animate-pulse';

    }

    else {

        systemBadge.innerText =
            'SYSTEM_ACTIVE';


        systemBadge.className =
            'text-xs font-bold text-[#2ea043] px-2 py-1 bg-[#2ea043]/10 border border-[#2ea043]/30 rounded';

    }



    /* =========================
       TRADE LOG
    ========================= */

    const tbody =
        document.getElementById(
            'trade_log_tbody'
        );


    if (
        state.trades.length === 0
    ) {

        tbody.innerHTML = `

            <tr>

                <td
                    colspan="7"
                    class="p-4 text-center text-[#8b949e] italic"
                >
                    No trades recorded for today yet.
                </td>

            </tr>

        `;

        return;

    }



    let html = '';



    state.trades
        .slice()
        .reverse()
        .forEach(
            (t, revIndex) => {


                const actualIndex =
                    state.trades.length -
                    1 -
                    revIndex;


                const displayNum =
                    state.trades.length -
                    revIndex;


                const outcomeBadge =

                    t.outcome === 'profit'

                        ?

                        `<span class="text-[#2ea043] font-bold">PROFIT</span>`

                        :

                        `<span class="text-[#f85149] font-bold">LOSS</span>`;


                const pnlValue =
                    Number(t.pnl) || 0;


                const pnlDisplay =

                    pnlValue >= 0

                        ?

                        `+$${pnlValue.toFixed(2)}`

                        :

                        `-$${Math.abs(pnlValue).toFixed(2)}`;


                const pnlColor =

                    pnlValue >= 0

                        ?

                        'text-[#2ea043]'

                        :

                        'text-[#f85149]';


                const riskDisplay =

                    Number(t.risk || 0).toFixed(2);



                html += `

                    <tr class="hover:bg-[#161b22]">

                        <td class="p-2.5 text-[#8b949e]">
                            #${displayNum}
                        </td>


                        <td class="p-2.5">
                            Session ${t.session}
                        </td>


                        <td class="p-2.5">
                            ${outcomeBadge}
                        </td>


                        <td class="p-2.5 font-bold text-[#e3b341]">
                            $${riskDisplay}
                        </td>


                        <td class="p-2.5 font-bold ${pnlColor}">
                            ${pnlDisplay}
                        </td>


                        <td class="p-2.5 text-[#8b949e]">
                            ${t.time}
                        </td>


                        <td class="p-2.5 text-right">

                            <button
                                onclick="deleteTrade(${actualIndex})"
                                class="text-[10px] text-[#f85149] bg-[#f85149]/10 hover:bg-[#f85149]/20 border border-[#f85149]/30 px-2 py-1 rounded uppercase"
                            >
                                Delete
                            </button>

                        </td>

                    </tr>

                `;

            }
        );


    tbody.innerHTML =
        html;

}



/* =========================
   PAGE LOAD
========================= */

window.addEventListener(
    'load',
    function() {

        loadSettings();

        updateDrawdownInterface();


        document
            .getElementById(
                'dd_active_session'
            )
            ?.addEventListener(
                'change',
                updateDrawdownInterface
            );


        document
            .getElementById(
                'dd_account_balance'
            )
            ?.addEventListener(
                'input',
                updateDrawdownInterface
            );


        document
            .getElementById(
                'dd_risk_amount'
            )
            ?.addEventListener(
                'input',
                updateDrawdownInterface
            );


        document
            .getElementById(
                'dd_profit_amount'
            )
            ?.addEventListener(
                'input',
                updateDrawdownInterface
            );


        document
            .getElementById(
                'dd_risk_limit_percent'
            )
            ?.addEventListener(
                'input',
                updateDrawdownInterface
            );

    }
);

</script>

</body>
</html>
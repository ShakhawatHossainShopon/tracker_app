<?php
date_default_timezone_set('Asia/Dhaka'); 

$host = 'sql102.infinityfree.com'; 
$db   = 'if0_40135421_trade_tracker'; 
$user = 'if0_40135421'; 
$pass = 'WasasCNrbr'; 
$dsn = "mysql:host=$host;dbname=$db;charset=utf8";

try {
    $pdo = new PDO($dsn, $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
} catch (PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

// Filter selection
$filter = $_GET['filter_by'] ?? '';
$filterSQL = '';
$params = [];

if($filter === 'day') {
    $filterSQL = "WHERE DATE(open_time) = CURDATE()";
} elseif($filter === 'week') {
    $filterSQL = "WHERE YEARWEEK(open_time, 1) = YEARWEEK(CURDATE(), 1)";
} elseif($filter === 'month') {
    $filterSQL = "WHERE MONTH(open_time) = MONTH(CURDATE()) AND YEAR(open_time) = YEAR(CURDATE())";
} elseif($filter === 'year') {
    $filterSQL = "WHERE YEAR(open_time) = YEAR(CURDATE())";
}

// Fetch totals grouped by session
$stmt = $pdo->prepare("
    SELECT s.id, s.session_name,
           SUM(CASE WHEN t.trade_number>1 AND t.status='win' THEN t.balance_change ELSE 0 END) AS total_profit,
           SUM(CASE WHEN t.trade_number>1 AND t.status='loss' THEN ABS(t.balance_change) ELSE 0 END) AS total_loss,
           COUNT(CASE WHEN t.trade_number>1 THEN 1 END) AS total_trades,
           COUNT(CASE WHEN t.trade_number>1 AND t.status='win' THEN 1 END) AS total_wins,
           COUNT(CASE WHEN t.trade_number>1 AND t.status='loss' THEN 1 END) AS total_losses
    FROM sessions s
    LEFT JOIN trades t ON t.session_id = s.id
    $filterSQL
    GROUP BY s.id, s.session_name
    ORDER BY s.id DESC
");
$stmt->execute($params);
$sessions = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate grand totals for all sessions
$grand_total_trades = $grand_total_wins = $grand_total_losses = 0;
$grand_total_profit = $grand_total_loss = 0;

foreach($sessions as $s){
    $grand_total_trades += $s['total_trades'];
    $grand_total_wins += $s['total_wins'];
    $grand_total_losses += $s['total_losses'];
    $grand_total_profit += $s['total_profit'];
    $grand_total_loss += $s['total_loss'];
}

// Correct Average Risk Reward Ratio
$avg_rr = 0;
if ($grand_total_loss > 0 && $grand_total_profit > 0) {
    $avg_rr = $grand_total_profit / $grand_total_loss;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Session Analytics | Grand Totals</title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<style>
    body {
        font-family: 'Plus Jakarta Sans', sans-serif;
        background-color: #060913;
        background-image: radial-gradient(circle at 50% 0%, rgba(56, 189, 248, 0.04) 0%, transparent 50%);
        color: #f8fafc;
    }
    .font-mono-num {
        font-family: 'JetBrains Mono', monospace;
    }
</style>
</head>
<body class="min-h-screen flex items-center justify-center py-10 px-4">

<div class="bg-[#0f172a] border border-white/5 rounded-2xl shadow-2xl p-6 sm:p-8 w-full max-w-6xl backdrop-blur-xl">

    <div class="flex flex-col md:flex-row justify-between items-center gap-4 mb-8 pb-6 border-b border-white/10">
        <div>
            <h2 class="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
                <span class="inline-block w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse"></span>
                Grand Totals by Session
            </h2>
            <p class="text-xs text-slate-400 mt-1">Aggregated session analytics, win metrics, and performance ratios</p>
        </div>

        <form method="get" class="flex items-center gap-2.5 bg-[#1e293b]/70 p-1.5 rounded-xl border border-white/5">
            <label class="text-xs font-semibold text-slate-400 pl-2">Filter:</label>
            <select name="filter_by" class="bg-[#0f172a] text-slate-200 text-xs font-medium border border-slate-700 rounded-lg px-3 py-2 outline-none focus:border-cyan-400 transition">
                <option value="">All Time</option>
                <option value="day" <?= ($filter==='day')?'selected':'' ?>>Today</option>
                <option value="week" <?= ($filter==='week')?'selected':'' ?>>This Week</option>
                <option value="month" <?= ($filter==='month')?'selected':'' ?>>This Month</option>
                <option value="year" <?= ($filter==='year')?'selected':'' ?>>This Year</option>
            </select>
            <button type="submit" class="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white text-xs font-semibold px-4 py-2 rounded-lg shadow-lg shadow-cyan-500/10 transition">Apply</button>
        </form>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
        <div class="bg-gradient-to-br from-emerald-950/30 to-[#1e293b] border border-emerald-500/20 rounded-xl p-5 relative overflow-hidden shadow-lg">
            <div class="absolute top-0 left-0 w-1 h-full bg-emerald-500"></div>
            <h3 class="text-xs font-semibold uppercase tracking-wider text-emerald-400/90 mb-1">Win Percentage Rate</h3>
            <p class="text-3xl font-bold font-mono-num text-emerald-400">
                <?= $grand_total_trades>0 ? number_format(($grand_total_wins/$grand_total_trades)*100,2) : '0' ?><span class="text-lg text-emerald-500/70">%</span>
            </p>
        </div>

        <div class="bg-gradient-to-br from-amber-950/30 to-[#1e293b] border border-amber-500/20 rounded-xl p-5 relative overflow-hidden shadow-lg">
            <div class="absolute top-0 left-0 w-1 h-full bg-amber-500"></div>
            <h3 class="text-xs font-semibold uppercase tracking-wider text-amber-400/90 mb-1">Average Risk-to-Reward</h3>
            <p class="text-3xl font-bold font-mono-num text-amber-400">
                1 : <?= number_format($avg_rr, 2) ?>
            </p>
        </div>
    </div>

    <div class="overflow-x-auto rounded-xl border border-white/5">
        <table class="min-w-full text-left border-collapse">
            <thead>
                <tr class="bg-[#1e293b] text-slate-400 text-xs font-semibold uppercase tracking-wider text-center border-b border-white/5">
                    <th class="p-3.5 text-left pl-5">Session Name</th>
                    <th class="p-3.5">Total Trades</th>
                    <th class="p-3.5">Wins</th>
                    <th class="p-3.5">Losses</th>
                    <th class="p-3.5">Total Profit</th>
                    <th class="p-3.5">Total Loss</th>
                    <th class="p-3.5 pr-5">Grand P&L</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-white/5 text-sm text-center">
                <?php foreach($sessions as $s): ?>
                <?php $sessionNet = $s['total_profit'] - $s['total_loss']; ?>
                <tr class="hover:bg-white/[0.02] transition">
                    <td class="p-3.5 text-left pl-5 font-semibold text-slate-200"><?= htmlspecialchars($s['session_name']) ?></td>
                    <td class="p-3.5 font-mono-num text-slate-300"><?= $s['total_trades'] ?></td>
                    <td class="p-3.5 font-mono-num text-emerald-400"><?= $s['total_wins'] ?></td>
                    <td class="p-3.5 font-mono-num text-rose-400"><?= $s['total_losses'] ?></td>
                    <td class="p-3.5 font-mono-num text-emerald-400 font-medium">+<?= number_format($s['total_profit'],2) ?></td>
                    <td class="p-3.5 font-mono-num text-rose-400 font-medium">-<?= number_format($s['total_loss'],2) ?></td>
                    <td class="p-3.5 pr-5 font-mono-num font-bold <?= ($sessionNet >= 0)?'text-emerald-400':'text-rose-400' ?>">
                        <?= ($sessionNet >= 0 ? '+' : '-').number_format(abs($sessionNet),2) ?>
                    </td>
                </tr>
                <?php endforeach; ?>

                <?php if(empty($sessions)): ?>
                <tr>
                    <td colspan="7" class="p-6 text-center text-slate-500 text-sm">No session data found for the selected filter.</td>
                </tr>
                <?php endif; ?>

                <?php $grandNet = $grand_total_profit - $grand_total_loss; ?>
                <tr class="bg-[#1e293b]/90 font-bold text-center border-t border-white/10">
                    <td class="p-4 text-left pl-5 text-cyan-400 tracking-wide">All Sessions Total</td>
                    <td class="p-4 font-mono-num text-white"><?= $grand_total_trades ?></td>
                    <td class="p-4 font-mono-num text-emerald-400"><?= $grand_total_wins ?></td>
                    <td class="p-4 font-mono-num text-rose-400"><?= $grand_total_losses ?></td>
                    <td class="p-4 font-mono-num text-emerald-400">+<?= number_format($grand_total_profit,2) ?></td>
                    <td class="p-4 font-mono-num text-rose-400">-<?= number_format($grand_total_loss,2) ?></td>
                    <td class="p-4 pr-5 font-mono-num <?= ($grandNet >= 0)?'text-emerald-400':'text-rose-400' ?>">
                        <?= ($grandNet >= 0 ? '+' : '-').number_format(abs($grandNet),2) ?>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

</div>

</body>
</html>
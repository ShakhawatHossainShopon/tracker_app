<?php
    error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
date_default_timezone_set('Asia/Dhaka'); // Set your local timezone

$host = 'sql102.infinityfree.com'; 
$db   = 'if0_40135421_trade_tracker'; 
$user = 'if0_40135421'; 
$pass = 'WasasCNrbr'; 
$dsn = "mysql:host=$host;dbname=$db;charset=utf8";

try {
    $pdo = new PDO($dsn, $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
} catch (PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

// CREATE NEW SESSION
if(isset($_POST['new_session'])){
    $sessionName = $_POST['session_name'] ?: "Session " . date('Y-m-d H:i');
    $pdo->prepare("INSERT INTO sessions (session_name) VALUES (?)")->execute([$sessionName]);
    $sessionId = $pdo->lastInsertId();

    $balance = floatval($_POST['initial_balance']);
    $openTime = date('Y-m-d H:i:s');

    $stmt = $pdo->prepare("
        INSERT INTO trades 
        (session_id, trade_number, result, stop_loss, target_profit, balance_change, cumulative_balance, status, open_time)
        VALUES (?, 1, 'start', 0, 0, ?, ?, 'win', ?)
    ");
    $stmt->execute([$sessionId, $balance, $balance, $openTime]);

    header("Location: ".$_SERVER['PHP_SELF']."?session=".$sessionId);
    exit;
}

// DELETE SESSION
if(isset($_POST['delete_session'])){
    $sessionIdToDelete = intval($_POST['session_id']);
    $pdo->prepare("DELETE FROM sessions WHERE id=?")->execute([$sessionIdToDelete]);
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// SELECT SESSION
$sessionId = isset($_GET['session']) ? intval($_GET['session']) : null;

// FETCH SESSIONS
$sessions = $pdo->query("SELECT * FROM sessions ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);

// DELETE TRADE via GET
if(isset($_GET['delete_trade'], $_GET['trade_id'], $_GET['session_id'])){
    $tradeId = intval($_GET['trade_id']);
    $sessionId = intval($_GET['session_id']);
    $pdo->prepare("DELETE FROM trades WHERE id=?")->execute([$tradeId]);
    header("Location: ".$_SERVER['PHP_SELF']."?session=".$sessionId);
    exit;
}

// SAVE NEW TRADE
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['session_id']) && !isset($_POST['new_session']) && !isset($_POST['delete_trade']) && !isset($_POST['delete_session']) && !isset($_POST['update_trade'])){
    $sessionId = intval($_POST['session_id']);
    $sl = floatval($_POST['sl']);
    $tp = floatval($_POST['tp']);
    $result = $_POST['res'];
    $ticker = strtoupper($_POST['ticker']);
    $tradeType = $_POST['trade_type'];
    $buyAt = floatval($_POST['buy_at']);
    $timeframe = trim($_POST['timeframe']);
    $gradeId = intval($_POST['grade_id']);
    
    $stmt = $pdo->prepare("SELECT IFNULL(MAX(trade_number),0)+1 FROM trades WHERE session_id=?");
    $stmt->execute([$sessionId]);
    $nextTradeNumber = $stmt->fetchColumn();

    $balanceChange = ($result === 'open') ? 0 : (($result==='win')?$tp:-$sl);
    $status = $result==='open'?'open':$result;

    $stmt = $pdo->prepare("SELECT cumulative_balance FROM trades WHERE session_id=? ORDER BY trade_number DESC LIMIT 1");
    $stmt->execute([$sessionId]);
    $lastBalance = $stmt->fetchColumn() ?: 0;
    $cumulativeBalance = $lastBalance + $balanceChange;

    $openTime = date('Y-m-d H:i:s');
    $closeTime = ($status !== 'open') ? date('Y-m-d H:i:s') : null;

    $stmt = $pdo->prepare("
        INSERT INTO trades 
        (session_id, trade_number, ticker, trade_type, result, stop_loss, target_profit, balance_change, cumulative_balance, status, open_time, close_time, buy_at, timeframe, grade_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([$sessionId, $nextTradeNumber, $ticker, $tradeType, $result, $sl, $tp, $balanceChange, $cumulativeBalance, $status, $openTime, $closeTime, $buyAt, $timeframe, $gradeId]);

    header("Location: ".$_SERVER['PHP_SELF']."?session=".$sessionId);
    exit;
}

// UPDATE OPEN TRADE & RECALCULATE BALANCE
if(isset($_POST['update_trade'])){
    $tradeId = intval($_POST['trade_id']);
    $sessionId = intval($_POST['session_id']);
    $status = $_POST['status'];
    $profit = floatval($_POST['profit_loss']);
    $closeTime = ($status !== 'open') ? date('Y-m-d H:i:s') : null;

    $stmt = $pdo->prepare("UPDATE trades SET status=?, balance_change=?, result=?, close_time=? WHERE id=?");
    $stmt->execute([$status, $profit, $status, $closeTime, $tradeId]);

    // Recalculate cumulative balances
    $stmt = $pdo->prepare("SELECT id, balance_change FROM trades WHERE session_id=? ORDER BY trade_number ASC");
    $stmt->execute([$sessionId]);
    $allTrades = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $cumulative = 0;
    foreach($allTrades as $index => $t){
        if($index === 0){
            $cumulative = $t['balance_change'];
        } else {
            $cumulative += $t['balance_change'];
        }
        $stmt2 = $pdo->prepare("UPDATE trades SET cumulative_balance=? WHERE id=?");
        $stmt2->execute([$cumulative, $t['id']]);
    }

    header("Location: ".$_SERVER['PHP_SELF']."?session=".$sessionId);
    exit;
}

// FETCH TRADES
$trades = [];
if($sessionId){
    $stmt = $pdo->prepare("SELECT * FROM trades WHERE session_id=? ORDER BY trade_number ASC");
    $stmt->execute([$sessionId]);
    $trades = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// SUMMARY
$totalTrades = $totalWins = $totalLosses = $totalProfit = $totalLoss = 0;
foreach($trades as $t){
    if($t['trade_number']==1) continue;
    $totalTrades++;
    if($t['status']==='win'){ 
        $totalWins++; 
        $totalProfit += $t['balance_change']; 
    } elseif($t['status']==='loss'){ 
        $totalLosses++; 
        $totalLoss += abs($t['balance_change']); 
    }
}
$cumulativeBalance = $trades ? end($trades)['cumulative_balance'] : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Trade Tracker Sessions</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
@keyframes terminalPulse {
    0%, 100% { opacity: 1; transform: translateY(0); }
    50% { opacity: 0.5; transform: translateY(-1px); }
}
.animate-terminal-pulse {
    animation: terminalPulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite;
}
</style>
</head>
<body class="bg-[#0b0e14] text-[#8b949e] font-mono min-h-screen flex items-center justify-center p-4">

<div class="bg-[#161b22] border border-[#30363d] rounded-md shadow-2xl w-full max-w-7xl overflow-hidden">
    
    <!-- Top Terminal Bar -->
    <div class="bg-[#21262d] px-4 py-3 border-b border-[#30363d] flex justify-between items-center">
        <div class="flex items-center gap-2">
            <span class="w-3 h-3 rounded-full bg-[#f85149] inline-block"></span>
            <span class="w-3 h-3 rounded-full bg-[#e3b341] inline-block"></span>
            <span class="w-3 h-3 rounded-full bg-[#2ea043] inline-block"></span>
            <span class="text-xs text-[#c9d1d9] font-bold ml-2 tracking-wider">EXECUTION_TERMINAL // SESSION_MANAGER</span>
        </div>
        <div class="text-xs text-[#8b949e]" id="terminal-clock">00:00:00</div>
    </div>

    <div class="p-6">

        <!-- Navigation Links -->
        <div class="w-full flex justify-end gap-2 flex-wrap mb-6 border-b border-[#30363d] pb-4">
            <!--  <a href="Profit_Scaling.pdf" target="_blank" class="bg-[#21262d] hover:bg-[#30363d] border border-[#30363d] text-[#c9d1d9] px-3 py-1.5 rounded text-xs transition">
                PROFIT SCALING
            </a>
             <a href="risk_management.pdf" target="_blank" class="bg-[#21262d] hover:bg-[#30363d] border border-[#30363d] text-[#c9d1d9] px-3 py-1.5 rounded text-xs transition">
                RISK MANAGEMENT
            </a>

			-->             <a href="backtest.php" target="_blank" class="bg-[#21262d] hover:bg-[#30363d] border border-[#30363d] text-[#c9d1d9] px-3 py-1.5 rounded text-xs transition">
                BACKTEST
            </a>
            <a href="daily_drawdown.php" target="_blank" class="bg-[#21262d] hover:bg-[#30363d] border border-[#30363d] text-[#c9d1d9] px-3 py-1.5 rounded text-xs transition">
                DAILY DRAWDOWN
            </a>
     		<!--
      		 <a href="breaker_block_stratergy.php" target="_blank" class="bg-[#21262d] hover:bg-[#30363d] border border-[#30363d] text-[#c9d1d9] px-3 py-1.5 rounded text-xs transition">
                STRATERGY
            </a>
			-->
            <a href="session.php" class="bg-[#21262d] hover:bg-[#30363d] border border-[#30363d] text-[#c9d1d9] px-3 py-1.5 rounded text-xs transition">
                SESSION
            </a>
            <a href="checker.php" class="bg-[#21262d] hover:bg-[#30363d] border border-[#30363d] text-[#c9d1d9] px-3 py-1.5 rounded text-xs transition">
                CHECKER
            </a>
            <a href="calculation.php" class="bg-[#238636] hover:bg-[#2ea043] text-white px-3 py-1.5 rounded text-xs font-bold transition border border-[#2ea043]">
                TRACKER
            </a>
        </div>

        <h2 class="text-sm font-bold text-[#c9d1d9] uppercase tracking-wider text-center mb-6">Trade Tracker with Local Time</h2>

        <!-- SESSION SELECTOR -->
        <div class="flex flex-wrap gap-2 mb-6 items-center justify-between bg-[#0d1117] p-4 rounded border border-[#30363d]">
            <form method="post" class="flex flex-wrap gap-2 w-full sm:w-auto items-center">
                <input type="text" name="session_name" placeholder="Session Name" class="bg-[#161b22] border border-[#30363d] rounded p-2 text-xs text-[#c9d1d9] focus:border-[#58a6ff] outline-none flex-1 min-w-[120px]">
                <input type="number" step="0.01" name="initial_balance" placeholder="Starting Balance" class="bg-[#161b22] border border-[#30363d] rounded p-2 text-xs text-[#c9d1d9] focus:border-[#58a6ff] outline-none flex-1 min-w-[120px]" required>
                <button type="submit" name="new_session" class="bg-[#238636] hover:bg-[#2ea043] text-white rounded px-4 py-2 text-xs font-bold uppercase transition border border-[#2ea043]">New Session</button>
                <a href="grand_totals.php" class="bg-[#21262d] hover:bg-[#30363d] border border-[#30363d] text-[#c9d1d9] px-4 py-2 rounded text-xs font-bold transition">
                    Accounts
                </a>
            </form>

            <div class="flex flex-wrap gap-2 w-full sm:w-auto items-center mt-2 sm:mt-0">
                <select onchange="location=this.value" class="bg-[#161b22] border border-[#30363d] rounded p-2 text-xs text-[#c9d1d9] focus:border-[#58a6ff] outline-none flex-1 min-w-[150px]">
                    <option value="">Select Session</option>
                    <?php foreach($sessions as $s): ?>
                    <option value="?session=<?= $s['id'] ?>" <?= $sessionId==$s['id']?'selected':'' ?>><?= htmlspecialchars($s['session_name']) ?></option>
                    <?php endforeach; ?>
                </select>

                <?php if($sessionId): ?>
                <form method="post" class="inline">
                    <input type="hidden" name="session_id" value="<?= $sessionId ?>">
                    <button type="submit" name="delete_session" class="bg-[#da3633]/20 hover:bg-[#da3633]/30 border border-[#f85149]/40 text-[#f85149] rounded px-3 py-2 text-xs font-bold transition">Delete Session</button>
                </form>
                <?php endif; ?>
            </div>
        </div>

        <?php if($sessionId): ?>
        <form method="post" class="flex flex-wrap gap-2 items-center mb-6 bg-[#0d1117] p-4 rounded border border-[#30363d]">
            <input type="hidden" name="session_id" value="<?= $sessionId ?>">
            <input type="text" name="ticker" placeholder="Stock Ticker" class="bg-[#161b22] border border-[#30363d] rounded p-2 text-xs text-[#c9d1d9] focus:border-[#58a6ff] outline-none w-28" required>
            <select name="trade_type" class="bg-[#161b22] border border-[#30363d] rounded p-2 text-xs text-[#c9d1d9] focus:border-[#58a6ff] outline-none w-24">
                <option value="buy">Buy</option>
                <option value="sell">Sell</option>
            </select>
            <input type="number" name="sl" step="0.01" placeholder="SL" class="bg-[#161b22] border border-[#30363d] rounded p-2 text-xs text-[#c9d1d9] focus:border-[#58a6ff] outline-none w-24" required>
            <input type="number" name="tp" step="0.01" placeholder="TP" class="bg-[#161b22] border border-[#30363d] rounded p-2 text-xs text-[#c9d1d9] focus:border-[#58a6ff] outline-none w-24" required>
            <select name="res" class="bg-[#161b22] border border-[#30363d] rounded p-2 text-xs text-[#c9d1d9] focus:border-[#58a6ff] outline-none">
                <option value="win">Win</option>
                <option value="loss">Loss</option>
            </select>
            <button type="submit" class="bg-[#238636] hover:bg-[#2ea043] text-white rounded px-4 py-2 text-xs font-bold uppercase transition border border-[#2ea043]">Next Trade</button>
        </form>

        <?php if($trades): ?>
        <div class="overflow-x-auto border border-[#30363d] rounded bg-[#0d1117]">
            <table class="min-w-full text-center">
                <thead class="bg-[#21262d] text-[#c9d1d9] text-xs border-b border-[#30363d]">
                    <tr>
                        <th class="p-3">Trade</th>
                        <th class="p-3">Stock</th>
                        <th class="p-3">Type</th>
                        <th class="p-3">Status</th>
                        <th class="p-3">SL</th>
                        <th class="p-3">TP</th>
                        <th class="p-3">Profit/Loss</th>
                        <th class="p-3">Balance</th>
                        <th class="p-3">Open Time</th>
                        <th class="p-3">Action</th>
                    </tr>
                </thead>
                <tbody class="text-center bg-[#0d1117] text-xs">
                <?php 
                $displayTradeNumber = 1;
                foreach($trades as $t): 
                    $rowBg = 'hover:bg-[#161b22] border-b border-[#30363d]';
                    if($t['status'] === 'win') $rowBg .= ' bg-[#2ea043]/5 text-[#c9d1d9]';
                    elseif($t['status'] === 'loss') $rowBg .= ' bg-[#da3633]/5 text-[#c9d1d9]';
                    else $rowBg .= ' text-[#c9d1d9]';
                ?>
                    <tr class="<?= $rowBg ?>">
                        <td class="p-3"><?= $t['trade_number']==1?'':$displayTradeNumber++ ?></td>
                        <td class="p-3"><?= $t['trade_number']==1?'':htmlspecialchars($t['ticker']) ?></td>
                        <td class="p-3"><?= $t['trade_number']==1?'':ucfirst($t['trade_type']) ?></td>
                        <td class="p-3 <?= $t['status'] == 'open' ? 'text-[#e3b341] font-bold' : ($t['status']=='win'?'text-[#2ea043] font-bold':'text-[#f85149] font-bold') ?>">
                          <?= ucfirst($t['status']) ?>
                        </td>
                        <td class="p-3"><?= $t['trade_number']==1?'':number_format($t['stop_loss'],2) ?></td>
                        <td class="p-3"><?= $t['trade_number']==1?'':number_format($t['target_profit'],2) ?></td>
                        <td class="p-3"><?= $t['trade_number']==1?'':number_format($t['balance_change'],2) ?></td>
                        <td class="p-3 font-bold text-[#58a6ff]"><?= number_format($t['cumulative_balance'],2) ?></td>
                        <td class="p-3 text-[#8b949e]"><?= date('h:i A', strtotime($t['open_time'])) ?></td>
                        <td class="p-3">
                        <?php if($t['trade_number'] != 1): ?>
                          <div class="relative inline-block w-full text-left">
                            <select 
                              onchange="if(this.value) window.location=this.value" 
                              class="bg-[#161b22] border border-[#30363d] rounded p-1.5 text-xs text-[#c9d1d9] focus:outline-none focus:border-[#58a6ff] transition">
                              <option value="">Select Action</option>
                              <option value="?delete_trade=1&trade_id=<?= $t['id'] ?>&session_id=<?= $sessionId ?>">Delete</option>
                              <option value="take_note.php?trade_id=<?= $t['id'] ?>">Take Note</option>
                              <option value="view_notes.php?trade_id=<?= $t['id'] ?>">View Notes</option>
                            </select>
                          </div>
                        <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-6 bg-[#0d1117] border border-[#30363d] p-4 rounded text-xs space-y-1.5">
            <p class="text-[#c9d1d9]">Total Trades: <span class="font-bold text-[#58a6ff]"><?= $totalTrades ?></span></p>
            <p class="text-[#c9d1d9]">Total Wins: <span class="font-bold text-[#2ea043]"><?= $totalWins ?></span> | Total Profit: <span class="text-[#2ea043] font-bold">+<?= number_format($totalProfit,2) ?></span></p>
            <p class="text-[#c9d1d9]">Total Losses: <span class="font-bold text-[#f85149]"><?= $totalLosses ?></span> | Total Loss: <span class="text-[#f85149] font-bold">-<?= number_format($totalLoss,2) ?></span></p>
            <p class="<?= ($totalProfit - $totalLoss) >= 0 ? 'text-[#2ea043]' : 'text-[#f85149]' ?> font-bold text-sm pt-1 border-t border-[#30363d]">Grand Total: <?= ($totalProfit - $totalLoss) >= 0 ? '+' : '-' ?><?= number_format(abs($totalProfit - $totalLoss),2) ?></p>
            <p class="text-[#c9d1d9]">Cumulative Balance: <span class="font-bold text-[#58a6ff]"><?= number_format($cumulativeBalance,2) ?></span></p>
        </div>
        <?php endif; ?>
        <?php endif; ?>

    </div>
</div>

<script>
setInterval(() => {
    const now = new Date();
    document.getElementById('terminal-clock').innerText = now.toLocaleTimeString();
}, 1000);
</script>
</body>
</html>
<?php
date_default_timezone_set('Asia/Dhaka');

/* =========================
   DATABASE
========================= */

$host = 'sql102.infinityfree.com';
$db   = 'if0_40135421_trade_tracker';
$user = 'if0_40135421';
$pass = 'WasasCNrbr';
$dsn  = "mysql:host=$host;dbname=$db;charset=utf8";

try {

    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);

    /*
     * NEW TABLE
     *
     * Duration is stored in exact seconds.
     * The interface accepts minutes.
     */

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS trading_time_logs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            workspace VARCHAR(100) NOT NULL,
            duration_seconds INT UNSIGNED NOT NULL,
            completed_at DATETIME NOT NULL,
            INDEX idx_completed_at (completed_at)
        )
    ");

} catch (PDOException $e) {

    die(
        "DB Connection failed: " .
        htmlspecialchars($e->getMessage())
    );

}


/* =========================
   SAVE COMPLETED SESSION
========================= */

if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['save_session'])
) {

    header('Content-Type: application/json');

    $workspace = trim(
        $_POST['workspace'] ?? 'Execution Desk'
    );

    $seconds = intval(
        $_POST['duration_seconds'] ?? 0
    );

    if ($workspace === '') {
        $workspace = 'Execution Desk';
    }

    if ($seconds <= 0) {

        echo json_encode([
            'status' => 'error',
            'message' => 'Invalid duration'
        ]);

        exit;
    }


    try {

        $stmt = $pdo->prepare("
            INSERT INTO trading_time_logs
            (
                workspace,
                duration_seconds,
                completed_at
            )
            VALUES (?, ?, ?)
        ");

        $stmt->execute([
            $workspace,
            $seconds,
            date('Y-m-d H:i:s')
        ]);


        echo json_encode([
            'status' => 'success'
        ]);

    } catch (PDOException $e) {

        echo json_encode([
            'status' => 'error',
            'message' => $e->getMessage()
        ]);

    }

    exit;
}


/* =========================
   TIME STATISTICS (SYNCHRONIZED WITH ASIA/DHAKA)
========================= */

$currentDate = date('Y-m-d');
$currentYear = date('Y');
$currentMonth = date('m');

// Calculate ISO Week bounds (Monday to Sunday) using PHP to ensure absolute accuracy
$dto = new DateTime();
$dto->setISODate(intval(date('o')), intval(date('W')));
$startOfWeek = $dto->format('Y-m-d');
$dto->modify('+6 days');
$endOfWeek = $dto->format('Y-m-d');

$dailyTotal = $pdo->query("
    SELECT COALESCE(
        SUM(duration_seconds),
        0
    )
    FROM trading_time_logs
    WHERE DATE(completed_at) = '$currentDate'
")->fetchColumn();


$weeklyTotal = $pdo->query("
    SELECT COALESCE(
        SUM(duration_seconds),
        0
    )
    FROM trading_time_logs
    WHERE DATE(completed_at) BETWEEN '$startOfWeek' AND '$endOfWeek'
")->fetchColumn();


$monthlyTotal = $pdo->query("
    SELECT COALESCE(
        SUM(duration_seconds),
        0
    )
    FROM trading_time_logs
    WHERE YEAR(completed_at) = $currentYear
      AND MONTH(completed_at) = $currentMonth
")->fetchColumn();


/* =========================
   EXACT TIME FORMATTER
========================= */

function formatExactTime($seconds)
{

    $seconds = max(
        0,
        intval($seconds)
    );


    $hours = intdiv(
        $seconds,
        3600
    );


    $minutes = intdiv(
        $seconds % 3600,
        60
    );


    $remainingSeconds =
        $seconds % 60;


    /*
     * Hours + minutes
     */

    if ($hours > 0) {

        if ($minutes > 0) {

            return $hours .
                ' hr' .
                ($hours !== 1 ? 's' : '') .
                ' ' .
                $minutes .
                ' min';

        }

        return $hours .
            ' hr' .
            ($hours !== 1 ? 's' : '');

    }


    /*
     * Minutes only
     */

    if ($minutes > 0) {

        if ($remainingSeconds > 0) {

            return $minutes .
                ' min ' .
                $remainingSeconds .
                ' sec';

        }

        return $minutes .
            ' min';

    }


    /*
     * Seconds only
     */

    return $remainingSeconds . ' sec';

}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>Terminal Workspace</title>

<script src="https://cdn.tailwindcss.com"></script>

<style>

@keyframes terminalPulse {

    0%, 100% {
        opacity: 1;
        transform: translateY(0);
    }

    50% {
        opacity: 0.5;
        transform: translateY(-1px);
    }

}

.animate-terminal-pulse {

    animation:
        terminalPulse
        3s cubic-bezier(0.4, 0, 0.6, 1)
        infinite;

}

</style>

</head>


<body
    class="bg-[#0b0e14] text-[#8b949e] font-mono min-h-screen flex items-center justify-center p-4"
>


<div
    class="bg-[#161b22] border border-[#30363d] rounded-md shadow-2xl w-full max-w-2xl overflow-hidden"
>


    <!-- TOP TERMINAL BAR -->

    <div
        class="bg-[#21262d] px-4 py-3 border-b border-[#30363d] flex justify-between items-center"
    >

        <div class="flex items-center gap-2">

            <span class="w-3 h-3 rounded-full bg-[#f85149] inline-block"></span>

            <span class="w-3 h-3 rounded-full bg-[#e3b341] inline-block"></span>

            <span class="w-3 h-3 rounded-full bg-[#2ea043] inline-block"></span>

            <span
                class="text-xs text-[#c9d1d9] font-bold ml-2 tracking-wider"
            >
                EXECUTION_TERMINAL_v3.0 // SESSION_TIMELINE
            </span>

        </div>


        <div
            class="text-xs text-[#8b949e]"
            id="terminal-clock"
        >
            00:00:00
        </div>

    </div>



    <div class="p-6">


        <!-- HEADER -->

        <div
            class="flex justify-between items-center mb-6 border-b border-[#30363d] pb-4"
        >

            <div>

                <h1
                    class="text-sm font-bold text-[#c9d1d9] uppercase tracking-wider"
                >
                    Terminal Time Tracker
                </h1>


                <p class="text-xs text-[#8b949e] mt-1">

                    Status:

                    <span
                        id="status-text"
                        class="text-[#2ea043]"
                    >
                        STANDBY_READY
                    </span>

                </p>

            </div>


            <a
                href="index.php"
                class="bg-[#21262d] hover:bg-[#30363d] border border-[#30363d] text-[#c9d1d9] px-3 py-1.5 rounded text-xs transition"
            >
                [ RETURN_TO_DASHBOARD ]
            </a>

        </div>



        <!-- QUOTE -->

        <div
            class="bg-[#0d1117] border border-[#30363d] rounded p-3 mb-6 flex items-start gap-3 animate-terminal-pulse"
        >

            <span
                class="text-[#58a6ff] text-xs font-bold whitespace-nowrap"
            >
                WISDOM://
            </span>


            <p
                id="quote-box"
                class="text-xs text-[#c9d1d9] italic leading-relaxed"
            >
                "The market is a device for transferring money from the impatient to the patient."
            </p>

        </div>



        <!-- SETUP -->

        <div
            id="setup-section"
            class="space-y-4"
        >

            <div
                class="grid grid-cols-1 md:grid-cols-2 gap-4"
            >


                <!-- WORKSPACE -->

                <div>

                    <label
                        class="block text-xs font-bold text-[#8b949e] mb-1.5 uppercase"
                    >
                        Workspace Target
                    </label>


                    <input
                        type="text"
                        id="workspace"
                        value="Execution Desk"
                        class="w-full bg-[#0d1117] border border-[#30363d] rounded p-2.5 text-xs text-[#c9d1d9] focus:border-[#58a6ff] outline-none"
                    >

                </div>



                <!-- MINUTES -->

                <div>

                    <label
                        class="block text-xs font-bold text-[#8b949e] mb-1.5 uppercase"
                    >
                        Session Duration (Minutes)
                    </label>


                    <input
                        type="number"
                        id="duration_input"
                        step="1"
                        min="1"
                        value="120"
                        class="w-full bg-[#0d1117] border border-[#30363d] rounded p-2.5 text-xs text-[#c9d1d9] focus:border-[#58a6ff] outline-none"
                    >


                    <p
                        id="duration-preview"
                        class="text-[10px] text-[#8b949e] mt-1"
                    >
                        2 hrs
                    </p>

                </div>


            </div>



            <button
                onclick="startTimer()"
                class="w-full bg-[#238636] hover:bg-[#2ea043] text-white font-bold text-xs py-3 rounded uppercase tracking-widest transition shadow-sm border border-[#2ea043]"
            >
                Initialize Session
            </button>

        </div>



        <!-- ACTIVE TIMER -->

        <div
            id="timer-section"
            class="hidden bg-[#0d1117] border border-[#30363d] rounded p-6 text-center space-y-4"
        >


            <div
                class="flex justify-between items-center text-xs border-b border-[#30363d] pb-3"
            >

                <span class="text-[#8b949e]">

                    TARGET:

                    <strong
                        id="active-workspace"
                        class="text-[#58a6ff]"
                    ></strong>

                </span>


                <span
                    class="text-[#2ea043] animate-pulse"
                >
                    ● LIVE_TRACKING
                </span>

            </div>



            <!-- TIMER -->

            <div
                id="timer-display"
                class="text-5xl font-extrabold text-[#c9d1d9] tracking-widest py-4"
            >
                00:00:00
            </div>



            <!-- EXACT TARGET -->

            <div
                id="target-display"
                class="text-xs text-[#8b949e]"
            >
                TARGET: 2 hrs
            </div>



            <!-- PROGRESS -->

            <div
                class="w-full bg-[#161b22] border border-[#30363d] rounded h-2 overflow-hidden p-0.5"
            >

                <div
                    id="progress-bar"
                    class="bg-[#2ea043] h-full transition-all duration-1000"
                    style="width: 100%"
                ></div>

            </div>


            <div
                class="text-[11px] text-[#8b949e]"
                id="progress-text"
            >
                0% COMPLETE
            </div>



            <!-- BUTTONS -->

            <div
                class="flex justify-center gap-3 pt-2"
            >

                <button
                    id="pause-btn"
                    onclick="pauseTimer()"
                    class="bg-[#21262d] hover:bg-[#30363d] border border-[#30363d] text-[#c9d1d9] px-4 py-2 rounded text-xs font-bold transition"
                >
                    PAUSE
                </button>


                <button
                    onclick="finishSessionEarly()"
                    class="bg-[#2ea043]/20 hover:bg-[#2ea043]/30 border border-[#2ea043]/40 text-[#2ea043] px-4 py-2 rounded text-xs font-bold transition"
                >
                    DONE
                </button>


                <button
                    onclick="resetTimer()"
                    class="bg-[#da3633]/20 hover:bg-[#da3633]/30 border border-[#f85149]/40 text-[#f85149] px-4 py-2 rounded text-xs font-bold transition"
                >
                    ABORT
                </button>

            </div>

        </div>



        <!-- STATISTICS -->

        <div
            class="mt-8 border-t border-[#30363d] pt-6"
        >

            <h2
                class="text-xs font-bold text-[#c9d1d9] uppercase tracking-wider mb-3"
            >
                Time Allocation Logs
            </h2>


            <div
                class="grid grid-cols-3 gap-3"
            >


                <!-- TODAY -->

                <div
                    class="bg-[#0d1117] border border-[#30363d] p-3 rounded text-center"
                >

                    <p
                        class="text-[10px] text-[#8b949e] uppercase"
                    >
                        Today
                    </p>


                    <p
                        class="text-lg font-bold text-[#c9d1d9] mt-1"
                    >

                        <?= htmlspecialchars(
                            formatExactTime($dailyTotal)
                        ) ?>

                    </p>

                </div>



                <!-- WEEK -->

                <div
                    class="bg-[#0d1117] border border-[#30363d] p-3 rounded text-center"
                >

                    <p
                        class="text-[10px] text-[#8b949e] uppercase"
                    >
                        This Week
                    </p>


                    <p
                        class="text-lg font-bold text-[#c9d1d9] mt-1"
                    >

                        <?= htmlspecialchars(
                            formatExactTime($weeklyTotal)
                        ) ?>

                    </p>

                </div>



                <!-- MONTH -->

                <div
                    class="bg-[#0d1117] border border-[#30363d] p-3 rounded text-center"
                >

                    <p
                        class="text-[10px] text-[#8b949e] uppercase"
                    >
                        This Month
                    </p>


                    <p
                        class="text-lg font-bold text-[#c9d1d9] mt-1"
                    >

                        <?= htmlspecialchars(
                            formatExactTime($monthlyTotal)
                        ) ?>

                    </p>

                </div>


            </div>

        </div>


    </div>

</div>

    <div></div>


<script>

/* =========================
   QUOTES
========================= */

const quotes = [

    "\"The market is a device for transferring money from the impatient to the patient.\"",

    "\"Risk comes from not knowing what you're doing.\"",

    "\"Amateurs look at the payout; professionals look at the risk.\"",

    "\"Plan your trade and trade your plan with strict algorithmic precision.\"",

    "\"Discipline is choosing between what you want now and what you want most.\"",

    "\"Execution without patience is just expensive gambling.\""

];


document.getElementById('quote-box').innerText =
    quotes[
        Math.floor(
            Math.random() *
            quotes.length
        )
    ];



/* =========================
   TERMINAL CLOCK
========================= */

function updateClock()
{

    const now = new Date();


    document.getElementById(
        'terminal-clock'
    ).innerText =
        now.toLocaleTimeString();

}


updateClock();

setInterval(
    updateClock,
    1000
);



/* =========================
   TIMER STATE
========================= */

let timerInterval = null;

let isPaused = false;

let sessionStartTime = null;

let sessionEndTime = null;

let pausedRemainingSeconds = 0;

let totalSessionSeconds = 0;

let sessionWorkspace = '';

let sessionSaved = false;



/* =========================
   STORAGE KEY
========================= */

const SESSION_KEY =
    'execution_terminal_active_session';



/* =========================
   EXACT TIME FORMATTER
========================= */

function formatExactTime(seconds)
{

    seconds = Math.max(
        0,
        Math.floor(seconds)
    );


    const hours =
        Math.floor(
            seconds / 3600
        );


    const minutes =
        Math.floor(
            (seconds % 3600) / 60
        );


    const secs =
        seconds % 60;


    if (hours > 0) {

        if (minutes > 0) {

            return (
                hours +
                ' hr' +
                (hours !== 1 ? 's' : '') +
                ' ' +
                minutes +
                ' min'
            );

        }

        return (
            hours +
            ' hr' +
            (hours !== 1 ? 's' : '')
        );

    }


    if (minutes > 0) {

        if (secs > 0) {

            return (
                minutes +
                ' min ' +
                secs +
                ' sec'
            );

        }

        return (
            minutes +
            ' min'
        );

    }


    return secs + ' sec';

}



/* =========================
   MINUTE INPUT PREVIEW
========================= */

function updateDurationPreview()
{

    const minutes =
        parseInt(
            document.getElementById(
                'duration_input'
            ).value,
            10
        );


    const preview =
        document.getElementById(
            'duration-preview'
        );


    if (
        !minutes ||
        minutes <= 0
    ) {

        preview.innerText =
            'Enter session duration';

        return;

    }


    preview.innerText =
        formatExactTime(
            minutes * 60
        );

}


document.getElementById(
    'duration_input'
).addEventListener(
    'input',
    updateDurationPreview
);


updateDurationPreview();



/* =========================
   START TIMER
========================= */

function startTimer()
{

    const minutes =
        parseInt(
            document.getElementById(
                'duration_input'
            ).value,
            10
        );


    if (
        !minutes ||
        minutes <= 0
    ) {

        alert(
            'ERR: INVALID_DURATION_VALUE'
        );

        return;

    }


    totalSessionSeconds =
        minutes * 60;


    sessionWorkspace =
        document.getElementById(
            'workspace'
        ).value.trim()
        || 'Execution Desk';


    sessionStartTime =
        Date.now();


    sessionEndTime =
        sessionStartTime +
        (
            totalSessionSeconds *
            1000
        );


    isPaused = false;

    pausedRemainingSeconds = 0;

    sessionSaved = false;


    saveActiveSession();

    showTimer();

    runCountdown();

}



/* =========================
   SAVE ACTIVE SESSION
========================= */

function saveActiveSession()
{

    const data = {

        startTime:
            sessionStartTime,

        endTime:
            sessionEndTime,

        totalSeconds:
            totalSessionSeconds,

        workspace:
            sessionWorkspace,

        paused:
            false,

        pausedRemaining:
            0

    };


    localStorage.setItem(
        SESSION_KEY,
        JSON.stringify(data)
    );

}



/* =========================
   LOAD ACTIVE SESSION
========================= */

function loadActiveSession()
{

    const saved =
        localStorage.getItem(
            SESSION_KEY
        );


    if (!saved)
        return false;


    try {

        const data =
            JSON.parse(saved);


        if (
            !data.startTime ||
            !data.endTime ||
            !data.totalSeconds
        ) {

            localStorage.removeItem(
                SESSION_KEY
            );

            return false;

        }


        sessionStartTime =
            data.startTime;


        sessionEndTime =
            data.endTime;


        totalSessionSeconds =
            data.totalSeconds;


        sessionWorkspace =
            data.workspace ||
            'Execution Desk';


        isPaused =
            data.paused ||
            false;


        pausedRemainingSeconds =
            data.pausedRemaining ||
            0;


        document.getElementById(
            'workspace'
        ).value =
            sessionWorkspace;


        showTimer();


        return true;

    } catch (error) {

        localStorage.removeItem(
            SESSION_KEY
        );

        return false;

    }

}



/* =========================
   SHOW TIMER
========================= */

function showTimer()
{

    document
        .getElementById(
            'setup-section'
        )
        .classList.add(
            'hidden'
        );


    document
        .getElementById(
            'timer-section'
        )
        .classList.remove(
            'hidden'
        );


    document
        .getElementById(
            'active-workspace'
        )
        .innerText =
            sessionWorkspace;


    document
        .getElementById(
            'target-display'
        )
        .innerText =
            'TARGET: ' +
            formatExactTime(
                totalSessionSeconds
            );


    document
        .getElementById(
            'status-text'
        )
        .innerText =
            'LIVE_TRACKING';


    document
        .getElementById(
            'status-text'
        )
        .className =
            'text-[#2ea043]';


    updatePauseButton();

}



/* =========================
   COUNTDOWN
========================= */

function runCountdown()
{

    if (timerInterval)
        clearInterval(
            timerInterval
        );


    updateTimer();


    timerInterval =
        setInterval(
            updateTimer,
            250
        );

}



/* =========================
   UPDATE TIMER
========================= */

function updateTimer()
{

    let remainingSeconds;


    if (isPaused) {

        remainingSeconds =
            pausedRemainingSeconds;

    } else {

        remainingSeconds =
            Math.max(
                0,
                Math.ceil(
                    (
                        sessionEndTime -
                        Date.now()
                    ) / 1000
                )
            );

    }


    updateDisplay(
        remainingSeconds
    );


    updateProgressBar(
        remainingSeconds
    );


    if (
        remainingSeconds <= 0 &&
        !isPaused &&
        !sessionSaved
    ) {

        completeSession();

    }

}



/* =========================
   DISPLAY
========================= */

function updateDisplay(
    remainingSeconds
)
{

    const hours =
        String(
            Math.floor(
                remainingSeconds / 3600
            )
        ).padStart(
            2,
            '0'
        );


    const minutes =
        String(
            Math.floor(
                (
                    remainingSeconds %
                    3600
                ) / 60
            )
        ).padStart(
            2,
            '0'
        );


    const seconds =
        String(
            remainingSeconds % 60
        ).padStart(
            2,
            '0'
        );


    document.getElementById(
        'timer-display'
    ).innerText =
        `${hours}:${minutes}:${seconds}`;

}



/* =========================
   PROGRESS BAR
========================= */

function updateProgressBar(
    remainingSeconds
)
{

    const elapsed =
        totalSessionSeconds -
        remainingSeconds;


    const remainingPercentage =
        (
            remainingSeconds /
            totalSessionSeconds
        ) * 100;


    const elapsedPercentage =
        Math.min(
            100,
            Math.max(
                0,
                Math.floor(
                    (
                        elapsed /
                        totalSessionSeconds
                    ) * 100
                )
            )
        );


    document.getElementById(
        'progress-bar'
    ).style.width =
        `${Math.max(
            0,
            remainingPercentage
        )}%`;


    document.getElementById(
        'progress-text'
    ).innerText =
        `${elapsedPercentage}% COMPLETE — ` +
        `${formatExactTime(
            remainingSeconds
        )} REMAINING`;

}



/* =========================
   PAUSE
========================= */

function pauseTimer()
{

    if (!isPaused) {

        pausedRemainingSeconds =
            Math.max(
                0,
                Math.ceil(
                    (
                        sessionEndTime -
                        Date.now()
                    ) / 1000
                )
            );


        isPaused = true;


        savePausedSession();

    } else {

        sessionEndTime =
            Date.now() +
            (
                pausedRemainingSeconds *
                1000
            );


        isPaused = false;


        saveActiveSession();

    }


    updatePauseButton();

    updateTimer();

}



/* =========================
   SAVE PAUSED STATE
========================= */

function savePausedSession()
{

    const data = {

        startTime:
            sessionStartTime,

        endTime:
            sessionEndTime,

        totalSeconds:
            totalSessionSeconds,

        workspace:
            sessionWorkspace,

        paused:
            true,

        pausedRemaining:
            pausedRemainingSeconds

    };


    localStorage.setItem(
        SESSION_KEY,
        JSON.stringify(data)
    );

}



/* =========================
   PAUSE BUTTON
========================= */

function updatePauseButton()
{

    const btn =
        document.getElementById(
            'pause-btn'
        );


    if (isPaused) {

        btn.innerText =
            'RESUME';


        btn.className =
            'bg-[#e3b341]/20 hover:bg-[#e3b341]/30 border border-[#e3b341]/40 text-[#e3b341] px-4 py-2 rounded text-xs font-bold transition';

    } else {

        btn.innerText =
            'PAUSE';


        btn.className =
            'bg-[#21262d] hover:bg-[#30363d] border border-[#30363d] text-[#c9d1d9] px-4 py-2 rounded text-xs font-bold transition';

    }

}



/* =========================
   COMPLETE SESSION
========================= */

function completeSession()
{

    if (sessionSaved)
        return;


    sessionSaved = true;


    clearInterval(
        timerInterval
    );


    playBeep();


    saveSessionToDB(
        totalSessionSeconds
    );

}



/* =========================
   FINISH SESSION EARLY (DONE)
========================= */

function finishSessionEarly()
{

    if (
        !confirm(
            'CONFIRM_DONE: Finish session and save elapsed time?'
        )
    ) {

        return;

    }


    let remainingSeconds;


    if (isPaused) {

        remainingSeconds =
            pausedRemainingSeconds;

    } else {

        remainingSeconds =
            Math.max(
                0,
                Math.ceil(
                    (
                        sessionEndTime -
                        Date.now()
                    ) / 1000
                )
            );

    }


    const elapsedSeconds =
        totalSessionSeconds -
        remainingSeconds;


    if (elapsedSeconds <= 0) {

        alert(
            'ERR: NO_TIME_RECORDED'
        );

        return;

    }


    if (sessionSaved)
        return;


    sessionSaved = true;


    clearInterval(
        timerInterval
    );


    playBeep();


    saveSessionToDB(
        elapsedSeconds
    );

}



/* =========================
   SAVE TO DATABASE
========================= */

function saveSessionToDB(
    seconds
)
{

    const formData =
        new FormData();


    formData.append(
        'save_session',
        '1'
    );


    formData.append(
        'workspace',
        sessionWorkspace
    );


    formData.append(
        'duration_seconds',
        seconds
    );


    fetch(
        window.location.href,
        {
            method: 'POST',
            body: formData
        }
    )

    .then(
        response =>
            response.json()
    )

    .then(
        data =>
        {

            if (
                data.status ===
                'success'
            ) {

                localStorage.removeItem(
                    SESSION_KEY
                );


                alert(
                    'SESSION_COMPLETE: Exact time recorded successfully.'
                );


                location.reload();

            } else {

                sessionSaved = false;


                alert(
                    'ERR: DB_WRITE_FAILED'
                );

            }

        }
    )

    .catch(
        error =>
        {

            console.error(
                error
            );


            sessionSaved = false;


            alert(
                'ERR: DATABASE_CONNECTION_FAILED'
            );

        }
    );

}



/* =========================
   ABORT
========================= */

function resetTimer()
{

    if (
        !confirm(
            'CONFIRM_ABORT: Terminate current tracking session?'
        )
    ) {

        return;

    }


    clearInterval(
        timerInterval
    );


    localStorage.removeItem(
        SESSION_KEY
    );


    isPaused = false;

    sessionSaved = false;

    pausedRemainingSeconds = 0;

    totalSessionSeconds = 0;


    document
        .getElementById(
            'timer-section'
        )
        .classList.add(
            'hidden'
        );


    document
        .getElementById(
            'setup-section'
        )
        .classList.remove(
            'hidden'
        );


    document
        .getElementById(
            'status-text'
        )
        .innerText =
            'STANDBY_READY';


    document
        .getElementById(
            'status-text'
        )
        .className =
            'text-[#2ea043]';

}



/* =========================
   BEEP
========================= */

function playBeep()
{

    try {

        const audioCtx =
            new (
                window.AudioContext ||
                window.webkitAudioContext
            )();


        const oscillator =
            audioCtx.createOscillator();


        const gainNode =
            audioCtx.createGain();


        oscillator.type =
            'square';


        oscillator.frequency.setValueAtTime(
            800,
            audioCtx.currentTime
        );


        gainNode.gain.setValueAtTime(
            0.05,
            audioCtx.currentTime
        );


        oscillator.connect(
            gainNode
        );


        gainNode.connect(
            audioCtx.destination
        );


        oscillator.start();


        oscillator.stop(
            audioCtx.currentTime +
            0.3
        );

    } catch (e) {}

}



/* =========================
   PAGE LOAD
========================= */

window.addEventListener(
    'load',
    function()
    {

        const active =
            loadActiveSession();


        if (active) {

            if (
                !isPaused &&
                Date.now() >=
                sessionEndTime
            ) {

                completeSession();

            } else {

                runCountdown();

            }

        }

    }
);

</script>

</body>
</html>
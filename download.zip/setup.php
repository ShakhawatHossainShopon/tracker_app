
<?php
date_default_timezone_set('Asia/Dhaka');

// DB connection
$host = 'sql102.infinityfree.com';
$db   = 'if0_40135421_trade_tracker';
$user = 'if0_40135421';
$pass = 'WasasCNrbr';
$dsn = "mysql:host=$host;dbname=$db;charset=utf8";

try {
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
} catch (PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

// ===== ADD NEW PARENT =====
if (isset($_POST['new_parent'])) {
    $parentName = trim($_POST['parent_name']);

    if ($parentName !== '') {
        $pdo->prepare("
            INSERT INTO todo_parents (parent_name)
            VALUES (?)
        ")->execute([$parentName]);
    }

    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// ===== DELETE PARENT =====
if (isset($_POST['delete_parent'])) {
    $parentId = intval($_POST['parent_id']);

    $pdo->prepare("
        DELETE FROM todo_parents
        WHERE id=?
    ")->execute([$parentId]);

    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// ===== ADD NEW TODO =====
if (isset($_POST['new_todo'])) {
    $parentId = intval($_POST['parent_id']);
    $todoText = trim($_POST['todo_text']);

    if ($todoText !== '') {
        $pdo->prepare("
            INSERT INTO todos (parent_id, todo_text, status)
            VALUES (?, ?, 'pending')
        ")->execute([$parentId, $todoText]);
    }

    header("Location: " . $_SERVER['PHP_SELF'] . "?parent=" . $parentId);
    exit;
}

// ===== TOGGLE TODO STATUS =====
if (isset($_GET['toggle_todo'])) {
    $todoId = intval($_GET['toggle_todo']);
    $parentId = intval($_GET['parent']);

    $stmt = $pdo->prepare("
        SELECT status
        FROM todos
        WHERE id=?
    ");
    $stmt->execute([$todoId]);

    $status = $stmt->fetchColumn();

    $newStatus = ($status === 'pending') ? 'done' : 'pending';

    $pdo->prepare("
        UPDATE todos
        SET status=?
        WHERE id=?
    ")->execute([$newStatus, $todoId]);

    header("Location: " . $_SERVER['PHP_SELF'] . "?parent=" . $parentId);
    exit;
}

// ===== DELETE TODO =====
if (isset($_GET['delete_todo'])) {
    $todoId = intval($_GET['delete_todo']);
    $parentId = intval($_GET['parent']);

    $pdo->prepare("
        DELETE FROM todos
        WHERE id=?
    ")->execute([$todoId]);

    header("Location: " . $_SERVER['PHP_SELF'] . "?parent=" . $parentId);
    exit;
}

// ===== FETCH DATA =====
$parents = $pdo->query("
    SELECT *
    FROM todo_parents
    ORDER BY id DESC
")->fetchAll(PDO::FETCH_ASSOC);

$parentId = isset($_GET['parent'])
    ? intval($_GET['parent'])
    : null;

$todos = [];

if ($parentId) {
    $stmt = $pdo->prepare("
        SELECT *
        FROM todos
        WHERE parent_id=?
        ORDER BY id DESC
    ");

    $stmt->execute([$parentId]);

    $todos = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>To-Do App</title>

<script src="https://cdn.tailwindcss.com"></script>

</head>

<body class="bg-gray-100 flex justify-center md:py-4 md:px-4">

<div class="bg-white rounded-xl shadow-md p-1 md:p-4 w-full md:max-w-5xl">

<h2 class="text-lg font-bold text-indigo-700 text-center mb-4">
    Check List
</h2>

<!-- TOP BUTTONS -->
<div class="flex gap-2 mb-4">

<a
    href="index.php"
    class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded"
>
    Back to Tracker
</a>

</div>

<!-- ADD PARENT -->
<form method="post" class="flex flex-wrap gap-2 mb-4">

<input
    type="text"
    name="parent_name"
    placeholder="New Parent Category"
    class="border rounded p-2 flex-1 min-w-[200px]"
    required
>

<button
    type="submit"
    name="new_parent"
    class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded"
>
    Add Parent
</button>

</form>

<!-- PARENT LIST -->
<div class="overflow-x-auto mb-6">

<table class="min-w-full border border-gray-300 rounded-md text-sm text-center">

<thead class="bg-indigo-600 text-white">

<tr>
    <th>ID</th>
    <th>Parent Name</th>
    <th>Created</th>
    <th>Action</th>
</tr>

</thead>

<tbody>

<?php foreach($parents as $index => $p): ?>

<tr class="<?= $p['id']==$parentId?'bg-indigo-50':'bg-gray-50' ?> hover:bg-gray-100">

<td class="p-2">
    <?= $index + 1 ?>
</td>

<td class="p-2">

<a
    href="?parent=<?= $p['id'] ?>"
    class="text-indigo-600 font-medium hover:underline"
>
    <?= htmlspecialchars($p['parent_name']) ?>
</a>

</td>

<td class="p-2">
    <?= date('Y-m-d h:i A', strtotime($p['created_at'])) ?>
</td>

<td class="p-2">

<form method="post" class="inline">

<input
    type="hidden"
    name="parent_id"
    value="<?= $p['id'] ?>"
>

<button
    type="submit"
    name="delete_parent"
    class="text-red-600 hover:underline"
>
    Delete
</button>

</form>

</td>

</tr>

<?php endforeach; ?>

</tbody>

</table>

</div>

<?php if($parentId): ?>

<!-- ADD TODO -->
<form method="post" class="flex flex-wrap gap-2 mb-4">

<input
    type="hidden"
    name="parent_id"
    value="<?= $parentId ?>"
>

<input
    type="text"
    name="todo_text"
    placeholder="New To-Do Item"
    class="border rounded p-2 flex-1 min-w-[200px]"
    required
>

<button
    type="submit"
    name="new_todo"
    class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded"
>
    Add To-Do
</button>

</form>

<!-- TODOS TABLE -->
<div class="overflow-x-auto">

<table class="min-w-full border border-gray-300 rounded-md text-sm text-center">

<thead class="bg-green-600 text-white">

<tr>
    <th>ID</th>
    <th>Title</th>
    <th>Status</th>
    <th>Created</th>
    <th>Action</th>
</tr>

</thead>

<tbody>

<?php foreach($todos as $index => $t): ?>

<tr class="<?= $t['status']==='done'?'bg-green-50':'bg-gray-50' ?> hover:bg-gray-100">

<td class="p-2">
    <?= $index + 1 ?>
</td>

<td class="p-2 font-bold  <?= $t['status']==='done' ? 'line-through' : '' ?>">
    <?= htmlspecialchars($t['todo_text']) ?>
</td>

<td class="p-2 font-medium <?= $t['status']==='done' ? 'text-green-600' : 'text-gray-600' ?>">
    <?= $t['status'] === 'done' ? 'Done' : 'Waiting' ?>
</td>

<td class="p-2">
    <?= date('Y-m-d h:i A', strtotime($t['created_at'])) ?>
</td>

<td class="p-2">

<!-- TOGGLE -->

<a
    href="?toggle_todo=<?= $t['id'] ?>&parent=<?= $parentId ?>"
    class="text-blue-600 hover:underline mr-2"
>
    Toggle
</a>

<!-- DELETE -->

<a
    href="?delete_todo=<?= $t['id'] ?>&parent=<?= $parentId ?>"
    class="text-red-600 hover:underline"
>
    Delete
</a>

</td>

</tr>

<?php endforeach; ?>

</tbody>

</table>

</div>

<?php endif; ?>

</div>

</body>

</html>

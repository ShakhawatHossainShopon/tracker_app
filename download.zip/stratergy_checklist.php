


<?php
date_default_timezone_set('Asia/Dhaka'); 

// --- DATABASE CONFIGURATION ---
$host = 'sql102.infinityfree.com'; 
$db   = 'if0_40135421_trade_tracker'; 
$user = 'if0_40135421'; 
$pass = 'WasasCNrbr'; 
$dsn = "mysql:host=$host;dbname=$db;charset=utf8";

try {
    $pdo = new PDO($dsn, $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
} catch (PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

// Handle AJAX Request to save or update state instantly without reload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save') {
    $taskId = (int)$_POST['task_id'];
    $isChecked = (int)$_POST['is_checked'];

    $stmt = $pdo->prepare("INSERT INTO ict_checklist_state (task_id, is_checked) VALUES (?, ?) ON DUPLICATE KEY UPDATE is_checked = ?");
    $stmt->execute([$taskId, $isChecked, $isChecked]);
    
    echo json_encode(['status' => 'success']);
    exit;
}

// Handle Reset Request (Clears database records)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'reset') {
    $pdo->query("DELETE FROM ict_checklist_state");
    echo json_encode(['status' => 'success']);
    exit;
}

// Define checklist items with point weights
$tasks = [
    [
        "id" => 1,
        "title" => "1H Market Structure & Bias",
        "points" => 10,
        "desc" => "Analyze the 1H timeframe for macro structural points (BOS / CHoCH) and institutional directional bias."
    ],
    [
        "id" => 2,
        "title" => "5M Internal Market Structure",
        "points" => 10,
        "desc" => "Identify internal swing highs/lows and structural shifts (BOS / CHoCH) supporting the higher timeframe bias."
    ],
    [
        "id" => 3,
        "title" => "Price Breaks Opposite Order Block",
        "points" => 15,
        "desc" => "Highlight key liquidity pools (EQH, EQL, PDH, PDL) where stop orders accumulate."
    ],
    [
        "id" => 4,
        "title" => "Price Creates New Order Block or FVG In Opposite",
        "points" => 15,
        "desc" => "Monitor price aggressively passed into a premium/discount order block."
    ],
    [
        "id" => 5,
        "title" => "Market Struture Shifts",
        "points" => 10,
        "desc" => "Catch a sharp 1M Market Structure Shift (MSS)"
    ],
    [
        "id" => 6,
        "title" => "Retrace To OTE Zone",
        "points" => 10,
        "desc" => "Catch a sharp 1M Market Structure Shift (MSS) and wait for retracement in the fair value gap"
    ],
    [
        "id" => 7,
        "title" => "Market Structure Shift With FVG",
        "points" => 10,
        "desc" => "Enter on a retracement into the 1M FVG following the sweep and alignment, targeting a strict 1:2 Risk-to-Reward ratio."
    ],
     [
        "id" => 8,
        "title" => "Wait For Retarce Then Entry",
        "points" => 10,
        "desc" => "Enter on a retracement into the 1M FVG following the sweep and alignment, targeting a strict 1:2 Risk-to-Reward ratio."
    ]
];

// Fetch saved states from database
$savedStates = [];
$stmt = $pdo->query("SELECT task_id, is_checked FROM ict_checklist_state");
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $savedStates[$row['task_id']] = (bool)$row['is_checked'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ICT Trading Strategy Checklist | Persistent Database UI</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: #060913;
            background-image: 
                radial-gradient(circle at 10% 20%, rgba(56, 189, 248, 0.03) 0%, transparent 40%),
                radial-gradient(circle at 90% 80%, rgba(16, 185, 129, 0.03) 0%, transparent 40%);
            color: #f8fafc;
        }
        .font-mono-num {
            font-family: 'JetBrains Mono', monospace;
        }
        input[type="checkbox"] {
            appearance: none;
            -webkit-appearance: none;
            width: 22px;
            height: 22px;
            border: 2px solid #64748b;
            border-radius: 6px;
            outline: none;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
            background-color: #060913;
        }
        input[type="checkbox"]:checked {
            background-color: #10b981;
            border-color: #10b981;
        }
        input[type="checkbox"]:checked::after {
            content: "✓";
            color: #ffffff;
            font-size: 13px;
            font-weight: bold;
        }
        .checklist-row.completed td {
            background: rgba(16, 185, 129, 0.03);
        }
        .checklist-row.completed .task-title {
            text-decoration: line-through;
            color: #64748b;
        }
        .checklist-row.completed .task-desc {
            opacity: 0.4;
        }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center py-4 px-4">

<div class="bg-[#0f172a] border border-white/5 rounded-2xl shadow-2xl p-4 sm:p-8 w-full max-w-4xl backdrop-blur-xl">
        <div class="flex justify-end pb-4">
                           <a href="breaker_block_stratergy.php" class="bg-[#21262d] hover:bg-[#30363d] border border-[#30363d] text-[#c9d1d9] px-3 py-1.5 rounded text-xs transition">
                [ BOS/CHOCh ]
            </a>
    </div>
    <!-- Top Bar with Score, Action Plan, and Reset Button -->
    <div class="flex flex-col md:flex-row gap-4 items-center justify-between mb-6">
        <div class="bg-gradient-to-br from-[#1e293b] to-[#0f172a] border border-white/10 rounded-xl p-4 text-center shadow-lg relative overflow-hidden flex-1 w-full">
            <div class="absolute top-0 left-0 w-1 h-full bg-cyan-400" id="rating-bar-accent"></div>
            <div class="text-xs font-bold uppercase tracking-wider text-green-300 mb-1">Recommended Action Plan For Catching Reversal and Agressive Price Action</div>
            <div id="rating-grade" class="text-sm sm:text-base font-bold text-rose-400 font-mono-num transition-colors">
                C / Skip — No Trade / Skip (Protect capital)
            </div>
        </div>

        <div class="flex items-center gap-3 w-full md:w-auto justify-between md:justify-end">
            <div class="bg-[#1e293b]/70 border border-white/5 px-5 py-3 rounded-xl text-center">
                <span class="text-xs font-semibold uppercase tracking-wider text-slate-400 block mb-0.5">Total Score</span>
                <span class="text-2xl font-bold font-mono-num text-emerald-400"><span id="total-score">0</span><span class="text-xs text-slate-500 font-normal"> / 100 Marks</span></span>
            </div>
            
            <button onclick="resetChecklist()" class="bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 px-4 py-3 rounded-xl text-xs font-semibold uppercase tracking-wider transition cursor-pointer">
                Reset
            </button>
        </div>
    </div>

    <!-- Checklist Table -->
    <div class="overflow-x-auto rounded-xl border border-white/5 mb-6">
        <table class="min-w-full text-left border-collapse">
            <thead>
                <tr class="bg-[#1e293b] text-slate-400 text-xs font-semibold uppercase tracking-wider border-b border-white/5">
                    <th class="p-4 text-center w-16">Check</th>
                    <th class="p-4">Checklist Criterion & Description</th>
                    <th class="p-4 text-right pr-6 w-32">Points Value</th>
                </tr>
            </thead>
            <tbody id="checklist-tbody" class="divide-y divide-white/5 text-sm">
                <?php foreach ($tasks as $task): ?>
                    <?php 
                        // If saved in DB, use that status. Otherwise, make ID 1 and 2 checked by default.
                        if (isset($savedStates[$task['id']])) {
                            $isChecked = $savedStates[$task['id']] === true;
                        } else {
                            $isChecked = ($task['id'] === 1 || $task['id'] === 2);
                        }
                    ?>
                    <tr class="checklist-row hover:bg-white/[0.02] transition cursor-pointer <?php echo $isChecked ? 'completed' : ''; ?>" onclick="toggleRow(event, <?php echo $task['id']; ?>, <?php echo $task['points']; ?>, this)">
                        <td class="p-4 text-center">
                            <input type="checkbox" data-points="<?php echo $task['points']; ?>" id="task-<?php echo $task['id']; ?>" <?php echo $isChecked ? 'checked' : ''; ?>>
                        </td>
                        <td class="p-4">
                            <div class="task-title font-semibold text-slate-200 mb-0.5"><?php echo htmlspecialchars($task['title']); ?></div>
                            <div class="task-desc text-xs text-slate-400 leading-relaxed"><?php echo htmlspecialchars($task['desc']); ?></div>
                        </td>
                        <td class="p-4 text-right pr-6 font-mono-num">
                            <span class="inline-block bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 px-2.5 py-1 rounded-lg text-xs font-semibold">
                                +<?php echo $task['points']; ?> Marks
                            </span>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</div>

<script>
    document.addEventListener("DOMContentLoaded", () => {
        calculateScore();
    });

    function toggleRow(event, taskId, points, rowElement) {
        const checkbox = rowElement.querySelector('input[type="checkbox"]');
        
        if (event.target !== checkbox) {
            checkbox.checked = !checkbox.checked;
        }

        if (checkbox.checked) {
            rowElement.classList.add('completed');
        } else {
            rowElement.classList.remove('completed');
        }

        calculateScore();
        saveStateToDB(taskId, checkbox.checked ? 1 : 0);
    }

    function calculateScore() {
        const checkboxes = document.querySelectorAll('#checklist-tbody input[type="checkbox"]');
        let currentScore = 0;

        checkboxes.forEach(cb => {
            if (cb.checked) {
                currentScore += parseInt(cb.getAttribute('data-points'));
            }
        });

        document.getElementById('total-score').innerText = currentScore;
        updateGrade(currentScore);
    }

    function updateGrade(score) {
        const gradeEl = document.getElementById('rating-grade');
        const accentBar = document.getElementById('rating-bar-accent');
        
        if (score >= 90) {
            gradeEl.innerText = "A+ Setup — Full Risk Allocation (High confidence entry)";
            gradeEl.style.color = "#10b981";
            accentBar.style.backgroundColor = "#10b981";
        } else if (score >= 75) {
            gradeEl.innerText = "A Setup — Standard Risk Allocation";
            gradeEl.style.color = "#38bdf8";
            accentBar.style.backgroundColor = "#38bdf8";
        } else if (score >= 60) {
            gradeEl.innerText = "B Setup — Half Risk Allocation (Cautious management)";
            gradeEl.style.color = "#fbbf24";
            accentBar.style.backgroundColor = "#fbbf24";
        } else {
            gradeEl.innerText = "C / Skip — No Trade / Skip (Protect capital)";
            gradeEl.style.color = "#f43f5e";
            accentBar.style.backgroundColor = "#f43f5e";
        }
    }

    function saveStateToDB(taskId, isChecked) {
        const formData = new FormData();
        formData.append('action', 'save');
        formData.append('task_id', taskId);
        formData.append('is_checked', isChecked);

        fetch(window.location.href, {
            method: 'POST',
            body: formData
        }).then(response => response.json())
          .catch(error => console.error('Error saving state:', error));
    }

    function resetChecklist() {
        if (!confirm("Are you sure you want to reset the checklist?")) return;

        const formData = new FormData();
        formData.append('action', 'reset');

        fetch(window.location.href, {
            method: 'POST',
            body: formData
        }).then(response => response.json())
          .then(data => {
              if (data.status === 'success') {
                  location.reload(); // Reloads to set tasks 1 and 2 back to default checked state
              }
          })
          .catch(error => console.error('Error resetting checklist:', error));
    }
</script>

</body>
</html>
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$host = 'sql102.infinityfree.com'; 
$db   = 'if0_40135421_trade_tracker'; 
$user = 'if0_40135421'; 
$pass = 'WasasCNrbr'; 
$dsn = "mysql:host=$host;dbname=$db;charset=utf8";

try {
    $pdo = new PDO($dsn, $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
} catch (PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

$tradeId = intval($_GET['trade_id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tradeId = intval($_POST['trade_id']);
    $timeFrameNote = $_POST['time_frame_note'] ?? '';
    $whyTrade = $_POST['why_trade'] ?? '';
    $note = $_POST['note'] ?? '';
    $closingNote = $_POST['closing_note'] ?? '';
    $imageLink = $_POST['image_link'] ?? '';

    $stmt = $pdo->prepare("
        UPDATE trades SET 
        time_frame_note=?, 
        why_trade=?, 
        note=?, 
        closing_note=?,
        image_link=? 
        WHERE id=?
    ");
    $stmt->execute([$timeFrameNote, $whyTrade, $note, $closingNote, $imageLink, $tradeId]);

    header("Location: view_notes.php?trade_id=$tradeId&session=" . urlencode($_GET['session'] ?? ''));
    exit;
}

// Fetch existing trade data to pre-fill the form
$stmt = $pdo->prepare("SELECT * FROM trades WHERE id=?");
$stmt->execute([$tradeId]);
$trade = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$trade) {
    die("Trade not found.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Trade #<?= htmlspecialchars($trade['trade_number'] ?? $tradeId) ?> | Edit Notes</title>
<!-- Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<style>
    body {
        font-family: 'Plus Jakarta Sans', sans-serif;
        background-color: #060913;
        background-image: 
            radial-gradient(circle at 10% 20%, rgba(56, 189, 248, 0.03) 0%, transparent 40%),
            radial-gradient(circle at 90% 80%, rgba(16, 185, 129, 0.03) 0%, transparent 40%);
        color: #f8fafc;
    }
    .font-mono-num {
        font-family: 'JetBrains Mono', monospace;
    }
    textarea, input[type="text"] {
        background-color: #1e293b;
        border-color: rgba(255, 255, 255, 0.08);
        color: #f8fafc;
    }
    textarea:focus, input[type="text"]:focus {
        border-color: #38bdf8;
        outline: none;
        box-shadow: 0 0 0 2px rgba(56, 189, 248, 0.2);
    }
</style>
</head>
<body class="min-h-screen flex items-center justify-center py-10 px-4">

<div class="bg-[#0f172a] border border-white/5 rounded-2xl shadow-2xl p-6 sm:p-8 w-full max-w-4xl backdrop-blur-xl">

    <!-- Header / Navigation Bar -->
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8 pb-6 border-b border-white/10">
        <div>
            <div class="flex items-center gap-2.5 mb-1">
                <span class="inline-block w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse"></span>
                <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Execution Journal Entry</span>
            </div>
            <h1 class="text-2xl font-bold tracking-tight text-white flex items-center gap-3">
                Edit Trade #<?= htmlspecialchars($trade['trade_number'] ?? $tradeId) ?>
                <span class="bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 px-3 py-0.5 rounded-lg text-sm font-mono-num">
                    <?= htmlspecialchars($trade['ticker'] ?? 'N/A') ?>
                </span>
            </h1>
        </div>
        <a href="index.php?session=<?= htmlspecialchars($_GET['session'] ?? '') ?>" class="bg-[#1e293b] hover:bg-slate-700 text-slate-300 hover:text-white border border-white/5 px-4 py-2.5 rounded-xl text-xs font-semibold uppercase tracking-wider transition">
            ← Back to Trades
        </a>
    </div>

    <!-- Edit Form -->
    <form method="post" class="space-y-6">
        <input type="hidden" name="trade_id" value="<?= $tradeId ?>">

        <!-- Time Frame Note -->
        <div>
            <label class="block text-xs font-semibold uppercase tracking-wider text-cyan-400 mb-2">Time Frame Note</label>
            <input type="text" name="time_frame_note" value="<?= htmlspecialchars($trade['time_frame_note'] ?? '') ?>" placeholder="e.g. 1H trend aligning with 5M execution" class="w-full border rounded-xl p-3 text-sm placeholder-slate-500 transition">
        </div>

        <!-- Why Trade -->
        <div>
            <label class="block text-xs font-semibold uppercase tracking-wider text-amber-400 mb-2">Thesis / Why Trade?</label>
            <textarea name="why_trade" placeholder="Detail your market structure shift, liquidity sweep, and order block entry criteria..." class="w-full border rounded-xl p-3 text-sm placeholder-slate-500 h-36 transition"><?= htmlspecialchars($trade['why_trade'] ?? '') ?></textarea>
        </div>

        <!-- Execution Note -->
        <div>
            <label class="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2">Execution Notes</label>
            <textarea name="note" placeholder="Add specific execution details, patience factors, or live management notes..." class="w-full border rounded-xl p-3 text-sm placeholder-slate-500 h-36 transition"><?= htmlspecialchars($trade['note'] ?? '') ?></textarea>
        </div>

        <!-- Closing Note -->
        <div>
            <label class="block text-xs font-semibold uppercase tracking-wider text-emerald-400 mb-2">Closing & Review Note</label>
            <textarea name="closing_note" placeholder="Post-trade reflections, lessons learned, and execution outcome..." class="w-full border rounded-xl p-3 text-sm placeholder-slate-500 h-36 transition"><?= htmlspecialchars($trade['closing_note'] ?? '') ?></textarea>
        </div>

        <!-- Image Link Field -->
        <div>
            <label class="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2">Chart Setup Image URL</label>
            <input type="text" name="image_link" value="<?= htmlspecialchars($trade['image_link'] ?? '') ?>" placeholder="https://example.com/chart-screenshot.png" class="w-full border rounded-xl p-3 text-sm placeholder-slate-500 transition">
        </div>

        <!-- Action Buttons -->
        <div class="flex items-center justify-end gap-4 pt-4 border-t border-white/10">
            <a href="view_notes.php?trade_id=<?= $tradeId ?>&session=<?= htmlspecialchars($_GET['session'] ?? '') ?>" class="bg-[#1e293b] hover:bg-slate-700 text-slate-300 border border-white/5 px-5 py-3 rounded-xl text-xs font-semibold uppercase tracking-wider transition">
                Cancel
            </a>
            <button type="submit" class="bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold px-6 py-3 rounded-xl text-xs uppercase tracking-wider transition shadow-lg shadow-cyan-500/20 cursor-pointer">
                Save Changes
            </button>
        </div>
    </form>

</div>

</body>
</html>
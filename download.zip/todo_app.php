
<?php
date_default_timezone_set('Asia/Dhaka');

// DB connection (same as your main file)
$host = 'sql102.infinityfree.com';
$db   = 'if0_40135421_trade_tracker';
$user = 'if0_40135421';
$pass = 'WasasCNrbr';
$dsn = "mysql:host=$host;dbname=$db;charset=utf8";

try {
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
} catch (PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

// ===== ADD NEW PARENT =====
if (isset($_POST['new_parent'])) {
    $parentName = trim($_POST['parent_name']);

    if ($parentName !== '') {
        $pdo->prepare("
            INSERT INTO todo_parents (parent_name)
            VALUES (?)
        ")->execute([$parentName]);
    }

    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// ===== DELETE PARENT =====
if (isset($_POST['delete_parent'])) {
    $parentId = intval($_POST['parent_id']);

    $pdo->prepare("
        DELETE FROM todo_parents
        WHERE id=?
    ")->execute([$parentId]);

    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// ===== ADD NEW TODO =====
if (isset($_POST['new_todo'])) {
    $parentId = intval($_POST['parent_id']);
    $todoText = trim($_POST['todo_text']);

    if ($todoText !== '') {
        $pdo->prepare("
            INSERT INTO todos (parent_id, todo_text, direction)
            VALUES (?, ?, 'BUY')
        ")->execute([$parentId, $todoText]);
    }

    header("Location: " . $_SERVER['PHP_SELF'] . "?parent=" . $parentId);
    exit;
}

// ===== TOGGLE TODO STATUS =====
if (isset($_GET['toggle_todo'])) {
    $todoId = intval($_GET['toggle_todo']);
    $parentId = intval($_GET['parent']);

    $stmt = $pdo->prepare("
        SELECT status
        FROM todos
        WHERE id=?
    ");
    $stmt->execute([$todoId]);

    $status = $stmt->fetchColumn();

    $newStatus = ($status === 'pending') ? 'done' : 'pending';

    $pdo->prepare("
        UPDATE todos
        SET status=?
        WHERE id=?
    ")->execute([$newStatus, $todoId]);

    header("Location: " . $_SERVER['PHP_SELF'] . "?parent=" . $parentId);
    exit;
}

// ===== TOGGLE BUY / SELL =====
if (isset($_GET['toggle_direction'])) {
    $todoId = intval($_GET['toggle_direction']);
    $parentId = intval($_GET['parent']);

    $stmt = $pdo->prepare("
        SELECT direction
        FROM todos
        WHERE id=?
    ");
    $stmt->execute([$todoId]);

    $direction = $stmt->fetchColumn();

    $newDirection = ($direction === 'BUY') ? 'SELL' : 'BUY';

    $pdo->prepare("
        UPDATE todos
        SET direction=?
        WHERE id=?
    ")->execute([$newDirection, $todoId]);

    header("Location: " . $_SERVER['PHP_SELF'] . "?parent=" . $parentId);
    exit;
}

// ===== DELETE TODO =====
if (isset($_GET['delete_todo'])) {
    $todoId = intval($_GET['delete_todo']);
    $parentId = intval($_GET['parent']);

    $pdo->prepare("
        DELETE FROM todos
        WHERE id=?
    ")->execute([$todoId]);

    header("Location: " . $_SERVER['PHP_SELF'] . "?parent=" . $parentId);
    exit;
}

// ===== FETCH DATA =====
$parents = $pdo->query("
    SELECT *
    FROM todo_parents
    ORDER BY id DESC
")->fetchAll(PDO::FETCH_ASSOC);

$parentId = isset($_GET['parent'])
    ? intval($_GET['parent'])
    : null;

$todos = [];

if ($parentId) {
    $stmt = $pdo->prepare("
        SELECT *
        FROM todos
        WHERE parent_id=?
        ORDER BY id DESC
    ");

    $stmt->execute([$parentId]);

    $todos = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>To-Do App</title>

<script src="https://cdn.tailwindcss.com"></script>

</head>

<body class="bg-gray-100 flex justify-center md:py-4 md:px-4">

<div class="bg-white rounded-xl shadow-md p-1 md:p-4 w-full md:max-w-5xl">

<h2 class="text-lg font-bold text-indigo-700 text-center mb-4">
    Check List
</h2>

<!-- TOP BUTTONS -->
<div class="flex gap-2 mb-4">

<a
    href="index.php"
    class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded"
>
    Back to Tracker
</a>

</div>

<!-- ADD PARENT -->
<form method="post" class="flex flex-wrap gap-2 mb-4">


</form>


<?php if($parentId): ?>



<!-- TODOS TABLE -->
<div class="overflow-x-auto">

<table class="min-w-full border border-gray-300 rounded-md text-sm text-center">

<thead class="bg-green-600 text-white">

<tr>
    <th>ID</th>
    <th>Title</th>
    <th>Direction</th>
    <th>Status</th>
    <th>Created</th>
    <th>Action</th>
</tr>

</thead>

<tbody>

<?php foreach($todos as $index => $t): ?>

<tr class="<?= $t['status']==='done'?'bg-green-50':'bg-gray-50' ?> hover:bg-gray-100">

<td class="p-2">
    <?= $index + 1 ?>
</td>

<td class="p-2 font-bold text-blue-600">
    <?= htmlspecialchars($t['todo_text']) ?>
</td>
 <td class="p-2 font-bold <?= $t['direction']==='BUY' ? 'text-green-600' : 'text-red-600' ?>">
        <?= $t['direction'] ?>
    </td>

<td class="p-2 font-medium
    <?= $t['direction']==='BUY'
        ? 'text-green-600'
        : 'text-red-600'
    ?>"
>

<?php if($t['status'] === 'done'): ?>

    <?= $t['direction'] === 'BUY'
        ? 'BUY TRADE IS GOING ON'
        : 'SELL TRADE IS GOING ON'
    ?>

<?php else: ?>
    <span class="text-black">
        <?= $t['direction'] === 'BUY'
            ? 'WAITING FOR BUY SETUP'
            : 'WAITING FOR SELL SETUP'
        ?>
    </span>
<?php endif; ?>

</td>

<td class="p-2">
    <?= date('Y-m-d h:i A', strtotime($t['created_at'])) ?>
</td>

<td class="p-2">

<!-- BUY / SELL TOGGLE -->

<a
    href="?toggle_direction=<?= $t['id'] ?>&parent=<?= $parentId ?>"
    class="text-orange-600 text-xs hover:underline mr-2"
>
    <?= $t['direction'] === 'BUY' ? 'Change Status' : 'Change Status' ?>
</a>

<!-- TRADE STATUS TOGGLE -->

<a
    href="?toggle_todo=<?= $t['id'] ?>&parent=<?= $parentId ?>"
    class="text-blue-600 hover:underline mr-2"
>
    Toggle
</a>

<!-- DELETE -->

<a
    href="?delete_todo=<?= $t['id'] ?>&parent=<?= $parentId ?>"
    class="text-red-600 hover:underline"
>
    Delete
</a>

</td>

</tr>

<?php endforeach; ?>

</tbody>

</table>

</div>

<?php endif; ?>

</div>

</body>

</html>


<?php
// DB connection
$host = 'sql102.infinityfree.com'; 
$db   = 'if0_40135421_trade_tracker'; 
$user = 'if0_40135421'; 
$pass = 'WasasCNrbr'; 
$dsn = "mysql:host=$host;dbname=$db;charset=utf8";

try {
    $pdo = new PDO($dsn, $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
} catch (PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

$tradeId = intval($_GET['trade_id'] ?? 0);
$sessionId = intval($_GET['session_id'] ?? 0);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $status = $_POST['status'];
    $profit = floatval($_POST['profit_loss']);
    $completed = trim($_POST['completed']) ?: null; // manual string

    $stmt = $pdo->prepare("UPDATE trades SET status=?, balance_change=?, result=?, completed=? WHERE id=?");
    $stmt->execute([$status, $profit, $status, $completed, $tradeId]);

    // Recalculate cumulative balances
    $stmt = $pdo->prepare("SELECT id, balance_change FROM trades WHERE session_id=? ORDER BY trade_number ASC");
    $stmt->execute([$sessionId]);
    $allTrades = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $cumulative = 0;
    foreach($allTrades as $t){
        $cumulative += $t['balance_change'];
        $stmt2 = $pdo->prepare("UPDATE trades SET cumulative_balance=? WHERE id=?");
        $stmt2->execute([$cumulative, $t['id']]);
    }

    header("Location: index.php?session=".$sessionId);
    exit;
}

// Fetch trade info
$stmt = $pdo->prepare("SELECT * FROM trades WHERE id=?");
$stmt->execute([$tradeId]);
$trade = $stmt->fetch(PDO::FETCH_ASSOC);
if(!$trade) die("Trade not found.");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Update Trade Status</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex justify-center py-8">
<div class="bg-white p-6 rounded shadow-md w-full max-w-md">
<h2 class="text-lg font-bold mb-4">Update Status for Trade #<?= $trade['trade_number'] ?></h2>

<form method="post" class="flex flex-col gap-3">
<input type="hidden" name="trade_id" value="<?= $tradeId ?>">
<input type="hidden" name="session_id" value="<?= $sessionId ?>">

<select name="status" class="border rounded p-2">
    <option value="open" <?= $trade['status']=='open'?'selected':'' ?>>Open</option>
    <option value="win" <?= $trade['status']=='win'?'selected':'' ?>>Win</option>
    <option value="loss" <?= $trade['status']=='loss'?'selected':'' ?>>Loss</option>
</select>

<input type="number" step="0.01" name="profit_loss" placeholder="Profit/Loss" value="<?= $trade['balance_change'] ?>" class="border rounded p-2">

<input type="text" name="completed" placeholder="Completed (manual string)" value="<?= htmlspecialchars($trade['completed']) ?>" class="border rounded p-2">

<button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Update Status</button>
</form>
</div>
</body>
</html>

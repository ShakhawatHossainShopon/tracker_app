<?php
date_default_timezone_set('Asia/Dhaka');

// DB connection credentials matching your template
$host = 'sql102.infinityfree.com';
$db   = 'if0_40135421_trade_tracker';
$user = 'if0_40135421';
$pass = 'WasasCNrbr';
$dsn = "mysql:host=$host;dbname=$db;charset=utf8";

try {
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

// Ensure an ID is set in the URL query string
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Error: No entry ID specified.");
}

$id = intval($_GET['id']);

// Fetch the specific setup record
$stmt = $pdo->prepare("SELECT * FROM ict_graded_setups WHERE id = ?");
$stmt->execute([$id]);
$setup = $stmt->fetch();

if (!$setup) {
    die("Error: Grading record not found for ID #" . htmlspecialchars($id));
}

// Parse the recorded matrix options
$savedBreakdown = json_decode($setup['matrix_data'], true) ?? [];

// Hardcoded verification configuration criteria rules matching app definitions
$criteria = [
    'htf_bias'    => ['label' => 'HTF bias alignment', 'weight' => 20],
    'liquidity'   => ['label' => 'Liquidity sweep', 'weight' => 15],
    'mss'         => ['label' => 'MSS (Market Structure Shift)', 'weight' => 15],
    'displacement'=> ['label' => 'Displacement', 'weight' => 15],
    'fvg'         => ['label' => 'FVG formation', 'weight' => 10],
    'retrace'     => ['label' => 'Retrace into FVG/OB', 'weight' => 10],
    'entry'       => ['label' => 'Entry execution logic', 'weight' => 5],
    'stop_loss'   => ['label' => 'Stop loss placement', 'weight' => 5],
    'take_profit' => ['label' => 'Take profit (1:2+)', 'weight' => 5],
];

// Determine CSS styling based on saved total score
$score = $setup['total_score'];
if ($score >= 90) {
    $badgeClass = "bg-emerald-600 text-white";
    $cardBgClass = "bg-emerald-50 border-emerald-300";
} else if ($score >= 75) {
    $badgeClass = "bg-teal-500 text-white";
    $cardBgClass = "bg-teal-50 border-teal-300";
} else if ($score >= 50) {
    $badgeClass = "bg-amber-500 text-white";
    $cardBgClass = "bg-amber-50 border-amber-300";
} else {
    $badgeClass = "bg-rose-600 text-white";
    $cardBgClass = "bg-rose-50 border-rose-300";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Saved Setup View - Matrix #<?= $setup['id'] ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex justify-center min-h-screen items-start md:py-8 md:px-4">
<div class="bg-white rounded-xl shadow-md p-6 w-full md:max-w-xl my-4 mx-2">

    <div class="mb-4">
        <a href="index.php" class="inline-flex items-center text-xs font-bold text-indigo-600 hover:text-indigo-800 transition">
            ⬅️ Back to Grading Workspace
        </a>
    </div>

    <h2 class="text-xl font-bold text-gray-800 text-center mb-1">📋 Setup Evaluation Matrix Details</h2>
    <p class="text-xs text-gray-500 text-center mb-6">Database Record Instance #<?= $setup['id'] ?> &bull; Saved At: <?= date('Y-m-d h:i A', strtotime($setup['created_at'])) ?></p>

    <div class="border rounded-xl p-6 text-center mb-6 <?= $cardBgClass ?>">
        <div class="text-sm font-semibold tracking-wider uppercase text-gray-500 mb-1">Archived Setup Score</div>
        <div class="text-5xl font-black text-gray-700"><?= $setup['total_score'] ?> / 100</div>
        <div class="inline-block mt-3 px-4 py-1.5 rounded-full text-sm font-bold tracking-wide shadow-sm <?= $badgeClass ?>">
            <?= htmlspecialchars($setup['grade']) ?>
        </div>
    </div>

    <div class="border rounded-lg border-gray-200 overflow-hidden shadow-sm">
        <div class="bg-indigo-600 text-white text-xs font-bold px-4 py-2 flex justify-between">
            <span>Trading Evaluation Matrix Rules</span>
            <span>Confirmation Status</span>
        </div>
        <div class="divide-y divide-gray-200 bg-white text-sm">
            <?php foreach ($criteria as $key => $info): ?>
                <?php 
                    $value = isset($savedBreakdown[$key]) ? $savedBreakdown[$key] : 'NO';
                    $isYes = ($value === 'YES');
                ?>
                <div class="p-3 flex justify-between items-center hover:bg-gray-50 transition-colors">
                    <span class="font-medium text-gray-800"><?= htmlspecialchars($info['label']) ?></span>
                    <span class="px-3 py-1 rounded text-xs font-bold <?= $isYes ? 'bg-green-100 text-green-800 border border-green-200' : 'bg-red-100 text-red-800 border border-red-200' ?>">
                        <?= $value ?> (+<?= $isYes ? $info['weight'] : '0' ?>)
                    </span>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

</div>
</body>
</html>
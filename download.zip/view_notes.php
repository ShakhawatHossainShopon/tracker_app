<?php
$host = 'sql102.infinityfree.com'; 
$db   = 'if0_40135421_trade_tracker'; 
$user = 'if0_40135421'; 
$pass = 'WasasCNrbr'; 
$dsn = "mysql:host=$host;dbname=$db;charset=utf8";

try {
    $pdo = new PDO($dsn, $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
} catch (PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

$tradeId = intval($_GET['trade_id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM trades WHERE id=?");
$stmt->execute([$tradeId]);
$trade = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$trade){
    die("Trade not found.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Trade #<?= htmlspecialchars($trade['trade_number'] ?? $tradeId) ?> | Execution Log</title>
<!-- Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<style>
    body {
        font-family: 'Plus Jakarta Sans', sans-serif;
        background-color: #060913;
        background-image: 
            radial-gradient(circle at 10% 20%, rgba(56, 189, 248, 0.03) 0%, transparent 40%),
            radial-gradient(circle at 90% 80%, rgba(16, 185, 129, 0.03) 0%, transparent 40%);
        color: #f8fafc;
    }
    .font-mono-num {
        font-family: 'JetBrains Mono', monospace;
    }
</style>
</head>
<body class="min-h-screen flex items-center justify-center py-10 px-4">

<div class="bg-[#0f172a] border border-white/5 rounded-2xl shadow-2xl p-6 sm:p-8 w-full max-w-4xl backdrop-blur-xl">

    <!-- Header / Navigation Bar -->
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8 pb-6 border-b border-white/10">
        <div>
            <div class="flex items-center gap-2.5 mb-1">
                <span class="inline-block w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse"></span>
                <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Trade Execution Log</span>
            </div>
            <h1 class="text-2xl font-bold tracking-tight text-white flex items-center gap-3">
                Trade #<?= htmlspecialchars($trade['trade_number'] ?? $tradeId) ?>
                <span class="bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 px-3 py-0.5 rounded-lg text-sm font-mono-num">
                    <?= htmlspecialchars($trade['ticker'] ?? 'N/A') ?>
                </span>
            </h1>
        </div>
        <a href="index.php?session=<?= htmlspecialchars($_GET['session'] ?? '') ?>" class="bg-[#1e293b] hover:bg-slate-700 text-slate-300 hover:text-white border border-white/5 px-4 py-2.5 rounded-xl text-xs font-semibold uppercase tracking-wider transition">
            ← Back to Trades
        </a>
    </div>

    <?php if(!empty($trade['image_link'])): ?>
    <!-- Image Preview Box -->
    <div class="mb-8 p-3 bg-[#1e293b]/50 border border-white/5 rounded-xl">
        <div class="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2 px-1">Chart Setup Snapshot</div>
        <img src="<?= htmlspecialchars($trade['image_link']) ?>" alt="Trade Setup Image" class="w-full rounded-lg shadow-inner max-h-[500px] object-cover">
    </div>
    <?php endif; ?>

    <!-- Content Grid / Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        
        <!-- Time Frame Analysis -->
        <div class="bg-[#1e293b]/70 border border-white/5 rounded-xl p-5">
            <h2 class="text-xs font-semibold uppercase tracking-wider text-cyan-400 mb-2">Time Frame Note</h2>
            <p class="text-slate-300 text-sm leading-relaxed"><?= nl2br(htmlspecialchars($trade['time_frame_note'] ?? 'No note provided.')) ?></p>
        </div>

        <!-- Timeframe Specification -->
        <div class="bg-[#1e293b]/70 border border-white/5 rounded-xl p-5">
            <h2 class="text-xs font-semibold uppercase tracking-wider text-cyan-400 mb-2">Timeframe Configuration</h2>
            <p class="text-slate-300 text-sm leading-relaxed font-mono-num"><?= nl2br(htmlspecialchars($trade['timeframe'] ?? 'N/A')) ?></p>
        </div>

    </div>

    <!-- Detailed Breakdown Container -->
    <div class="space-y-6">
        
        <!-- Why Trade -->
        <div class="bg-[#1e293b]/40 border border-white/5 rounded-xl p-5">
            <h2 class="text-xs font-semibold uppercase tracking-wider text-amber-400 mb-2">Thesis / Why Trade</h2>
            <p class="text-slate-200 text-sm leading-relaxed"><?= nl2br(htmlspecialchars($trade['why_trade'] ?? 'No thesis recorded.')) ?></p>
        </div>

        <!-- Note -->
        <div class="bg-[#1e293b]/40 border border-white/5 rounded-xl p-5">
            <h2 class="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Execution Notes</h2>
            <p class="text-slate-200 text-sm leading-relaxed"><?= nl2br(htmlspecialchars($trade['note'] ?? 'No additional notes.')) ?></p>
        </div>

        <!-- Closing Note -->
        <div class="bg-[#1e293b]/40 border border-white/5 rounded-xl p-5">
            <h2 class="text-xs font-semibold uppercase tracking-wider text-emerald-400 mb-2">Closing & Post-Trade Review</h2>
            <p class="text-slate-200 text-sm leading-relaxed"><?= nl2br(htmlspecialchars($trade['closing_note'] ?? 'Trade currently open or review pending.')) ?></p>
        </div>

    </div>

    <!-- Footer Back Link -->
    <div class="mt-8 pt-6 border-t border-white/10 flex justify-end">
        <a href="index.php?session=<?= htmlspecialchars($_GET['session'] ?? '') ?>" class="text-cyan-400 hover:text-cyan-300 text-sm font-semibold flex items-center gap-1.5 transition">
            ← Back to Trades Dashboard
        </a>
    </div>

</div>

</body>
</html>
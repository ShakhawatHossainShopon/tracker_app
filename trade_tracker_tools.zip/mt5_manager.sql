-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 27, 2026 at 10:16 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mt5_manager`
--

-- --------------------------------------------------------

--
-- Table structure for table `calculator_cards`
--

CREATE TABLE `calculator_cards` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `bLots` float DEFAULT NULL,
  `bDist` float DEFAULT NULL,
  `bRisk` float DEFAULT NULL,
  `dist` float DEFAULT NULL,
  `lots` float DEFAULT NULL,
  `risk` float DEFAULT NULL,
  `ratio` float DEFAULT NULL,
  `tf` int(11) DEFAULT NULL,
  `atr` float DEFAULT NULL,
  `baseSpread` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `calculator_cards`
--

INSERT INTO `calculator_cards` (`id`, `name`, `bLots`, `bDist`, `bRisk`, `dist`, `lots`, `risk`, `ratio`, `tf`, `atr`, `baseSpread`) VALUES
(2, 'GBP/USD', 0.01, 100, 1, 100, 0.05, 5, 1, 5, 9, 0.1),
(3, 'EUR/USD', 0.01, 100, 0.63, 100, 0.08, 5.04, 0.63, 5, 15, 0.08);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `calculator_cards`
--
ALTER TABLE `calculator_cards`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
